package com.homedepot.renowalk.ConfigManager;

public class SQLConfig {
	
	public final String sPropertySelectQuery = "SELECT * FROM Renowalk.Property WHERE Property_Id='param_prop'"; 
	
}
