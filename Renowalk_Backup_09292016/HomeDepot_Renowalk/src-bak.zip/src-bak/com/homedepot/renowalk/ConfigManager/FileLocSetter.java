package com.homedepot.renowalk.ConfigManager;

public class FileLocSetter {

	public static final String sProjPath = "C://Selenium_Workspace//HomeDepot_Renowalk//";
	public static final String sTestDataPath = sProjPath+"TestData//";
	public static final String sConfigPath = sProjPath+"config//";
	public static final String sFileName = "Renowalk_Automation_Data.xls";
	public static final String sPropFile = sProjPath+"global.properties"; // properties file
	public static final String sReportsPath = sProjPath	;
	
}
