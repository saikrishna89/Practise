package com.homedepot.renowalk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Objects;
import com.homedepot.renowalk.ObjectRepository.RenowalkHome;
import com.homedepot.renowalk.ObjectRepository.RenowalkModules;
import com.homedepot.renowalk.ReportManager.Reporter;
import com.homedepot.renowalk.UtilManager.AppMessages;


public class Regression extends TestDriver
{
	RenowalkModules objRWModules = new RenowalkModules();
	RenowalkHome objRWHome = new RenowalkHome();
	AppMessages objAppMessages = new AppMessages();
	
	///////////////////////////////////Offices Tests Start Here///////////////////////////////////////////////////////////////////////////
			//RW_Offices_TC001_View Offices_Viewing the Offices
			@SuppressWarnings("static-access")
			public Reporter TC27166(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27166 Started..");

				try {
							
					obj.repAddData( "Viewing the Offices", "", "", "");
					
					/*ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();*/
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					fnSelectFromComboBoxXpath(objRWModules.Common_ViewModules_ComboPageSize_xp,"VIEW ALL");
					fnLoadingPageWait();
			/*		WebElement eleTable = driver.findElement(By.xpath(objRWHome.Main_ViewModules_Table_xp));

					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());

					HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer,HashMap<Integer, String>>();
					ArrayList<String> arrTableData = new ArrayList<String>();
		
					for(int iRow=0;iRow<arrTableRows.size();iRow++)
					{	
						//arrTableData.clear();
						String sColValue=null;
						mTableData.put(iRow+1, new HashMap<Integer, String>());
						
						List<WebElement> arrTableColumns = arrTableRows.get(iRow).findElements(By.xpath("./td"));  //Get the table data rows
						for(int iCol=0;iCol<arrTableColumns.size();iCol++)
						{
							List<WebElement> arrEditDelete;	
						
							switch (iCol) 
							{
								case 0: //sColValue = arrTableColumns.get(iCol).findElement(By.xpath("./b")).getText();//.toString();
										sColValue = arrTableColumns.get(iCol).findElement(By.xpath("./b")).getAttribute("innerText");
										System.out.println("sColValue"+sColValue);
										break;
								case 1: sColValue = arrTableColumns.get(iCol).getText().toString();
										break;
								case 2: arrEditDelete = arrTableColumns.get(iCol).findElements(By.xpath("./div/span"));
										String sEdit  = arrEditDelete.get(0).getAttribute("title");
										String sDelete = arrEditDelete.get(1).getAttribute("title");
										System.out.println(sEdit+sDelete);
										sColValue= sEdit+","+sDelete;
										break;
							}
							arrTableData.add(sColValue);
							
							mTableData.get(iRow+1).put(iCol+1,sColValue);
						}
						
		
					}*/
					
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Offices");
					fnCheckSortedList(mTableData,"Office Name",1);
					System.out.println("Sorted Functionality Tested Successfully");
								////////////////////Sorting Logic End////////////////////////////
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27166 Failed!", e );
				}
				finally {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					/*obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					header = null;    //Enable after testing
		*/				log.info("Execution of Function TC27166 Completed");
				}
				return obj;
			} //End of function TC27166	
			
			//RW_Offices_TC002_View Offices_Viewing the Columns in Office Table
			@SuppressWarnings("static-access")
			public Reporter TC27167(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27167 Started..");

				try {
							
					obj.repAddData( "Viewing the Columns in Office Table", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("./thead/tr/th"));  //Get the header
					System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
					fnVerifyHeaders(arrHeaderColumns,0,"Office Name");
					fnVerifyHeaders(arrHeaderColumns,1,"Default Store");
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27167 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27167 Completed");
				}
				return obj;
			} //End of function TC27167	
			
			
			//RW_Offices_TC003_View Offices_Availability of Add Office, Edit and Delete options
			@SuppressWarnings("static-access")
			public Reporter TC27168(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27168 Started..");

				try {
							
					obj.repAddData( "Availability of Add Office, Edit and Delete Options", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					fnCheckFieldDisplayByXpath(RenowalkModules.Offices_ViewOffice_BtnAddOffice_xp,"'Add Office' button",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.Offices_ViewOffice_BtnAddOffice_xp)));
					
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Offices");
					boolean bEditDelete = true;
					int iRow = 0;
					for(iRow=1;iRow<=mTableData.size();iRow++)
					{
						String[] arrEditDelete = mTableData.get(iRow).get(3).toString().trim().split(";;");
						if(!arrEditDelete[0].toString().trim().equalsIgnoreCase("Edit") && !arrEditDelete[1].toString().trim().equalsIgnoreCase("Delete"))
						{
							bEditDelete = false;
							break;
						}
					
					}
					
					if(bEditDelete==true)
					{
						obj.repAddData( "Verify Edit and Delete Options", "Edit and Delete Options should be displayed in front of each row", "Edit and Delete Options are displayed in front of each row", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Edit and Delete Options", "Edit and Delete Options should be displayed in front of each row", "Edit and Delete Options are not displayed for row = "+iRow, "Fail");
					}
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27168 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27168 Completed");
				}
				return obj;
			} //End of function TC27168	
	
			
			//RW_Offices_TC004_View Offices_Check Table Title
			@SuppressWarnings("static-access")
			public Reporter TC27170(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27170 Started..");

				try {
							
					obj.repAddData( "Check Office Table Title", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					fnCheckFieldDisplayByXpath(RenowalkModules.Offices_ViewOffice_LabelCurrentOffices_xp,"'Current Offices' label",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.Offices_ViewOffice_LabelCurrentOffices_xp)));
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27170 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27170 Completed");
				}
				return obj;
			} //End of function TC27170	
			
			
			//RW_Offices_TC005_View Offices_Availability of Pagination options
			@SuppressWarnings("static-access")
			public Reporter TC27171(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27171 Started..");

				try {
							
					obj.repAddData( "Availability of Pagination Options", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27171 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27171 Completed");
				}
				return obj;
			} //End of function TC27171	
			
			
			//RW_Offices_TC006_View Offices_Validate Office table count using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC27172(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27172 Started..");

				try {
							
					obj.repAddData( "Office Table Count for VIEW ALL Option", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					//driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
					//Write DB code here
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27172 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27172 Completed");
				}
				return obj;
			} //End of function TC27172	
			
			
			//RW_Offices_TC007_View Offices_Validate Office table records using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC27173(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27173 Started..");

				try {
							
					obj.repAddData( "Office Table Records for VIEW ALL Option", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);
					
					WebElement eleTable = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
					//HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWHome.Main_ViewModules_Table_xp, "Offices");
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27173 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27173 Completed");
				}
				return obj;
			} //End of function TC27173	
			
			
			//RW_Offices_TC008_View Offices_Validate Pagination for option 10
			@SuppressWarnings("static-access")
			public Reporter TC27174(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27174 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 10", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
					//HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWHome.Main_ViewModules_Table_xp, "Offices");
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27174 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27174 Completed");
				}
				return obj;
			} //End of function TC27174	
			
			
			//RW_Offices_TC009_View Offices_Validate Pagination for any page with option 10
			@SuppressWarnings("static-access")
			public Reporter TC27175(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27175 Started..");

				try {
							
					obj.repAddData("Validate pagination for any page with option 10", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp); 
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum),"Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 10", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
					fnVerifyNumofRecords("10");
					
					//HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWHome.Main_ViewModules_Table_xp, "Offices");
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27175 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27175 Completed");
				}
				return obj;
			} //End of function TC27175	
			
			
			//RW_Offices_TC010_View Offices_Validate Pagination for option 20
			@SuppressWarnings("static-access")
			public Reporter TC27176(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27176 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 20", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnVerifyNumofRecords("20");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}
					
					//HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWHome.Main_ViewModules_Table_xp, "Offices");
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27176 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27176 Completed");
				}
				return obj;
			} //End of function TC27176	
			
			
			//RW_Offices_TC011_View Offices_Validate Pagination for any page with option 20
			@SuppressWarnings("static-access")
			public Reporter TC27177(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27177 Started..");

				try {
							
					obj.repAddData("Validate pagination for any page with option 20", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnVerifyNumofRecords("20");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 20", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}
					
					fnVerifyNumofRecords("20");
					
					//HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWHome.Main_ViewModules_Table_xp, "Offices");
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27177 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27177 Completed");
				}
				return obj;
			} //End of function TC27177	
			
			
			//RW_Offices_TC012_View Offices_Validate for Page Counter and Navigation
			@SuppressWarnings("static-access")
			public Reporter TC27178(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27178 Started..");

				try {
							
					obj.repAddData("Validate Page Counter and Navigation", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
		
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);
					
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option '10 PER PAGE' should be validated", "Pagination with option '10 PER PAGE' cannot be validated as no of records are less than 10", "Pass");
					}
					
					
					//HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWHome.Main_ViewModules_Table_xp, "Offices");
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27178 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27178 Completed");
				}
				return obj;
			} //End of function TC27178	
			
			//RW_Offices_TC013_View Offices_Validate for Previous Button for navigation
			@SuppressWarnings("static-access")
			public Reporter TC27179(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27179 Started..");

				try {
							
					obj.repAddData("Validate Previous Button for navigation", "", "", "");
								
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, "1", "Page Number");
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						//fnCheckEnableByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button"); //For temperory purpose, comment this code once improvement RW-314 gets fixed
						fnCheckDisbleByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button");//Once implemented, uncomment this line
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27179 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27179 Completed");
				}
				return obj;
			} //End of function TC27179	
			
			//RW_Offices_TC014_View Offices_Validate for Next Button for navigation
			@SuppressWarnings("static-access")
			public Reporter TC27180(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27180 Started..");

				try {
							
					obj.repAddData("Validate Next Button for navigation", "", "", "");
								
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
						
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						//fnCheckEnableByXPath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "'Next' button"); //For temperory purpose, comment this code once improvement RW-314 gets fixed
						fnCheckDisbleByXPath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "'Next' button");//Once implemented, uncomment this line
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27180 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27180 Completed");
				}
				return obj;
			} //End of function TC27180	
			
			
			//RW-60_Offices_TC018_Add Office_Add Office Page
			@SuppressWarnings("static-access")
			public Reporter TC27184(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27184 Started..");
				
				try {
					obj.repAddData( "Adding the Office", "", "", "");
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp,"Office Name text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "ZipCode text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone number text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote EMail Address text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region select box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit email address text box", true, true);
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
				
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27184 Failed!", e );
				}
				finally {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					/*obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					header = null;    //Enable after testing
		*/				log.info("Execution of Function TC27184 Completed");
				}
				return obj;
			} //End of function TC27184
			
			
			//RW-60_Offices_TC019_Add Office_Validate add Office page fields
			@SuppressWarnings("static-access")
			public Reporter TC27185(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27185 Started..");

				try {
							
					obj.repAddData( "Validating the Office Page", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					//Check for Office Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_OfficeNameErrorMsgRequired_xp, "Office name Error Message", true, true);
		
					String sOfficeNameMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_OfficeNameErrorMsgRequired_xp)).getText().toString().trim();
					if(sOfficeNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					//Check for Default Store Number Validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_DefaultStoreNumberErrorMsgRequired_xp, "Default Store Number Error Message", true, true);
		
					String sDefaultStoreNumberMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_DefaultStoreNumberErrorMsgRequired_xp)).getText().toString().trim();
					if(sDefaultStoreNumberMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					
					//check for Address field validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_AddressErrorMsgRequired_xp, "Address Error Message", true, true);
		
					String sAddressMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_AddressErrorMsgRequired_xp)).getText().toString().trim();
					if(sAddressMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					//check for City field validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_CityErrorMsgRequired_xp, "City Error Message", true, true);
		
					String sCityMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_CityErrorMsgRequired_xp)).getText().toString().trim();
					if(sCityMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					//check for State field validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_StateErrorMsgRequired_xp, "State Error Message", true, true);
		
					String sStateMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_StateErrorMsgRequired_xp)).getText().toString().trim();
					if(sStateMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					//check for Zip Code field validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);

					
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ZipCodeErrorMsgRequired_xp, "Zip Code Error Message", true, true);
		
					String sZipCodeMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ZipCodeErrorMsgRequired_xp)).getText().toString().trim();
					if(sZipCodeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					//check for Phone Number field validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_PhoneNumberErrorMsgRequired_xp, "Phone Number Error Message", true, true);
		
					String sPhoneNumberMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_PhoneNumberErrorMsgRequired_xp)).getText().toString().trim();
					if(sPhoneNumberMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		
					
					//check for Quote Email Address field validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_QuoteEmailAddressErrorMsgRequired_xp, "Quote Email Address Error Message", true, true);

					String sQuoteEmailAddressMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_QuoteEmailAddressErrorMsgRequired_xp)).getText().toString().trim();
					if(sQuoteEmailAddressMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27185 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27185 Completed");
				}
				return obj;
			} //End of function TC27185	
			
			//RW-60_Offices_TC020_Add Office_Required Field Office Name Validation
			@SuppressWarnings("static-access")
			public Reporter TC27186(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27186 Started..");

				try {
							
					obj.repAddData( "Required Field Office Name Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					//Check for Office Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);			
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_OfficeNameErrorMsgRequired_xp, "Office name Error Message", true, true);
		
					String sOfficeNameMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_OfficeNameErrorMsgRequired_xp)).getText().toString().trim();
					if(sOfficeNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27186 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27186 Completed");
				}
				return obj;
			} //End of function TC27186	
			
			
			//RW-60_Offices_TC021_Add Office_Required Field Default Store Number Validation
			@SuppressWarnings("static-access")
			public Reporter TC27187(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27187 Started..");

				try {
							
					obj.repAddData( "Required Field Default Store Number Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);		
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);				
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_DefaultStoreNumberErrorMsgRequired_xp, "Default Store Number Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_DefaultStoreNumberErrorMsgRequired_xp);
		
					String sDefaultStoreNumberMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_DefaultStoreNumberErrorMsgRequired_xp)).getText().toString().trim();
					if(sDefaultStoreNumberMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27187 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27187 Completed");
				}
				return obj;
			} //End of function TC27187	
			
			//RW-60_Offices_TC022_Add Office_Required Field Address Validation
			@SuppressWarnings("static-access")
			public Reporter TC27188(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27188 Started..");

				try {
							
					obj.repAddData( "Required Field Address Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_AddressErrorMsgRequired_xp, "Address Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_AddressErrorMsgRequired_xp);
		
					String sAddressMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_AddressErrorMsgRequired_xp)).getText().toString().trim();
					if(sAddressMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27188 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27188 Completed");
				}
				return obj;
			} //End of function TC27188	
			
			
			//RW-60_Offices_TC023_Add Office_Required Field City Validation
			@SuppressWarnings("static-access")
			public Reporter TC27189(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27189 Started..");

				try {
							
					obj.repAddData( "Required Field City Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_CityErrorMsgRequired_xp, "City Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_CityErrorMsgRequired_xp);
		
					String sCityMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_CityErrorMsgRequired_xp)).getText().toString().trim();
					if(sCityMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27189 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27189 Completed");
				}
				return obj;
			} //End of function TC27189	
			
			
			//RW-60_Offices_TC024_Add Office_Required Field State Validation
			@SuppressWarnings("static-access")
			public Reporter TC27190(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27190 Started..");

				try {
							
					obj.repAddData( "Required Field State Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_StateErrorMsgRequired_xp, "State Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_StateErrorMsgRequired_xp);
		
					String sStateMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_StateErrorMsgRequired_xp)).getText().toString().trim();
					if(sStateMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		
					
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27190 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27190 Completed");
				}
				return obj;
			} //End of function TC27190
			
			
			//RW-60_Offices_TC025_Add Office_Required Field Zip Code Validation
			@SuppressWarnings("static-access")
			public Reporter TC27192(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27192 Started..");

				try {
							
					obj.repAddData( "Required Field Zip Code Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ZipCodeErrorMsgRequired_xp, "Zip Code Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ZipCodeErrorMsgRequired_xp);
		
					String sZipCodeMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ZipCodeErrorMsgRequired_xp)).getText().toString().trim();
					if(sZipCodeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			

					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27192 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27192 Completed");
				}
				return obj;
			} //End of function TC27192
			
			
			//RW-60_Offices_TC026_Add Office_Required Field Phone Number Validation
			@SuppressWarnings("static-access")
			public Reporter TC27191(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27191 Started..");

				try {
							
					obj.repAddData( "Required Field Phone Number Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_PhoneNumberErrorMsgRequired_xp, "Phone Number Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_PhoneNumberErrorMsgRequired_xp);
		
					String sPhoneNumberMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_PhoneNumberErrorMsgRequired_xp)).getText().toString().trim();
					if(sPhoneNumberMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27191 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27191 Completed");
				}
				return obj;
			} //End of function TC27191
			
			//RW-60_Offices_TC027_Add Office_Required Field Quote Email Address Validation
			@SuppressWarnings("static-access")
			public Reporter TC27193(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27193 Started..");

				try {
							
					obj.repAddData( "Required Field Phone Number Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_QuoteEmailAddressErrorMsgRequired_xp, "Quote Email Address Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_QuoteEmailAddressErrorMsgRequired_xp);
		
					String sQuoteEmailAddressMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_QuoteEmailAddressErrorMsgRequired_xp)).getText().toString().trim();
					if(sQuoteEmailAddressMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27193 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27193 Completed");
				}
				return obj;
			} //End of function TC27193
			
			
			//RW-60_Offices_TC028_Add Office_Required Field Address and City Validation
			@SuppressWarnings("static-access")
			public Reporter TC27194(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27194 Started..");

				try {
							
					obj.repAddData( "Required Field Address and City Validation", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputOfficeName_xp)).sendKeys(sOfficeName);
					
					//fill all fields with value
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).clear();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_AddressErrorMsgRequired_xp, "Address Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_AddressErrorMsgRequired_xp);
		
					String sAddressMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_AddressErrorMsgRequired_xp)).getText().toString().trim();
					if(sAddressMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_CityErrorMsgRequired_xp, "City Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_CityErrorMsgRequired_xp);
		
					String sCityMsg = driver.findElement(By.xpath(objRWModules.Offices_AddOffice_CityErrorMsgRequired_xp)).getText().toString().trim();
					if(sCityMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27194 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27194 Completed");
				}
				return obj;
			} //End of function TC27194	
			
			
			
			//RW-60_Offices_TC034_Add Office_Validate Office Name with duplicate Office name for same corporation
			@SuppressWarnings("static-access")
			public Reporter TC27245(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27245 Started..");

				try {
							
					obj.repAddData( "Adding a Duplicate Office name", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, sOfficeName+iRandomNum, "Name");
					
					//Fill all values
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
					
					//Again fill the form with same values
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					SendKeyByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, sOfficeName+iRandomNum, "Name");
					
					//Fill all values
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true);   //Once real time checking deployed for duplicate field, remove this line
					fnLoadingPageWait();
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ErrorMsgDuplicateOfficeName_xp,"Duplicate Error Message", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ErrorMsgDuplicateOfficeName_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ErrorMsgDuplicateOfficeName_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Offices_AddOffice_ErrorMsgDuplicateOfficeName_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Offices_AddOffice_ErrorMsgDuplicateOfficeName_msg+"' should be shown", "'"+objAppMessages.Offices_AddOffice_ErrorMsgDuplicateOfficeName_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Offices_AddOffice_ErrorMsgDuplicateOfficeName_msg+"' should be shown","'"+ objAppMessages.Offices_AddOffice_ErrorMsgDuplicateOfficeName_msg+"' not shown", "Fail");
					}
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27245 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27245 Completed");
				}
				return obj;
			} //End of function TC27245
			
			
			//RW-60_Offices_TC032_Add Office_Save Office Details
			@SuppressWarnings("static-access")
			public Reporter TC27198(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27198 Started..");

				try {
							
					obj.repAddData( "Add and Save an Office", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
										
					int iRandomNum = fnRandomNum(1,10000);
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, sOfficeName+iRandomNum, "Name");
					
					//Fill all values
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);		
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					//region.selectByIndex(1);
					region.selectByVisibleText("Test");  //for demo purpose
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
					
					//obj.repAddData( "Verify Office Name in Database", "", "", "");
					//Put db code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27198 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27198 Completed");
				}
				return obj;
			} //End of function TC27198	
			
			
			//RW-60_Offices_TC033_Add Office_Cancel Adding Office Details
			@SuppressWarnings("static-access")
			public Reporter TC27199(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27199 Started..");

				try {
							
					obj.repAddData( "Cancelling an Office", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, sOfficeName+iRandomNum, "Name");
					
					//Fill all values
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true); 
					obj.repAddData( "Verify Office Name in Database", "", "", "");
					//Put db code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27199 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27199 Completed");
				}
				return obj;
			} //End of function TC27199	
			
			
			//RW-60_Offices_TC031_Add Office_Check View Offices
			@SuppressWarnings("static-access")
			public Reporter TC27197(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27197 Started..");

				try {
							
					obj.repAddData( "Viewing the Offices", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();

					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Offices");
					fnCheckSortedList(mTableData,"Office Name",1);
					System.out.println("Sorted Functionality Tested Successfully");
					////////////////////Sorting Logic End////////////////////////////
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27197 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27197 Completed");
				}
				return obj;
			} //End of function TC27197	
			
			
			//RW-60_Offices_TC029_Add Office_View Regions in Region field
			@SuppressWarnings("static-access")
			public Reporter TC27195(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27195 Started..");

				try {
							
					obj.repAddData( "Viewing the Regions in Region field", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckComboBoxSorting(objRWModules.Offices_AddOffice_ComboRegion_xp,"Region", "Select Region");
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true); 
					fnLoadingPageWait();
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27195 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27195 Completed");
				}
				return obj;
			} //End of function TC27195	
			
			
			//RW-60_Offices_TC035_Add Office_Added Office in User page
			@SuppressWarnings("static-access")
			public Reporter TC27246(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27246 Started..");

				try {
							
					obj.repAddData( "Added Office in User page", "", "", "");

					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add Office button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, "Office Name text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sOfficeName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Offices_AddOffice_InputOfficeName_xp, sOfficeName+iRandomNum, "Name");
					
					//Fill all values
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp, "Default Store Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp);				
					String sDefaultStoreNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("StoreNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputDefaultStoreNumber_xp)).sendKeys(sDefaultStoreNumber);


					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputAddress_xp, "Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputAddress_xp);					
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputAddress_xp)).sendKeys(sAddress);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputCity_xp, "City text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputCity_xp);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputCity_xp)).sendKeys(sCity);

					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputState_xp, "State text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputState_xp);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputState_xp)).sendKeys(sState);
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp, "Zip Code text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputZipCode_xp);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputZipCode_xp)).sendKeys(sZipCode);					
										
										
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp, "Phone Number text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp);
					String sPhoneNumber = mTestPhaseData.get(TestDriver.iTC_ID).get("PhoneNumber").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputPhoneNumber_xp)).sendKeys(sPhoneNumber);					
									
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp, "Quote Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp);
					String sQuoteEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_InputQuoteEmailAddress_xp)).sendKeys(sQuoteEmailAddress);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp, "Region Select Box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_ComboRegion_xp);
					Select region = new Select(driver.findElement(By.xpath(objRWModules.Offices_AddOffice_ComboRegion_xp)));
					region.selectByIndex(1);
					
					fnCheckFieldDisplayByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp, "Property Walk Submit Email Address text box", true, true);
					HighlightElementByXpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp);
					String sPropertyWalkSubmitEmailAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Email").toString().trim();
					driver.findElement(By.xpath(objRWModules.Offices_AddOffice_Input_InputPropertyWalkSubmitEmailAddress_xp)).sendKeys(sPropertyWalkSubmitEmailAddress);
					
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
					
					obj.repAddData( "Verify Added Office in User page", "", "", "");
					//Put code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27246 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27246 Completed");
				}
				return obj;
			} //End of function TC27246	

			
			///////////////////////////////////Offices Tests End Here///////////////////////////////////////////////////////////////////////////		
	
			///////////////////////////////////////Corporations Tests Start Here///////////////////////////////////////////////////////////////////////////		
			
			//RW_Corporations_TC001_View Corporations_Viewing the Corporations
			@SuppressWarnings("static-access")
			public Reporter TC27057(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27057 Started..");

				try {
							
					obj.repAddData( "Viewing the Corporations", "", "", "");
					
					/*ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();*/
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					fnSelectFromComboBoxXpath(objRWModules.Common_ViewModules_ComboPageSize_xp,"VIEW ALL");
					fnLoadingPageWait();
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Corporations");
					fnCheckSortedList(mTableData,"Corporation Name",1);
					System.out.println("Sorted Functionality Tested Successfully");
								////////////////////Sorting Logic End////////////////////////////
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27057 Failed!", e );
				}
				finally {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					/*obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					header = null;    //Enable after testing
		*/				log.info("Execution of Function TC27057 Completed");
				}
				return obj;
			} //End of function TC27057	
			
			
			//RW_Corporations_TC002_View Corporations_Availability of Add Corporation option
			@SuppressWarnings("static-access")
			public Reporter TC27058(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27058 Started..");

				try {
							
					obj.repAddData( "Availability of Add Corporation option", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					fnCheckFieldDisplayByXpath(RenowalkModules.Corporations_ViewCorporation_BtnAddCorporation_xp,"'Add Corporation' button",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.Corporations_ViewCorporation_BtnAddCorporation_xp)));
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("./thead/tr/th"));  //Get the header
					System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
					fnVerifyHeaders(arrHeaderColumns,0,"Corporation Name");  //There is one improvement RW-286. Once implemented, change it to Corporation Name
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27058 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27058 Completed");
				}
				return obj;
			} //End of function TC27058	
			
			
			//RW_Corporations_TC003_View Corporations_Availability of edit and delete options
			@SuppressWarnings("static-access")
			public Reporter TC27059(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27059 Started..");

				try {
							
					obj.repAddData( "Availability of Edit and Delete Options", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Corporations");
					boolean bEditDelete = true;
					int iRow = 0;
					System.out.println("mTableData.keySet().size()>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+mTableData.keySet().size());
					for(iRow=1;iRow<=mTableData.size();iRow++)
					{
						String[] arrEditDelete = mTableData.get(iRow).get(2).toString().trim().split(";;");
						if(!arrEditDelete[0].toString().trim().equalsIgnoreCase("Edit") && !arrEditDelete[1].toString().trim().equalsIgnoreCase("Delete"))
						{
							bEditDelete = false;
							break;
						}
					
					}
					
					if(bEditDelete==true)
					{
						obj.repAddData( "Verify Edit and Delete Options", "Edit and Delete Options should be displayed in front of each row", "Edit and Delete Options are displayed in front of each row", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Edit and Delete Options", "Edit and Delete Options should be displayed in front of each row", "Edit and Delete Options are not displayed for row = "+iRow, "Fail");
					}
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27059 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27059 Completed");
				}
				return obj;
			} //End of function TC27059	
	
			
			//RW_Corporations_TC004_View Corporations_Check table title
			@SuppressWarnings("static-access")
			public Reporter TC27060(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27060 Started..");

				try {
							
					obj.repAddData( "Check Corporation Table Title", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					fnCheckFieldDisplayByXpath(RenowalkModules.Corporations_ViewCorporation_LabelCurrentCorporations_xp,"'Current Corporations' label",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.Corporations_ViewCorporation_LabelCurrentCorporations_xp)));
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27060 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27060 Completed");
				}
				return obj;
			} //End of function TC27060	
			
			
			//RW_Corporations_TC017_View Corporations_Availability of Pagination options
			@SuppressWarnings("static-access")
			public Reporter TC27136(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27136 Started..");

				try {
							
					obj.repAddData( "Availability of Pagination Options", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27136 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27136 Completed");
				}
				return obj;
			} //End of function TC27136	
			
			
			//RW_Corporations_TC018_View Corporations_Validate Corporation table count using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC27137(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27137 Started..");

				try {
							
					obj.repAddData( "Corporation Table Count for VIEW ALL Option", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27137 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27137 Completed");
				}
				return obj;
			} //End of function TC27137	
			
			
			//RW_Corporations_TC019_View Corporations_Validate Corporation table records using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC27138(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27138 Started..");

				try {
							
					obj.repAddData( "Corporation Table Records for VIEW ALL Option", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);
					
					WebElement eleTable = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27138 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27138 Completed");
				}
				return obj;
			} //End of function TC27138	
			
			
			//RW_Corporations_TC020_View Corporations_Validate Pagination for option 10
			@SuppressWarnings("static-access")
			public Reporter TC27139(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27139 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 10", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27139 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27139 Completed");
				}
				return obj;
			} //End of function TC27139	
			
			
			//RW_Corporations_TC021_View Corporations_Validate Pagination for any page with option 10
			@SuppressWarnings("static-access")
			public Reporter TC27140(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27140 Started..");

				try {
							
					obj.repAddData("Validate pagination for any page with option 10", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 10", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
					fnVerifyNumofRecords("10");

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27140 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27140 Completed");
				}
				return obj;
			} //End of function TC27140	
			
			
			//RW_Corporations_TC022_View Corporations_Validate Pagination for option 20
			@SuppressWarnings("static-access")
			public Reporter TC27141(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27141 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 20", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnVerifyNumofRecords("20");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27141 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27141 Completed");
				}
				return obj;
			} //End of function TC27141	
			
			
			//RW_Corporations_TC023_View Corporations_Validate Pagination for any page with option 20
			@SuppressWarnings("static-access")
			public Reporter TC27142(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27142 Started..");

				try {
							
					obj.repAddData("Validate pagination for any page with option 20", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnVerifyNumofRecords("20");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 20", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}
					
					fnVerifyNumofRecords("20");

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27142 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27142 Completed");
				}
				return obj;
			} //End of function TC27142	
			
			
			//RW_Corporations_TC024_View Corporations_Validate for Page Counter and Navigation
			@SuppressWarnings("static-access")
			public Reporter TC27143(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27143 Started..");

				try {
							
					obj.repAddData("Validate Page Counter and Navigation", "", "", "");
					
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
		
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);
					
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option '10 PER PAGE' should be validated", "Pagination with option '10 PER PAGE' cannot be validated as no of records are less than 10", "Pass");
					}

					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27143 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27143 Completed");
				}
				return obj;
			} //End of function TC27143	
			
			//RW_Corporations_TC025_View Corporations_Validate for Previous Button for navigation
			@SuppressWarnings("static-access")
			public Reporter TC27144(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC27144 Started..");

				try {
							
					obj.repAddData("Validate Previous Button for navigation", "", "", "");
								
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, "1", "Page Number");
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckEnableByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button"); //For temperory purpose, comment this code once improvement RW-314 gets fixed
						//fnCheckDisbleByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button");//Once implemented, un-comment this line
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27144 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27144 Completed");
				}
				return obj;
			} //End of function TC27144	
			
			//RW_Corporations_TC026_View Corporations_Validate for Next Button for navigation
			@SuppressWarnings("static-access")
			public Reporter TC27145(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27145 Started..");

				try {
							
					obj.repAddData("Validate Next Button for navigation", "", "", "");
								
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
						
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckEnableByXPath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "'Next' button"); //For temperory purpose, comment this code once improvement RW-314 gets fixed
						//fnCheckDisbleByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button");//Once implemented, uncomment this line
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27145 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27145 Completed");
				}
				return obj;
			} //End of function TC27145	

			
			//RW-46_Corporations_TC007_Add Corporation_Add Corporation Page
			@SuppressWarnings("static-access")
			public Reporter TC27063(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27063 Started..");

				try {
							
					obj.repAddData( "Adding the Corporation", "", "", "");
					
					/*ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();*/
					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					/*HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Corporations");
					fnCheckSortedList(mTableData,"Corporation Name",1);
					System.out.println("Sorted Functionality Tested Successfully");*/
					////////////////////Sorting Logic End////////////////////////////
					
					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27063 Failed!", e );
				}
				finally {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					/*obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					header = null;    //Enable after testing
		*/				log.info("Execution of Function TC27063 Completed");
				}
				return obj;
			} //End of function TC27063	
			
			
			//RW-46_Corporations_TC008_Add Corporation_Validate add Corporation
			@SuppressWarnings("static-access")
			public Reporter TC27064(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27064 Started..");

				try {
							
					obj.repAddData( "Validating the Corporation", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					//SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName);
					driver.findElement(By.id(objRWModules.Corporations_AddCorporation_InputCorpName_id)).sendKeys(sName);
					driver.findElement(By.id(objRWModules.Corporations_AddCorporation_InputCorpName_id)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Corporations_AddCorporation_ErrorMsgRequired_xp,"Required Error Message", true, true);
					HighlightElementByXpath(objRWModules.Corporations_AddCorporation_ErrorMsgRequired_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Corporations_AddCorporation_ErrorMsgRequired_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}
					
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27064 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27064 Completed");
				}
				return obj;
			} //End of function TC27064	
			
			
			//RW-46_Corporations_TC009_Add Corporation_Check View Corporations
			@SuppressWarnings("static-access")
			public Reporter TC27065(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27065 Started..");

				try {
							
					obj.repAddData( "Viewing the Corporations", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Corporations");
					fnCheckSortedList(mTableData,"Corporation Name",1);
					System.out.println("Sorted Functionality Tested Successfully");
					////////////////////Sorting Logic End////////////////////////////
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27065 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27065 Completed");
				}
				return obj;
			} //End of function TC27065	
			
			
			//RW-46_Corporations_TC010_Add Corporation_Save Corporation Name
			@SuppressWarnings("static-access")
			public Reporter TC27066(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27066 Started..");

				try {
							
					obj.repAddData( "Add and Save a Corporation", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName+iRandomNum, "Name");
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					//fnLoadingPageWait();
					fnVerifyDialogBox("Add",0);
					
					/*WebDriverWait wait = new WebDriverWait(driver,5);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='confirmSaveContent']/p[@class='saveText']")));	 //Wait for loading message to disappear
					String sConfirmationText =  driver.findElement(By.xpath("//div[@class='confirmSaveContent']/p[@class='saveText']")).getText();
					System.out.println(sConfirmationText);*/
					
					obj.repAddData( "Verify Corporation Name in Database", "", "", "");
					//Put db code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27066 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27066 Completed");
				}
				return obj;
			} //End of function TC27066	
			
			
			//RW-46_Corporations_TC011_Add Corporation_Validate corporation Name with Non Alphanumeric characters
			@SuppressWarnings("static-access")
			public Reporter TC27067(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27067 Started..");

				try {
							
					obj.repAddData( "Add and Save a Corporation with Special Characters", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					String sRandomName ="";
					for(int i=1 ; i<sName.length();i++)
					{
						int iRandomNum = fnRandomNum(1,sName.length()-1);
						sRandomName= sRandomName+sName.charAt(iRandomNum);
						
					}
					SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sRandomName, "Name");
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
		
					obj.repAddData( "Verify Corporation Name in Database", "", "", "");
					//Put db code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27067 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27067 Completed");
				}
				return obj;
			} //End of function TC27067	
			
			//RW-46_Corporations_TC012_Add Corporation_Validate Corporation Name with characters length more than 80
			@SuppressWarnings("static-access")
			public Reporter TC27068(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27068 Started..");

				try {
							
					obj.repAddData( "Add and Save a Corporation with length more than 80", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName+iRandomNum, "Name");
					
					fnCheckFieldDisplayByXpath(objRWModules.Corporations_AddCorporation_ErrorMsgMaxLength_xp,"Max Length Error Message", true, true);
					HighlightElementByXpath(objRWModules.Corporations_AddCorporation_ErrorMsgMaxLength_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Corporations_AddCorporation_ErrorMsgMaxLength_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg))
					{
						obj.repAddData( "Verify Max Length Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Max Length Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' not shown", "Fail");
					}
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27068 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27068 Completed");
				}
				return obj;
			} //End of function TC27068	
			
			//RW-46_Corporations_TC013_Add Corporation_Validate Corporation Name with characters length 80 and special characters
			@SuppressWarnings("static-access")
			public Reporter TC27069(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27069 Started..");

				try {
							
					obj.repAddData( "Add and Save a Corporation with characters length 80 and special characters", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					
					int iRandomNum = fnRandomNum(10000000,99999999);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName+iRandomNum, "Name");
					System.out.println("Size>>>>>>>>>>>>>>>"+sName.length()+String.valueOf(iRandomNum).length());
					
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnSave_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true);
						fnLoadingPageWait();
					}
					else
					{
						obj.repAddData( "Click on Save button", "Save button should be clicked","Save button not clicked", "Fail");
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					
					obj.repAddData( "Verify Corporation Name in Database", "", "", "");
					//Put db code here

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27069 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27069 Completed");
				}
				return obj;
			} //End of function TC27069	
			
			
			//RW-46_Corporations_TC014_Add Corporation_Validate Corporation Name by adding a duplicate Corporation name
			@SuppressWarnings("static-access")
			public Reporter TC27070(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27070 Started..");

				try {
							
					obj.repAddData( "Adding a Duplicate Corporation Name", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName+iRandomNum,"Name");
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName+iRandomNum,"Name");
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true);   //Once real time checking deployed for duplicate field, remove this line
					fnLoadingPageWait();
					
					fnCheckFieldDisplayByXpath(objRWModules.Corporations_AddCorporation_ErrorMsgDuplicate_xp,"Duplicate Error Message", true, true);
					HighlightElementByXpath(objRWModules.Corporations_AddCorporation_ErrorMsgDuplicate_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Corporations_AddCorporation_ErrorMsgDuplicate_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Corporations_AddCorporation_ErrorMsgDuplicate_msg))
					{
						obj.repAddData( "Verify Duplicate Error Message", "'"+objAppMessages.Corporations_AddCorporation_ErrorMsgDuplicate_msg+"' should be shown", "'"+objAppMessages.Corporations_AddCorporation_ErrorMsgDuplicate_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Duplicate Error Message", "'"+objAppMessages.Corporations_AddCorporation_ErrorMsgDuplicate_msg+"' should be shown","'"+ objAppMessages.Corporations_AddCorporation_ErrorMsgDuplicate_msg+"' not shown", "Fail");
					}
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27070 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27070 Completed");
				}
				return obj;
			} //End of function TC27070	
			
			//RW-46_Corporations_TC015_Add Corporation_Cancel adding Corporation name
			@SuppressWarnings("static-access")
			public Reporter TC27071(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27071 Started..");

				try {
							
					obj.repAddData( "Cancelling a Corporation", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName+iRandomNum,"Name");
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true); 
					obj.repAddData( "Verify Corporation Name in Database", "", "", "");
					//Put db code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27071 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27071 Completed");
				}
				return obj;
			} //End of function TC27071	
			
			//RW-46_Corporations_TC016_Add Corporation_Validate Corporation Name with blank characters
			@SuppressWarnings("static-access")
			public Reporter TC27072(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27072 Started..");

				try {
							
					obj.repAddData( "Validating the Corporation Name with blank characters", "", "", "");

					ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Corporations_ViewCorporation_BtnAddCorporation_xp, "Add Corporation button",true);
					fnCheckFieldDisplayById(objRWModules.Corporations_AddCorporation_InputCorpName_id,"Corporation Name text box", true, true);
					HighlightElementById(objRWModules.Corporations_AddCorporation_InputCorpName_id);
					
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					//SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName);
					driver.findElement(By.id(objRWModules.Corporations_AddCorporation_InputCorpName_id)).sendKeys(sName);
					driver.findElement(By.id(objRWModules.Corporations_AddCorporation_InputCorpName_id)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Corporations_AddCorporation_ErrorMsgRequired_xp,"Required Error Message", true, true);
					HighlightElementByXpath(objRWModules.Corporations_AddCorporation_ErrorMsgRequired_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Corporations_AddCorporation_ErrorMsgRequired_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}
	
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27072 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27072 Completed");
				}
				return obj;
			} //End of function TC27072	
			/////////////////////////////////////Corporations Tests End Here///////////////////////////////////////////////////////////////////////////			
			
			
			///////////////////////////////////////Regions Tests Start Here///////////////////////////////////////////////////////////////////////////
			
			//RW-57_Regions_TC001_View Regions_Viewing the Regions
			@SuppressWarnings("static-access")
			public Reporter TC27073(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27073 Started..");

				try {
							
					obj.repAddData( "Viewing the Regions", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					fnSelectFromComboBoxXpath(objRWModules.Common_ViewModules_ComboPageSize_xp,"VIEW ALL");
					fnLoadingPageWait();
					
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Regions");
					fnCheckSortedList(mTableData,"Region Name",1);
					System.out.println("Sorted Functionality Tested Successfully");
								////////////////////Sorting Logic End////////////////////////////
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27073 Failed!", e );
				}
				finally {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					/*obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					header = null;    //Enable after testing
		*/				log.info("Execution of Function TC27073 Completed");
				}
				return obj;
			} //End of function TC27073	
			
			
			//RW-57_Regions_TC002_View Regions_Availability of Add Region option
			@SuppressWarnings("static-access")
			public Reporter TC27075(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27075 Started..");

				try {
							
					obj.repAddData( "Availability of Add Region option", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					fnCheckFieldDisplayByXpath(RenowalkModules.Regions_ViewRegion_BtnAddRegion_xp,"'Add Region' button",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.Regions_ViewRegion_BtnAddRegion_xp)));
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("./thead/tr/th"));  //Get the header
					System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
					fnVerifyHeaders(arrHeaderColumns,0,"Region Name");  //There is one improvement RW-286. Once implemented, change it to Region Name
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27075 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27075 Completed");
				}
				return obj;
			} //End of function TC27075	
			
			
			//RW-57_Regions_TC003_View Regions_Availability of edit and delete options
			@SuppressWarnings("static-access")
			public Reporter TC27077(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27077 Started..");

				try {
							
					obj.repAddData( "Availability of Edit and Delete Options", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
					
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Regions");
					boolean bEditDelete = true;
					int iRow = 0;
					System.out.println("mTableData.keySet().size()>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+mTableData.keySet().size());
					for(iRow=1;iRow<=mTableData.size();iRow++)
					{
						String[] arrEditDelete = mTableData.get(iRow).get(2).toString().trim().split(";;");
						if(!arrEditDelete[0].toString().trim().equalsIgnoreCase("Edit") && !arrEditDelete[1].toString().trim().equalsIgnoreCase("Delete"))
						{
							bEditDelete = false;
							break;
						}
					
					}
					
					if(bEditDelete==true)
					{
						obj.repAddData( "Verify Edit and Delete Options", "Edit and Delete Options should be displayed in front of each row", "Edit and Delete Options are displayed in front of each row", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Edit and Delete Options", "Edit and Delete Options should be displayed in front of each row", "Edit and Delete Options are not displayed for row = "+iRow, "Fail");
					}
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27077 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27077 Completed");
				}
				return obj;
			} //End of function TC27077	
	
			
			//RW-57_Regions_TC004_View Regions_Check table title
			@SuppressWarnings("static-access")
			public Reporter TC27078(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27078 Started..");

				try {
							
					obj.repAddData( "Check Region Table Title", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					fnCheckFieldDisplayByXpath(RenowalkModules.Regions_ViewRegion_LabelCurrentRegions_xp,"'Current Regions' label",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.Regions_ViewRegion_LabelCurrentRegions_xp)));
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27078 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27078 Completed");
				}
				return obj;
			} //End of function TC27078	
			
			
			//RW-57_Regions_TC018_View Regions_Availability of Pagination options
			@SuppressWarnings("static-access")
			public Reporter TC27146(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27146 Started..");

				try {
							
					obj.repAddData( "Availability of Pagination Options", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27146 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27146 Completed");
				}
				return obj;
			} //End of function TC27146	
			
			
			//RW-57_Regions_TC019_View Regions_Validate Region table count using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC27147(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27147 Started..");

				try {
							
					obj.repAddData( "Region Table Count for VIEW ALL Option", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27147 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27147 Completed");
				}
				return obj;
			} //End of function TC27147	
			
			
			//RW-57_Regions_TC020_View Regions_Validate Region table records using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC27148(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27148 Started..");

				try {
							
					obj.repAddData( "Region Table Records for VIEW ALL Option", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);
					
					WebElement eleTable = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
					
					//Write DB code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27148 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27148 Completed");
				}
				return obj;
			} //End of function TC27148	
			
			
			//RW-57_Regions_TC021_View Regions_Validate Pagination for option 10
			@SuppressWarnings("static-access")
			public Reporter TC27149(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27149 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 10", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27149 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27149 Completed");
				}
				return obj;
			} //End of function TC27149	
			
			
			//RW-57_Regions_TC022_View Regions_Validate Pagination for any page with option 10
			@SuppressWarnings("static-access")
			public Reporter TC27150(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27150 Started..");

				try {
							
					obj.repAddData("Validate pagination for any page with option 10", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 10", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
					fnVerifyNumofRecords("10");

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27150 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27150 Completed");
				}
				return obj;
			} //End of function TC27150	
			
			
			//RW-57_Regions_TC023_View Regions_Validate Pagination for option 20
			@SuppressWarnings("static-access")
			public Reporter TC27151(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27151 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 20", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnVerifyNumofRecords("20");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27151 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27151 Completed");
				}
				return obj;
			} //End of function TC27151	
			
			
			//RW-57_Regions_TC024_View Regions_Validate Pagination for any page with option 20
			@SuppressWarnings("static-access")
			public Reporter TC27152(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27152 Started..");

				try {
							
					obj.repAddData("Validate pagination for any page with option 20", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnVerifyNumofRecords("20");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 20", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}
					
					fnVerifyNumofRecords("20");

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27152 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27152 Completed");
				}
				return obj;
			} //End of function TC27152	
			
			
			//RW-57_Regions_TC025_View Regions_Validate for Page Counter and Navigation
			@SuppressWarnings("static-access")
			public Reporter TC27153(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27153 Started..");

				try {
							
					obj.repAddData("Validate Page Counter and Navigation", "", "", "");
					
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
		
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);
					
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option '10 PER PAGE' should be validated", "Pagination with option '10 PER PAGE' cannot be validated as no of records are less than 10", "Pass");
					}

					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27153 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27153 Completed");
				}
				return obj;
			} //End of function TC27153	
			
			//RW-57_Regions_TC026_View Regions_Validate for Previous Button for navigation
			@SuppressWarnings("static-access")
			public Reporter TC27154(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC27154 Started..");

				try {
							
					obj.repAddData("Validate Previous Button for navigation", "", "", "");
								
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, "1", "Page Number");
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckEnableByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button"); //For temperory purpose, comment this code once improvement RW-314 gets fixed
						//fnCheckDisbleByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button");//Once implemented, un-comment this line
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27154 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27154 Completed");
				}
				return obj;
			} //End of function TC27154	
			
			//RW-57_Regions_TC027_View Regions_Validate for Next Button for navigation
			@SuppressWarnings("static-access")
			public Reporter TC27155(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27155 Started..");

				try {
							
					obj.repAddData("Validate Next Button for navigation", "", "", "");
								
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
						
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckEnableByXPath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "'Next' button"); //For temperory purpose, comment this code once improvement RW-314 gets fixed
						//fnCheckDisbleByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button");//Once implemented, uncomment this line
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27155 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27155 Completed");
				}
				return obj;
			} //End of function TC27155	
			
			
			//RW-58_Regions_TC007-Add Region_Add Region Page
			@SuppressWarnings("static-access")
			public Reporter TC27084(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27084 Started..");

				try {
							
					obj.repAddData( "Adding the Region", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();
					
					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27084 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27084 Completed");
				}
				return obj;
			} //End of function TC27084	
			
			
			//RW-58_Regions_TC008_Add Region_Validate add region name
			@SuppressWarnings("static-access")
			public Reporter TC27081(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27081 Started..");

				try {
							
					obj.repAddData( "Validating the Region", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.id(objRWModules.Regions_AddRegion_InputRegionName_id)).sendKeys(sName);
					driver.findElement(By.id(objRWModules.Regions_AddRegion_InputRegionName_id)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Regions_AddRegion_ErrorMsgRequired_xp,"Required Error Message", true, true);
					HighlightElementByXpath(objRWModules.Regions_AddRegion_ErrorMsgRequired_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Regions_AddRegion_ErrorMsgRequired_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}
					
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27081 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27081 Completed");
				}
				return obj;
			} //End of function TC27081	
			
			
			//RW-58_Regions_TC009_Add Region_Check View regions
			@SuppressWarnings("static-access")
			public Reporter TC27085(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27085 Started..");

				try {
							
					obj.repAddData( "Viewing the Regions", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Regions");
					fnCheckSortedList(mTableData,"Region Name",1);
					System.out.println("Sorted Functionality Tested Successfully");
					////////////////////Sorting Logic End////////////////////////////
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27085 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27085 Completed");
				}
				return obj;
			} //End of function TC27085	
			
			
			//RW-58_Regions_TC010_Add Region_Save Region Name
			@SuppressWarnings("static-access")
			public Reporter TC27083(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27083 Started..");

				try {
							
					obj.repAddData( "Add and Save a Region", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Regions_AddRegion_InputRegionName_id, sName+iRandomNum, "Name");
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
					obj.repAddData( "Verify Region Name in Database", "", "", "");
					//Put db code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27083 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27083 Completed");
				}
				return obj;
			} //End of function TC27083	
			
			
			//RW-58_Regions_TC011_Add Region_Validate Region Name with Non Alphanumeric characters
			@SuppressWarnings("static-access")
			public Reporter TC27082(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27082 Started..");

				try {
							
					obj.repAddData( "Add and Save a Region with Special Characters", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					String sRandomName ="";
					for(int i=1 ; i<sName.length();i++)
					{
						int iRandomNum = fnRandomNum(1,sName.length()-1);
						sRandomName= sRandomName+sName.charAt(iRandomNum);
						
					}
					SendKeyById(objRWModules.Regions_AddRegion_InputRegionName_id, sRandomName, "Name");
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
		
					obj.repAddData( "Verify Region Name in Database", "", "", "");
					//Put db code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27082 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27082 Completed");
				}
				return obj;
			} //End of function TC27082	
			
			//RW-58_Regions_TC012_Add Region_Validate region Name with characters length more than 80
			@SuppressWarnings("static-access")
			public Reporter TC27086(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27086 Started..");

				try {
							
					obj.repAddData( "Add and Save a Region with length more than 80", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Regions_AddRegion_InputRegionName_id, sName+iRandomNum, "Name");
					
					fnCheckFieldDisplayByXpath(objRWModules.Regions_AddRegion_ErrorMsgMaxLength_xp,"Max Length Error Message", true, true);
					HighlightElementByXpath(objRWModules.Regions_AddRegion_ErrorMsgMaxLength_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Regions_AddRegion_ErrorMsgMaxLength_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg))
					{
						obj.repAddData( "Verify Max Length Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Max Length Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' not shown", "Fail");
					}
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27086 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27086 Completed");
				}
				return obj;
			} //End of function TC27086	
			
			//RW-58_Regions_TC013_Add Region_Validate Region Name with characters length 80 and special characters
			@SuppressWarnings("static-access")
			public Reporter TC27088(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27088 Started..");

				try {
							
					obj.repAddData( "Add and Save a Region with characters length 80 and special characters", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					int iRandomNum = fnRandomNum(10000000,99999999);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Regions_AddRegion_InputRegionName_id, sName+iRandomNum, "Name");
					System.out.println("Size>>>>>>>>>>>>>>>"+sName.length()+String.valueOf(iRandomNum).length());
					
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnSave_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true);
						fnLoadingPageWait();
					}
					else
					{
						obj.repAddData( "Click on Save button", "Save button should be clicked","Save button not clicked", "Fail");
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					
					obj.repAddData( "Verify Region Name in Database", "", "", "");
					//Put db code here

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27088 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27088 Completed");
				}
				return obj;
			} //End of function TC27088	
			
					
			//RW-58_Regions_TC014_Add Region_Cancel adding region name
			@SuppressWarnings("static-access")
			public Reporter TC27090(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27090 Started..");

				try {
							
					obj.repAddData( "Cancelling a Region", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Regions_AddRegion_InputRegionName_id, sName+iRandomNum,"Name");
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true); 
					obj.repAddData( "Verify Region Name in Database", "", "", "");
					//Put db code here
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27090 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27090 Completed");
				}
				return obj;
			} //End of function TC27090	
			
			
			//RW-58_Regions_TC015_Add Region_Added Region in Office page
			@SuppressWarnings("static-access")
			public Reporter TC27087(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27087 Started..");

				try {
							
					obj.repAddData( "Add and Save a Region", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Regions_AddRegion_InputRegionName_id, sName+iRandomNum, "Name");
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
					obj.repAddData( "Verify Region Name in Database", "", "", "");
					//Put db code here
					
					obj.repAddData( "Viewing the Offices", "", "", "");
					
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
					
					ClickByXpath(objRWModules.Offices_ViewOffice_BtnAddOffice_xp, "Add button",true);
					
					obj.repAddData( "Verifying Region on Office Page", "", "", "");
					fnVerifyComboBoxValue(objRWModules.Offices_AddOffice_ComboRegion_xp, sName+iRandomNum);
					//fnCheckComboBoxSorting(objRWModules.Offices_AddOffice_ComboRegion_xp,"Region", "Select Region");
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false); 
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27087 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27087 Completed");
				}
				return obj;
			} //End of function TC27087	

			
			//RW-58_Regions_TC016_Add Region_Validate Region Name with blank characters
			@SuppressWarnings("static-access")
			public Reporter TC27089(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27089 Started..");

				try {
							
					obj.repAddData( "Validating the Region Name with blank characters", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.id(objRWModules.Regions_AddRegion_InputRegionName_id)).sendKeys(sName);
					driver.findElement(By.id(objRWModules.Regions_AddRegion_InputRegionName_id)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Regions_AddRegion_ErrorMsgRequired_xp,"Required Error Message", true, true);
					HighlightElementByXpath(objRWModules.Regions_AddRegion_ErrorMsgRequired_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Regions_AddRegion_ErrorMsgRequired_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}
	
					//*This field is required
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27089 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27089 Completed");
				}
				return obj;
			} //End of function TC27089	
			
			
			//RW-58_Regions_TC017_Add Region_Validate Region Name with duplicate Region name
			@SuppressWarnings("static-access")
			public Reporter TC27091(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27091 Started..");

				try {
							
					obj.repAddData( "Adding a Duplicate Region Name", "", "", "");

					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					fnCheckFieldDisplayById(objRWModules.Regions_AddRegion_InputRegionName_id,"Region Name text box", true, true);
					HighlightElementById(objRWModules.Regions_AddRegion_InputRegionName_id);
					
					int iRandomNum = fnRandomNum(1,10000);
					String sName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.Regions_AddRegion_InputRegionName_id, sName+iRandomNum,"Name");
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Regions_ViewRegion_BtnAddRegion_xp, "Add Region button",true);
					SendKeyById(objRWModules.Regions_AddRegion_InputRegionName_id, sName+iRandomNum,"Name");
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true);   //Once real time checking deployed for duplicate field, remove this line
					fnLoadingPageWait();
					
					fnCheckFieldDisplayByXpath(objRWModules.Regions_AddRegion_ErrorMsgDuplicate_xp,"Duplicate Error Message", true, true);
					HighlightElementByXpath(objRWModules.Regions_AddRegion_ErrorMsgDuplicate_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.Regions_AddRegion_ErrorMsgDuplicate_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Regions_AddRegion_ErrorMsgDuplicate_msg))
					{
						obj.repAddData( "Verify Duplicate Error Message", "'"+objAppMessages.Regions_AddRegion_ErrorMsgDuplicate_msg+"' should be shown", "'"+objAppMessages.Regions_AddRegion_ErrorMsgDuplicate_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Duplicate Error Message", "'"+objAppMessages.Regions_AddRegion_ErrorMsgDuplicate_msg+"' should be shown","'"+ objAppMessages.Regions_AddRegion_ErrorMsgDuplicate_msg+"' not shown", "Fail");
					}
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC27091 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC27091 Completed");
				}
				return obj;
			} //End of function TC27091	
			
			///////////////////////////////////////Regions Tests End Here///////////////////////////////////////////////////////////////////////////
			
			
			///////////////////////////////////////Properties Tests Start Here///////////////////////////////////////////////////////////////////////////
			//RW-74_Property_TC001_View Property_View Property
			@SuppressWarnings("static-access")
			public Reporter TC31928(Reporter obj) throws Exception
			{
				Boolean bLoginFlag = false;	
				log.info("Execution of Function TC31928 Started..");
				
		
				try {
							
					obj.repAddData( "View Properties", "", "", "");
					
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp, "Property Link",true);
					
					fnLoadingPageWait();

					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Property");
					fnCheckSortedList(mTableData,"Last Activity",7);
					
					fnCheckDateSorting(mTableData, "Last Activity", 7, "DEFAULT");

					//ClickByXpath(RenowalkModules.Common_BtnSorting_xp, "Sorting button", true);
					//mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Property");
					//fnLoadingPageWait();
					//fnCheckDateSorting(mTableData, "Last Activity", 7, "ASC");
					//fnCheckDateSorting(mTableData, "Last Activity", 7, "DESC");
					////////////////////Sorting Logic End////////////////////////////

				}
				
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31928 Failed!", e );
				}
				finally {
					
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC31928 Completed");
				}
				return obj;
			} //End of function TC31928	
			
			
			
			
			///////////////////////////////////////Properties Tests End Here///////////////////////////////////////////////////////////////////////////
			
			
			///////////////////////////////////////Items Tests Start Here/////////////////////////////////////////////////////////////////////////////
			
			//RW-225_Items_TC001_View Items_View Items Ascending
			@SuppressWarnings("static-access")
			public Reporter TC31909(Reporter obj) throws Exception
			{
				Boolean bLoginFlag = false;	
				log.info("Execution of Function TC31909 Started..");
				
		
				try {
							
					obj.repAddData( "View Items", "", "", "");
					
					//fnSelectCorpOffice(sCorporation, sOffice);
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					
					fnLoadingPageWait();
					
					fnSelectFromComboBoxXpath(objRWModules.Common_ViewModules_ComboPageSize_xp, "VIEW ALL");
					fnLoadingPageWait();
					
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Items");
					fnCheckSortedList(mTableData,"Name",1);
					
				}
				
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31909 Failed!", e );
				}
				finally {
					
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC31909 Completed");
				}
				return obj;
			} //End of function TC31909	
			
			
			//RW-225_Items_TC001_View Items_View Items Ascending
			@SuppressWarnings("static-access")
			public Reporter TC31910(Reporter obj) throws Exception
			{
				Boolean bLoginFlag = false;	
				log.info("Execution of Function TC31910 Started..");
				
		
				try {
							
						obj.repAddData( "View Items", "", "", "");
						//fnSelectFromComboBoxXpath(objRWModules.Common_AllModules_ComboCorporateName_xp, "Select");
						fnSelectCorpOffice("Select", sOffice);
						ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
						fnVerifyDialogBox("OfficeCode",1);
					
				}
				
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31910 Failed!", e );
				}
				finally {
					
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC31910 Completed");
				}
				return obj;
			} //End of function TC31910	
			
			//RW-225_Items_TC003_View Items_Verify columns
			@SuppressWarnings("static-access")
			public Reporter TC31911(Reporter obj) throws Exception
			{
				Boolean bLoginFlag = false;	
				log.info("Execution of Function TC31911 Started..");
				
		
				try {
							
						obj.repAddData( "View Items", "", "", "");
						fnSelectCorpOffice(sCorporation, sOffice);
						ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
												
						WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("./thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,0,"Item Name");
						fnVerifyHeaders(arrHeaderColumns,1,"Row Type");
						fnVerifyHeaders(arrHeaderColumns,2,"GL Code");
						fnVerifyHeaders(arrHeaderColumns,3,"Default Material");
						fnVerifyHeaders(arrHeaderColumns,4,"Default Labor");
						fnVerifyHeaders(arrHeaderColumns,5,"Required");
					
						HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Items");
						boolean bCopyEditDelete = true;
						boolean bCheckBox = true;
						int iRow = 0;
						for(iRow=1;iRow<=mTableData.size();iRow++)
						{
							String[] arrCopyEditDelete = mTableData.get(iRow).get(7).toString().trim().split(";;");
							if(!arrCopyEditDelete[0].toString().trim().equalsIgnoreCase("Copy") && !arrCopyEditDelete[1].toString().trim().equalsIgnoreCase("Edit") && !arrCopyEditDelete[2].toString().trim().equalsIgnoreCase("Delete"))
							{
								bCopyEditDelete = false;
								break;
							}
							
							if(!mTableData.get(iRow).get(8).toString().trim().equalsIgnoreCase("checkbox"))
							{
								bCheckBox = false;
								break;
							}
						
						}
						
						if(bCopyEditDelete==true && bCheckBox==true)
						{
							obj.repAddData( "Verify Copy, Edit, Delete and Checkbox Options", "Copy, Edit, Delete and Checkbox Options should be displayed in front of each row", "Copy, Edit, Delete and Checkbox Options are displayed in front of each row", "Pass");
						}
						else
						{
							obj.repAddData( "Verify Copy, Edit, Delete and Checkbox Options", "Copy, Edit, Delete and Checkbox Options should be displayed in front of each row", "Copy, Edit, Delete and Checkbox Options are not displayed for row = "+iRow, "Fail");
						}
				}
				
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31911 Failed!", e );
				}
				finally {
					
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC31911 Completed");
				}
				return obj;
			} //End of function TC31911	
			
			
			//RW-225_Items_TC005_View Items_Verify ADD ITEM option
			@SuppressWarnings("static-access")
			public Reporter TC31912(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31912 Started..");

				try {
							
					obj.repAddData( "Availability of DELETE SELECTED button", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnDeleteSelected_xp,"'DELETE SELECTED' button",true,true);
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31912 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31912 Completed");
				}
				return obj;
			} //End of function TC31912	
			
			//RW-225_Items_TC005_View Items_Verify ADD ITEM option
			@SuppressWarnings("static-access")
			public Reporter TC31913(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31913 Started..");

				try {
							
					obj.repAddData( "Availability of ADD ITEM button", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31913 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31913 Completed");
				}
				return obj;
			} //End of function TC31913	
			
			
			//RW-225_Items_TC006_View Items_Verify no items for no property
			@SuppressWarnings("static-access")
			public Reporter TC31914(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31914 Started..");

				try {
							
					obj.repAddData( "Verify No Items for No Property", "", "", "");
					/*fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();*/
					
					//Write Code here once no property is there 

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31914 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31914 Completed");
				}
				return obj;
			} //End of function TC31914	
			
			//RW-225_Items_TC007_View Items_Verify table heading displayed by default
			@SuppressWarnings("static-access")
			public Reporter TC31915(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31915 Started..");

				try {
							
					obj.repAddData( "Verify table heading displayed by default", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_LabelCurrentItems_xp,"'Current Items' label",true,true);
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31915 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31915 Completed");
				}
				return obj;
			} //End of function TC31915	
			
			//RW-225_Items_TC008_View Items_Verify loading icon
			@SuppressWarnings("static-access")
			public Reporter TC31916(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31916 Started..");

				try {
							
					obj.repAddData( "Verify loading icon", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();			//Currently not coming. loading icon should come on every click on left hand side. Defect already raised.

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31916 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31916 Completed");
				}
				return obj;
			} //End of function TC31916	
			
			
			//RW-225_Items_TC009_View Items_Availability of Pagination options
			@SuppressWarnings("static-access")
			public Reporter TC31917(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31917 Started..");

				try {
							
					obj.repAddData( "Availability of Pagination Options", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31917 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31917 Completed");
				}
				return obj;
			} //End of function TC31917	
			
			
			//RW-225_Items_TC010_View Items_Validate Current Items table using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC31918(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31918 Started..");

				try {
							
					obj.repAddData( "Items Table Count for VIEW ALL Option", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					//driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
					//Write DB code here
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31918 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31918 Completed");
				}
				return obj;
			} //End of function TC31918	
			

			
			//RW-225_Items_TC011_View Items_Validate Pagination for option 10 for current page
			@SuppressWarnings("static-access")
			public Reporter TC31919(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31919 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 10", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31919 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31919 Completed");
				}
				return obj;
			} //End of function TC31919	
			
			//RW-225_Items_TC012_View Items_Validate Pagination for option 10 for all the pages
			@SuppressWarnings("static-access")
			public Reporter TC31920(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31920 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 10", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
									
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE' and verify all pages", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");  //First time validation
					
					boolean bMultiPageExists = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", false,true);
					if(bMultiPageExists==true)
					{
						int iCurrentPage = 1;
						String sTotalPages = fnGetGUITextXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp);
						while(iCurrentPage<Integer.parseInt(sTotalPages))
						{
							ClickByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "Next button", false);
							fnVerifyNumofRecords("10");
							iCurrentPage++;
						}
					}
					else
					{
						obj.repAddData( "Verify Pagination for all pages", "Pagination for all pages with option 10 should be validated", "Pagination for all pages with option 10 cannot be validated as no of records are less than 10", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31920 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31920 Completed");
				}
				return obj;
			} //End of function TC31920	
			
		
			//RW-225_Items_TC013_View Items_Validate Pagination for option 10 with specific page
			@SuppressWarnings("static-access")
			public Reporter TC31921(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31921 Started..");

				try {
							
					obj.repAddData("Validate pagination for any specific page with option 10", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					//fnVerifyNumofRecords("10");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp); 
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						int iRandomNum = fnRandomNum(1,iTotalPageNum);
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iRandomNum),"Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 10", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
					fnVerifyNumofRecords("10");
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31921 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31921 Completed");
				}
				return obj;
			} //End of function TC31921	
			

			//RW-225_Items_TC014_View Items_Validate Pagination for option 20 for current page
			@SuppressWarnings("static-access")
			public Reporter TC31922(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31922 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 20", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("20");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31922 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31922 Completed");
				}
				return obj;
			} //End of function TC31922	
			
			//RW-225_Items_TC015_View Items_Validate Pagination for option 20 for all the pages
			@SuppressWarnings("static-access")
			public Reporter TC31923(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31923 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 20", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
									
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE' and verify all pages", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("20");  //First time validation
					
					boolean bMultiPageExists = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", false,true);
					if(bMultiPageExists==true)
					{
						int iCurrentPage = 1;
						String sTotalPages = fnGetGUITextXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp);
						while(iCurrentPage<Integer.parseInt(sTotalPages))
						{
							ClickByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "Next button", false);
							fnVerifyNumofRecords("20");
							iCurrentPage++;
						}
					}
					else
					{
						obj.repAddData( "Verify Pagination for all pages", "Pagination for all pages with option 20 should be validated", "Pagination for all pages with option 20 cannot be validated as no of records are less than 20", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31923 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31923 Completed");
				}
				return obj;
			} //End of function TC31923	
			
		
			//RW-225_Items_TC016_View Items_Validate Pagination for option 20 with specific page
			@SuppressWarnings("static-access")
			public Reporter TC31924(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31924 Started..");

				try {
							
					obj.repAddData("Validate pagination for any specific page with option 20", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					//fnVerifyNumofRecords("20");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp); 
					
					if(bElementFound==true || iRows>20)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						int iRandomNum = fnRandomNum(1,iTotalPageNum);
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iRandomNum),"Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 20", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}
					
					fnVerifyNumofRecords("20");
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31924 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31924 Completed");
				}
				return obj;
			} //End of function TC31924	
			
		
			//RW-225_Items_TC017_View Items_Validate for Page Counter and Navigation
			@SuppressWarnings("static-access")
			public Reporter TC31925(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31925 Started..");

				try {
							
					obj.repAddData("Validate Page Counter and Navigation", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items Link",true);
					fnLoadingPageWait();	
		
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);
					
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option '10 PER PAGE' should be validated", "Pagination with option '10 PER PAGE' cannot be validated as no of records are less than 10", "Pass");
					}
					
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					if(bElementFound==true || iRows>20)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option '20 PER PAGE' should be validated", "Pagination with option '20 PER PAGE' cannot be validated as no of records are less than 20", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31925 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31925 Completed");
				}
				return obj;
			} //End of function TC31925	
			
			
			//Spencer Tests
			//Add Item
			
			//RW-239_Items_TC001_ADD ITEM_Verify ADD ITEM view
			@SuppressWarnings("static-access")
			public Reporter TC37193(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37193 Started..");

				try {
							
					obj.repAddData( "Verify Add Item Page View", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					obj.repAddData( "Navigated successfully to Add Item page, verifying all fields now...", "", "", "");
					///Check all Add Item fields
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_ItemName_nm,"Name",true,true);
					//Row Type
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_RowTypeSelector_nm,"Row Type",true,true);
					//Required check box
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_RequiredCheckbox_nm,"Required",true,true);
					//Non-budget Item check box
					fnCheckFieldDisplayById(RenowalkModules.Items_AddItem_NonBudgetCheckbox_id,"Non-Budget Item",true,true);
					//Default Material
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_DefaultMaterial_nm,"Default Material",true,true);
					//Default Labor
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_DefaultLabor_nm,"Default Labor",true,true);
					//Default Hours
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_DefaultHours_nm,"Default Hours",true,true);
					//GL Code
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_GLCode_nm, "GL Code",true,true);
					//Category
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_Category_nm, "Category",true,true);
					//Sub Category
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_Subcategory_nm, "Subcategory",true,true);
					//Comments
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					//Products
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_ProductsPanelHeader_xp,"Products:",true,true);
					obj.repAddData("Found all objects. Closing form.", "", "", "");
					
					//Cancel Post Condition
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37193 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35862 Completed");
				}
				return obj;
			}
			//End of function TC37193
			
			//RW-239_Items_TC002_ADD ITEM_Verify the Row Type values
			@SuppressWarnings("static-access")
			public Reporter TC37194(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37194 Started..");

				try {
							
					obj.repAddData( "Verify Add Item Row Type values", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					obj.repAddData( "Navigated successfully to Add Item page, verifying row type fields now...", "", "", "");
					//Row Type
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_RowTypeSelector_nm,"Row Type",true,true);
					HighlightElementByName(objRWModules.Items_AddItem_RowTypeSelector_nm);
					Select select = new Select(driver.findElement(By.name(objRWModules.Items_AddItem_RowTypeSelector_nm)));
					List<WebElement> arrRowTypes = select.getOptions();
					//System.out.println("Row Type Option>>>>"+arrRowTypes.size());
					fnVerifyComboBoxValues(arrRowTypes, 1, "Always Added");
					fnVerifyComboBoxValues(arrRowTypes, 2, "Basic Comment");
					fnVerifyComboBoxValues(arrRowTypes, 3, "Default Package Kit");
					fnVerifyComboBoxValues(arrRowTypes, 4, "Increment Row Type");
					fnVerifyComboBoxValues(arrRowTypes, 5, "Multiple Sku Display");
					fnVerifyComboBoxValues(arrRowTypes, 6, "Optional Increment Row Type");
					fnVerifyComboBoxValues(arrRowTypes, 7, "Package Row Type");
					fnVerifyComboBoxValues(arrRowTypes, 8, "Tenant Only");
					fnVerifyComboBoxValues(arrRowTypes, 9, "Whole Budget Percent");
					fnVerifyComboBoxValues(arrRowTypes, 10, "Whole House SqFT");
					//Cancel out
					obj.repAddData("Found all Row Type options. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37194 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC37194 Completed");
				}
				return obj;
			}
			//End of Function 37194
			
			//37195 through 37204 (10 items) begin
			//RW-239_Items_TC003_ADD ITEM_Verify Prompt for required fields_Always Added Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37195(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37195 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Always Added type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Always Added");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					String sDefaultMaterial, sDefaultLabor = new String();
					sDefaultMaterial = sDefaultLabor = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgDefaultMaterialRequired_xp, "Default Material Error Message", true, true);

					String sDefaultMaterialMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgDefaultMaterialRequired_xp)).getText().toString().trim();
					if(sDefaultMaterialMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Default Material Required error message.", "", "", "");
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgDefaultLaborRequired_xp, "Default Labor Error Message", true, true);
					
					String sDefaultLaborMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgDefaultLaborRequired_xp)).getText().toString().trim();
					if(sDefaultLaborMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);;
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37195 Failed!", e );
				}
				return obj;
			}
			//End of Function 37195
			//RW-239_Items_TC004_ADD ITEM_Verify Prompt for required fields_Basic Comment Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37196(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37196 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Basic Comment type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Basic Comment");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					String sDefaultMaterial, sDefaultLabor = new String();
					sDefaultMaterial = sDefaultLabor = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgDefaultMaterialRequired_xp, "Default Material Error Message", true, true);

					String sDefaultMaterialMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgDefaultMaterialRequired_xp)).getText().toString().trim();
					if(sDefaultMaterialMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Default Material Required error message.", "", "", "");
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgDefaultLaborRequired_xp, "Default Labor Error Message", true, true);
					
					String sDefaultLaborMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgDefaultLaborRequired_xp)).getText().toString().trim();
					if(sDefaultLaborMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);;
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37196 Failed!", e );
				}
				return obj;
			}
			//End of Function 37196
			//RW-239_Items_TC005_ADD ITEM_Verify Prompt for required fields_Default Package Kit Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37197(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37197 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Default Package Kit type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Default Package Kit");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Select");
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp, "Row Type Required error message", true, true);
					
					String sRowTypeMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp)).getText().toString().trim();
					if(sRowTypeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Row Type Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);;
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37197 Failed!", e );
				}
				return obj;
			}
			//End of Function 37197
			//RW-239_Items_TC006_ADD ITEM_Verify Prompt for required fields_Increment Row Type Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37198(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37198 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Increment Row type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Increment Row Type");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					String sDefaultMaterial, sDefaultLabor = new String();
					sDefaultMaterial = sDefaultLabor = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgDefaultMaterialRequired_xp, "Default Material Error Message", true, true);

					String sDefaultMaterialMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgDefaultMaterialRequired_xp)).getText().toString().trim();
					if(sDefaultMaterialMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Default Material Required error message.", "", "", "");
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgDefaultLaborRequired_xp, "Default Labor Error Message", true, true);
					
					String sDefaultLaborMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgDefaultLaborRequired_xp)).getText().toString().trim();
					if(sDefaultLaborMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Select");
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp, "Row Type Required error message", true, true);
					
					String sRowTypeMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp)).getText().toString().trim();
					if(sRowTypeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);;
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37198 Failed!", e );
				}
				return obj;
			}
			//End of Function 37198
			//RW-239_Items_TC007_ADD ITEM_Verify Prompt for required fields_Multiple SKU Display Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37199(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37199 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Multiple SKU Display type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Multiple Sku Display");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Select");
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp, "Row Type Required error message", true, true);
					
					String sRowTypeMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp)).getText().toString().trim();
					if(sRowTypeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Row Type Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);;
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37199 Failed!", e );
				}
				return obj;
			}
			//End of Function 37199
			//RW-239_Items_TC008_ADD ITEM_Verify Prompt for required fields_Optional Incremental Row Type Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37200(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37200 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Optional Increment Row type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Optional Increment Row Type");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Select");
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp, "Row Type Required error message", true, true);
					
					String sRowTypeMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp)).getText().toString().trim();
					if(sRowTypeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);;
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37200 Failed!", e );
				}
				return obj;
			}
			//End of Function 37200
			//RW-239_Items_TC009_ADD ITEM_Verify Prompt for required fields_Package Row Type Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37201(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37201 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Package Row type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Package Row Type");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Select");
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp, "Row Type Required error message", true, true);
					
					String sRowTypeMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgRowTypeRequired_xp)).getText().toString().trim();
					if(sRowTypeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37201 Failed!", e );
				}
				return obj;
			}
			//End of Function 37201
			//RW-239_Items_TC010_ADD ITEM_Verify Prompt for required fields_Tenant Only Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37202(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37202 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Tenant Only type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Tenant Only");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					String sDefaultMaterial, sDefaultLabor = new String();
					sDefaultMaterial = sDefaultLabor = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgDefaultMaterialRequired_xp, "Default Material Error Message", true, true);

					String sDefaultMaterialMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgDefaultMaterialRequired_xp)).getText().toString().trim();
					if(sDefaultMaterialMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Default Material Required error message.", "", "", "");
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgDefaultLaborRequired_xp, "Default Labor Error Message", true, true);
					
					String sDefaultLaborMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgDefaultLaborRequired_xp)).getText().toString().trim();
					if(sDefaultLaborMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37202 Failed!", e );
				}
				return obj;
			}
			//End of Function 37202
			//RW-239_Items_TC011_ADD ITEM_Verify Prompt for required fields_Whole Budget Percent Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37203(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37203 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Whole Budget Percent Row type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Whole Budget Percent");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					String sDefaultPercent = new String();
					sDefaultPercent = Integer.toString(fnRandomNum( 1, 90));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_BudgetPercent_nm, "Budget Percent text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_BudgetPercent_nm)).sendKeys(sDefaultPercent);
					driver.findElement(By.name(objRWModules.Items_AddItem_BudgetPercent_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgBudgetPercentRequired_xp, "Default Material Error Message", true, true);

					String sDefaultMaterialMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgBudgetPercentRequired_xp)).getText().toString().trim();
					if(sDefaultMaterialMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Default Material Required error message.", "", "", "");
					
					//Cancel out
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37203 Failed!", e );
				}
				return obj;
			}
			//End of Function 37203
			//RW-239_Items_TC012_ADD ITEM_Verify Prompt for required fields_Whole House SqFT Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37204(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37204 Started..");
				try {
					
					obj.repAddData( "Verify Add Item required texts for Whole House SqFT Row Type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Whole House SqFT");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp, "Item name Error Message", true, true);

					String sItemNameMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgItemNameRequired_xp)).getText().toString().trim();
					if(sItemNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Item Name Required error message.", "", "", "");
					
					String sMaterialRate, sLaborRate = new String();
					sMaterialRate = sLaborRate = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MaterialRate_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_MaterialRate_nm)).sendKeys(sMaterialRate);
					driver.findElement(By.name(objRWModules.Items_AddItem_MaterialRate_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgMaterialRateRequired_xp, "Material Rate Error Message", true, true);

					String sMaterialRateMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgMaterialRateRequired_xp)).getText().toString().trim();
					if(sMaterialRateMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					obj.repAddData("Verified Default Material Required error message.", "", "", "");
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_LaborRate_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_LaborRate_nm)).sendKeys(sLaborRate);
					driver.findElement(By.name(objRWModules.Items_AddItem_LaborRate_nm)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_ErrorMsgLaborRateRequired_xp, "Labor Rate Error Message", true, true);
					
					String sLaborRateMsg = driver.findElement(By.xpath(objRWModules.Items_AddItem_ErrorMsgLaborRateRequired_xp)).getText().toString().trim();
					if(sLaborRateMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					
					
					//Cancel out
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);
					ClickByXpath(objRWModules.Common_CancelModule_BtnYes,"Cancel Confirm",false);
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37204 Failed!", e );
				}
				return obj;
			}
			//End of Function 37204
			//37195 through 37204 (10 items) end
			//37212 through 37229 (10 items, not consecutive) begin SAVE functions
			//RW-239_Items_TC021_ADD ITEM_Verify SAVE for ADD ITEM Always Added Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37212(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37212 Started..");
				try {
					
					obj.repAddData( "Verify Save New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Always Added");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37212 Failed!", e );
				}
				return obj;
			}
			//End of Function 37212
			//RW-239_Items_TC019_ADD ITEM_Verify SAVE for ADD ITEM Basic Comment Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37213(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37213 Started..");
				try {
					
					obj.repAddData( "Verify Save New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Basic Comment");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37213 Failed!", e );
				}
				return obj;
			}
			//End of Function 37213
			
			@SuppressWarnings("static-access")
			public Reporter TC37215(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37215 Started..");
				try {
					
					obj.repAddData( "Verify Save New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Default Package Kit");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37215 Failed!", e );
				}
				return obj;
			}
			//End of Function 37215
			
			@SuppressWarnings("static-access")
			public Reporter TC37217(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37217 Started..");
				try {
					
					obj.repAddData( "Verify Save New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Increment Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37217 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37217
			@SuppressWarnings("static-access")
			public Reporter TC37219(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37219 Started..");
				try {
					
					obj.repAddData( "Verify Save New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Multiple Sku Display");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37219 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37219
			@SuppressWarnings("static-access")
			public Reporter TC37221(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37221 Started..");
				try {
					
					obj.repAddData( "Verify Save New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Optional Increment Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37221 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37221
			@SuppressWarnings("static-access")
			public Reporter TC37223(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37223 Started..");
				try {
					
					obj.repAddData( "Verify Save New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Package Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37223 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37223
			@SuppressWarnings("static-access")
			public Reporter TC37225(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37225 Started..");
				try {
					
					obj.repAddData( "Verify Save New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Tenant Only");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37225 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37225
			@SuppressWarnings("static-access")
			public Reporter TC37227(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37227 Started..");
				try {
					
					obj.repAddData( "Verify Add Item saves for Whole Budget Percent Row type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Whole Budget Percent");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					
					String sDefaultPercent = new String();
					sDefaultPercent = Integer.toString(fnRandomNum( 1, 90));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_BudgetPercent_nm, "Budget Percent text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_BudgetPercent_nm)).sendKeys(sDefaultPercent);
					
					
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37227 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37227
			@SuppressWarnings("static-access")
			public Reporter TC37229(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37229 Started..");
				try {
					
					obj.repAddData( "Verify Add Item saves for Whole House SqFT Row Type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Whole House SqFT");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					
					String sMaterialRate, sLaborRate = new String();
					sMaterialRate = sLaborRate = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MaterialRate_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_MaterialRate_nm)).sendKeys(sMaterialRate);
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_LaborRate_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_LaborRate_nm)).sendKeys(sLaborRate);	
					
					//Save Item, Click Yes
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37229 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37229
			//37212 through 37229 (10 items, not consecutive) begin SAVE functions
			
			//RW-239_Items_TC029_ADD ITEM_Verify CANCEL (Discard) for ADD ITEM Always Added Row Type
			@SuppressWarnings("static-access")
			public Reporter TC37231(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37231 Started..");
				try {
					
					obj.repAddData( "Verify Add Item Page View", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Always Added");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Check DB to ensure object was NOT saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37231 Failed!", e );
				}
				return obj;
			}
			//End of Function 37231
			
			@SuppressWarnings("static-access")
			public Reporter TC37249(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37249 Started..");
				try {
					
					obj.repAddData( "Verify Add Item Page View", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Always Added");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					
					//Cancel out, then click No when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Check DB to ensure object was NOT saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37249 Failed!", e );
				}
				return obj;
			}
			//End of Function 37250
			
			@SuppressWarnings("static-access")
			public Reporter TC37232(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37232 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Basic Comment");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item appears in UI after saving (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37232 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37232
			
			@SuppressWarnings("static-access")
			public Reporter TC37250(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37250 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Not Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Basic Comment");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after cancelling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37250 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37250
			
			@SuppressWarnings("static-access")
			public Reporter TC37234(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37234 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Default Package Kit");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37234 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37234
			
			@SuppressWarnings("static-access")
			public Reporter TC37251(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37251 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Not Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Default Package Kit");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click No when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37251 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37234
			
			@SuppressWarnings("static-access")
			public Reporter TC37236(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37236 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Increment Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item does not appear in UI after cancelling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37236 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37236
			
			@SuppressWarnings("static-access")
			public Reporter TC37252(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37252 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Not Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Increment Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37252 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37236
			
			@SuppressWarnings("static-access")
			public Reporter TC37238(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37238 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Multiple Sku Display");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37238 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37238
			
			@SuppressWarnings("static-access")
			public Reporter TC37253(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37253 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Not Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Multiple Sku Display");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click No when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37253 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37253
			
			@SuppressWarnings("static-access")
			public Reporter TC37240(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37240 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Optional Increment Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37240 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37240
			
			@SuppressWarnings("static-access")
			public Reporter TC37254(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37254 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Not Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Optional Increment Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click No when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37254 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37254
			
			@SuppressWarnings("static-access")
			public Reporter TC37242(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37242 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Package Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37242 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37242
			
			@SuppressWarnings("static-access")
			public Reporter TC37255(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37255 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Not Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Package Row Type");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					//Generate and input Default Int
					String sDefaultInt = new String();
					sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click No when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37255 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37255
			
			@SuppressWarnings("static-access")
			public Reporter TC37244(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37244 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Tenant Only");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37244 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37244
			
			@SuppressWarnings("static-access")
			public Reporter TC37256(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37256 Started..");
				try {
					
					obj.repAddData( "Verify Cancel (Not Discard) New Item", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Tenant Only");
					
					//Enter and clear name field
					
					String sDefaultString = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sDefaultString);
					
					//Click and verify checkboxes
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxRequired_xp,"Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox",true);
					fnCheckSelectedCheckBoxByXPath(RenowalkModules.Items_AddItem_NonBudgetCheckbox_xp,"Non-Budget checkbox");
					
					ClickByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_AddItem_PriceOverride_xp,"Price Override Box",true,true);
					
					//Generate and input Default Material, Default labor and Default Hours amounts
					String sDefaultMaterial, sDefaultLabor, sDefaultHours, sDefaultInt = new String();
					sDefaultMaterial = sDefaultLabor = sDefaultHours = sDefaultInt = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultMaterial_nm)).sendKeys(sDefaultMaterial);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultLabor_nm)).sendKeys(sDefaultLabor);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm, "Default Hours text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_DefaultHours_nm)).sendKeys(sDefaultHours);
					
					//Input default string data for GLCode and Category
					driver.findElement(By.name(objRWModules.Items_AddItem_GLCode_nm)).sendKeys(sDefaultString);
					driver.findElement(By.name(objRWModules.Items_AddItem_Category_nm)).sendKeys(sDefaultString);
					
					//Open and Add a Comment
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_ItemComment_nm)).sendKeys(sDefaultString);
					ClickByName(RenowalkModules.Items_AddItem_RateNameComment_nm,"Rate Name",true);
					driver.findElement(By.name(RenowalkModules.Items_AddItem_RateNameComment_nm)).sendKeys(sDefaultInt);
					ClickByXpath(RenowalkModules.Items_AddItem_BtnAddComment_xp,"Add New Comment",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_SecondItemComment_nm,"New comment box",true,true);
					
					//Cancel out, then click No when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37256 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37256
			
			@SuppressWarnings("static-access")
			public Reporter TC37246(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37246 Started..");
				try {
					
					obj.repAddData( "Verify Add Item Cancel (Discard) for Whole Budget Percent Row type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Whole Budget Percent");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					
					String sDefaultPercent = new String();
					sDefaultPercent = Integer.toString(fnRandomNum( 1, 90));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_BudgetPercent_nm, "Budget Percent text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_BudgetPercent_nm)).sendKeys(sDefaultPercent);
					
					
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37246 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37246
			
			@SuppressWarnings("static-access")
			public Reporter TC37257(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37257 Started..");
				try {
					
					obj.repAddData( "Verify Add Item Cancel (Not Discard) for Whole Budget Percent Row type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Whole Budget Percent");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					
					String sDefaultPercent = new String();
					sDefaultPercent = Integer.toString(fnRandomNum( 1, 90));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_BudgetPercent_nm, "Budget Percent text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_BudgetPercent_nm)).sendKeys(sDefaultPercent);
					
					
					
					//Cancel out, then click No when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37257 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37257
			
			@SuppressWarnings("static-access")
			public Reporter TC37248(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37248 Started..");
				try {
					
					obj.repAddData( "Verify Add Item Cancel (Discard) for Whole House SqFT Row Type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Whole House SqFT");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					
					String sMaterialRate, sLaborRate = new String();
					sMaterialRate = sLaborRate = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MaterialRate_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_MaterialRate_nm)).sendKeys(sMaterialRate);
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_LaborRate_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_LaborRate_nm)).sendKeys(sLaborRate);	
					
					//Cancel out, then click Yes when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(1);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37248 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37248
			
			@SuppressWarnings("static-access")
			public Reporter TC37258(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC37258 Started..");
				try {
					
					obj.repAddData( "Verify Add Item Cancel (Not Discard) for Whole House SqFT Row Type", "", "", "");
					//Set Corp and Office, load Item page
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp, "Items",true);
					fnLoadingPageWait();
					//To Add Item page
					fnCheckFieldDisplayByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp,"'ADD ITEM' button",true,true);
					ClickByXpath(RenowalkModules.Items_ViewItem_BtnAddItem_xp, "ADD ITEM",true);
					
					fnSelectFromComboBoxXpath(RenowalkModules.Items_AddItem_ComboRowType_xp,"Whole House SqFT");
					
					//Enter and clear name field
					
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_InputItemName_xp, "Item Name text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Items_AddItem_InputItemName_xp)).sendKeys(sItemName);
					
					String sMaterialRate, sLaborRate = new String();
					sMaterialRate = sLaborRate = Integer.toString(fnRandomNum( 2, 20));
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MaterialRate_nm, "Default Material text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_MaterialRate_nm)).sendKeys(sMaterialRate);
					
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_LaborRate_nm, "Default Labor text box", true, true);
					driver.findElement(By.name(objRWModules.Items_AddItem_LaborRate_nm)).sendKeys(sLaborRate);	
					
					//Cancel out, then click No when prompted
					obj.repAddData("Verified Default Labor Required error message. Closing form.", "", "", "");
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true);
					fnVerifyCancelForm(0);
					
					//Verify item does not appear in UI after canceling (if using fnVerify 1 flag)
					//Check DB to ensure object was saved or stored in any way
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC37258 Failed!", e );
				}
				return obj;
			}
			//End of Function TC37258
			
			
			///////////////////////////////////////Items Tests End Here///////////////////////////////////////////////////////////////////////////////
			///////////////////////////////////////Product Tier Tests Starts Here///////////////////////////////////////////////////////////////////////////

			//View Product Tier

			//RW-90_Product Tiers_TC001_View existing Product Tiers_View list of product tiers
			@SuppressWarnings("static-access")
			public Reporter TC31888(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31888 Started..");

				try {

					obj.repAddData( "Viewing the Product Tiers", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					fnSelectFromComboBoxXpath(objRWModules.Common_ViewModules_ComboPageSize_xp, "VIEW ALL");
					fnLoadingPageWait();
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Product Tiers");
					fnCheckSortedList(mTableData,"Product Tiers",1);
					System.out.println("Sorted Functionality Tested Successfully");
					////////////////////Sorting Logic End////////////////////////////

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31888 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31888 Completed");
				}
				return obj;
			} //End of function TC31888	


			//RW-90_Product Tiers_TC002_View existing Product Tiers_Options to Add Product Tier
			@SuppressWarnings("static-access")
			public Reporter TC31889(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31889 Started..");

				try {

					obj.repAddData( "Availability of Add Product Tier option", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					fnCheckFieldDisplayByXpath(RenowalkModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp,"'Add Product Tier' button",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp)));

					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("./thead/tr/th"));  //Get the header
					System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
					fnVerifyHeaders(arrHeaderColumns,0,"Product Tier Name");  //There is one improvement RW-286. Once implemented, change it to Product Tier

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31889 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31889 Completed");
				}
				return obj;
			} //End of function TC31889	


			//RW-90_Product Tiers_TC003_View existing Product Tiers_Options to edit or delete
			@SuppressWarnings("static-access")
			public Reporter TC31890(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31890 Started..");

				try {

					obj.repAddData( "Availability of Edit and Delete Options", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					fnSelectFromComboBoxXpath(objRWModules.Common_ViewModules_ComboPageSize_xp, "VIEW ALL");
					fnLoadingPageWait();

					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Product Tiers");
					boolean bEditDelete = true;
					int iRow = 0;
					System.out.println("mTableData.keySet().size()>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+mTableData.keySet().size());
					for(iRow=1;iRow<=mTableData.size();iRow++)
					{
						String[] arrEditDelete = mTableData.get(iRow).get(2).toString().trim().split(";;");
						if(!arrEditDelete[0].toString().trim().equalsIgnoreCase("Edit") && !arrEditDelete[1].toString().trim().equalsIgnoreCase("Delete"))
						{
							bEditDelete = false;
							break;
						}

					}

					if(bEditDelete==true)
					{
						obj.repAddData( "Verify Edit and Delete Options", "Edit and Delete Options should be displayed in front of each row", "Edit and Delete Options are displayed in front of each row", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Edit and Delete Options", "Edit and Delete Options should be displayed in front of each row", "Edit and Delete Options are not displayed for row = "+iRow, "Fail");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31890 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31890 Completed");
				}
				return obj;
			} //End of function TC31890	


			//RW-90_Product Tiers_TC004_View existing Product Tiers_Prompt to select office
			@SuppressWarnings("static-access")
			public Reporter TC31891(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31891 Started..");

				try {

					obj.repAddData( "Verify Select Office Prompt", "", "", "");
					//fnSelectFromComboBoxXpath(objRWModules.Common_AllModules_ComboCorporateName_xp, "Select");
					//fnVerifyDialogBox("OfficeCode", 1);
					fnSelectCorpOffice("Select", sOffice);
					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnVerifyDialogBox("OfficeCode", 1);

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31891 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31891 Completed");
				}
				return obj;
			} //End of function TC31891	

			//RW-90_Product Tiers_TC005_View existing Product Tiers_Availability of Pagination options
			@SuppressWarnings("static-access")
			public Reporter TC31892(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31892 Started..");

				try {

					obj.repAddData( "Availability of Pagination Options", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();


					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31892 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31892 Completed");
				}
				return obj;
			} //End of function TC31892	

			//RW-90_Product Tiers_TC006_View existing Product Tiers_Validate Current Product Tiers table using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC31893(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31893 Started..");

				try {

					obj.repAddData( "Product Tier Table Count for VIEW ALL Option", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());

					//Write DB code here

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31893 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31893 Completed");
				}
				return obj;
			} //End of function TC31893	


			//RW-90_Product Tiers_TC007_View existing Product Tiers_Validate Pagination for option 10 for current page
			@SuppressWarnings("static-access")
			public Reporter TC31894(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31894 Started..");

				try {

					obj.repAddData("Validate Pagination for Option 10 for current page", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");


					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31894 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31894 Completed");
				}
				return obj;
			} //End of function TC31894	

			//RW-90_Product Tiers_TC008_View existing Product Tiers_Validate Pagination for option 10 for all the pages
			@SuppressWarnings("static-access")
			public Reporter TC31895(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31895 Started..");

				try {

					obj.repAddData("Validate pagination for any page with option 10 for all the pages", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");

					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);

					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 10", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}

					fnVerifyNumofRecords("10");

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31895 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31895 Completed");
				}
				return obj;
			} //End of function TC31895	

			//RW-90_Product Tiers_TC009_View existing Product Tiers_Validate Pagination for option 10 with specific page
			@SuppressWarnings("static-access")
			public Reporter TC31896(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31896 Started..");

				try {

					obj.repAddData("Validate pagination for any page with option 10 with specific page", "", "", "");


					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");

					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);

					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 10", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}

					fnVerifyNumofRecords("10");

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31896 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31896 Completed");
				}
				return obj;
			} //End of function TC31896	


			//RW-90_Product Tiers_TC010_View existing Product Tiers_Validate Pagination for option 20 for current page
			@SuppressWarnings("static-access")
			public Reporter TC31897(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31897 Started..");

				try {

					obj.repAddData("Validate Pagination for Option 20 for current page", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("20");


					if(bElementFound==true || iRows>20)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31897 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31897 Completed");
				}
				return obj;
			} //End of function TC31897	

			//RW-90_Product Tiers_TC011_View existing Product Tiers_Validate Pagination for option 20 for all the pages
			@SuppressWarnings("static-access")
			public Reporter TC31898(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31898 Started..");

				try {

					obj.repAddData("Validate pagination for any page with option 20 for all the pages", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("20");

					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);

					if(bElementFound==true || iRows>20)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 20", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}

					fnVerifyNumofRecords("20");

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31898 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31898 Completed");
				}
				return obj;
			} //End of function TC31898	

			//RW-90_Product Tiers_TC012_View existing Product Tiers_Validate Pagination for option 20 with specific page
			@SuppressWarnings("static-access")
			public Reporter TC31899(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31899 Started..");

				try {

					obj.repAddData("Validate pagination for any page with option 20 with specific page", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("20");

					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);

					if(bElementFound==true || iRows>20)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 20", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}

					fnVerifyNumofRecords("20");

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31896 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31896 Completed");
				}
				return obj;
			} //End of function TC31896	


			//RW-90_Product Tiers_TC013_View existing Product Tiers_Validate for Page Counter and Navigation
			@SuppressWarnings("static-access")
			public Reporter TC31900(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31900 Started..");

				try {

					obj.repAddData("Validate Page Counter and Navigation", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());

					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);

					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option '10 PER PAGE' should be validated", "Pagination with option '10 PER PAGE' cannot be validated as no of records are less than 10", "Pass");
					}


				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31900 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31900 Completed");
				}
				return obj;
			} //End of function TC31900	

			//RW-90_Product Tiers_TC014_View existing Product Tiers_Loading icon shown
			@SuppressWarnings("static-access")
			public Reporter TC31901(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31901 Started..");

				try {

					obj.repAddData("Verify Loading Icon when page loads", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31901 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31901 Completed");
				}
				return obj;
			} //End of function TC31901	

			//RW-91_Product Tiers_TC001_Add Product Tier_Verify the prompt for ADD PRODUCT TIER
			@SuppressWarnings("static-access")
			public Reporter TC31903(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31903 Started..");

				try {

					obj.repAddData( "Adding the Product Tier", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					fnCheckFieldDisplayById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id,"Product Tier text box", true, true);
					HighlightElementById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id);
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31903 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31903 Completed");
				}
				return obj;
			} //End of function TC31903	

			//RW-91_Product Tiers_TC002_Add Product Tier_Verify Name field
			@SuppressWarnings("static-access")
			public Reporter TC31904(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31904 Started..");

				try {

					obj.repAddData( "Validating the Product Tier", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					fnCheckFieldDisplayById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id,"Product Tier text box", true, true);
					HighlightElementById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id);

					String sProductTier = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					//SendKeyById(objRWModules.Corporations_AddCorporation_InputCorpName_id, sName);
					driver.findElement(By.id(objRWModules.ProductTiers_AddProductTier_InputProductTier_id)).sendKeys(sProductTier);
					driver.findElement(By.id(objRWModules.ProductTiers_AddProductTier_InputProductTier_id)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgRequired_xp,"Required Error Message", true, true);
					HighlightElementByXpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgRequired_xp);
					String sErrorMsg = driver.findElement(By.xpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgRequired_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}

					//*This field is required

					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31904 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31904 Completed");
				}
				return obj;
			} //End of function TC31904	


			//RW-91_Product Tiers_TC003_Add Product Tier_Verify current product tier display
			@SuppressWarnings("static-access")
			public Reporter TC31905(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31905 Started..");

				try {

					obj.repAddData( "Viewing the Product Tiers", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();


					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Product Tiers");
					fnCheckSortedList(mTableData,"Name",1);
					System.out.println("Sorted Functionality Tested Successfully");
					////////////////////Sorting Logic End////////////////////////////

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31905 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31905 Completed");
				}
				return obj;
			} //End of function TC31905	

			//RW-91_Product Tiers_TC004_Add Product Tier_Save Product Tier Name
			@SuppressWarnings("static-access")
			public Reporter TC31906(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31906 Started..");

				try {

					obj.repAddData( "Add and Save a Product Tier", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();


					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					fnCheckFieldDisplayById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id,"Product Tier text box", true, true);
					HighlightElementById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id);

					int iRandomNum = fnRandomNum(1,10000);
					String sProductTier = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id, sProductTier+iRandomNum, "Name");
					//*This field is required

					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 			
					fnVerifyDialogBox("Add", 0);

					obj.repAddData( "Verify Corporation Name in Database", "", "", "");
					//Put db code here

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31906 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31906 Completed");
				}
				return obj;
			} //End of function TC31906	

			//RW-91_Product Tiers_TC005_Add Product Tier_Cancel Product Tier Name
			@SuppressWarnings("static-access")
			public Reporter TC31907(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31907 Started..");

				try {

					obj.repAddData( "Cancelling a Product Tier", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					fnCheckFieldDisplayById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id,"Product Tier text box", true, true);
					HighlightElementById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id);

					int iRandomNum = fnRandomNum(1,10000);
					String sProductTier = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id, sProductTier+iRandomNum,"Name");
					//*This field is required

					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",true); 
					obj.repAddData( "Verify Corporation Name in Database", "", "", "");
					//Put db code here

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31907 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31907 Completed");
				}
				return obj;
			} //End of function TC31907	


			//RW-91_Product Tiers_TC008_Add Product Tier_Validate Product Tier Name with characters length more than 80
			@SuppressWarnings("static-access")
			public Reporter TC32900(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC32900 Started..");

				try {

					obj.repAddData( "Add and Save a Product Tier with length more than 80", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tier Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					fnCheckFieldDisplayById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id,"Product Tier text box", true, true);
					HighlightElementById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id);

					int iRandomNum = fnRandomNum(1,10000);
					String sProductTier = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id, sProductTier+iRandomNum, "Name");

					fnCheckFieldDisplayByXpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgMaxLength_xp,"Max Length Error Message", true, true);
					HighlightElementByXpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgMaxLength_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgMaxLength_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg))
					{
						obj.repAddData( "Verify Max Length Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Max Length Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' not shown", "Fail");
					}

					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC32900 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC32900 Completed");
				}
				return obj;
			} //End of function TC32900	


			//RW-91_Product Tiers_TC009_Add Product Tier_Validate Product Tier with characters length 80 and special characters
			@SuppressWarnings("static-access")
			public Reporter TC32901(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC32901 Started..");

				try {

					obj.repAddData( "Add and Save a Product Tier with characters length 80 and special characters", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tier Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					fnCheckFieldDisplayById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id,"Product Tier text box", true, true);

					int iRandomNum = fnRandomNum(10000000,99999999);
					String sProductTier = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id, sProductTier+iRandomNum, "Name");
					System.out.println("Size>>>>>>>>>>>>>>>"+sProductTier.length()+String.valueOf(iRandomNum).length());

					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnSave_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true);
						fnLoadingPageWait();
					}
					else
					{
						obj.repAddData( "Click on Save button", "Save button should be clicked","Save button not clicked", "Fail");
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}

					fnVerifyDialogBox("Add", 0);
					obj.repAddData( "Verify Corporation Name in Database", "", "", "");
					//Put db code here
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC32901 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC32901 Completed");
				}
				return obj;
			} //End of function TC32901	

			//RW-91_Product Tiers_TC010_Add Product Tier_Validate Product Tier by adding a duplicate Product Tier Name
			@SuppressWarnings("static-access")
			public Reporter TC32902(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC32902 Started..");

				try {

					obj.repAddData( "Adding a Duplicate Product Tier", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tier Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					fnCheckFieldDisplayById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id,"Product Tier text box", true, true);
					HighlightElementById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id);


					int iRandomNum = fnRandomNum(1,10000);
					String sProductTier = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id, sProductTier+iRandomNum,"Name");
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 

					fnVerifyDialogBox("Add", 0);

					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					SendKeyById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id, sProductTier+iRandomNum,"Name");

					fnCheckFieldDisplayByXpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgDuplicate_xp,"Duplicate Error Message", true, true);
					HighlightElementByXpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgDuplicate_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgDuplicate_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.ProductTiers_AddProductTier_ErrorMsgDuplicate_msg))
					{
						obj.repAddData( "Verify Duplicate Error Message", "'"+objAppMessages.ProductTiers_AddProductTier_ErrorMsgDuplicate_msg+"' should be shown", "'"+objAppMessages.ProductTiers_AddProductTier_ErrorMsgDuplicate_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Duplicate Error Message", "'"+objAppMessages.ProductTiers_AddProductTier_ErrorMsgDuplicate_msg+"' should be shown","'"+ objAppMessages.ProductTiers_AddProductTier_ErrorMsgDuplicate_msg+"' not shown", "Fail");
					}

					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC32902 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC32902 Completed");
				}
				return obj;
			} //End of function TC32902	




			//RW-91_Product Tiers_TC010_Add Product Tier_Validate Product tier Name with blank characters
			@SuppressWarnings("static-access")
			public Reporter TC32903(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC32903 Started..");

				try {

					obj.repAddData( "Validating the Product Tier with blank characters", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.ProductTiers_GenProd_LinkProductTiersOption_xp, "Product Tiers Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.ProductTiers_ViewProductTiers_BtnAddProductTier_xp, "Add Product Tier button",true);
					fnCheckFieldDisplayById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id,"Product Tier text box", true, true);
					HighlightElementById(objRWModules.ProductTiers_AddProductTier_InputProductTier_id);

					String sProductTier = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.id(objRWModules.ProductTiers_AddProductTier_InputProductTier_id)).sendKeys(sProductTier);
					driver.findElement(By.id(objRWModules.ProductTiers_AddProductTier_InputProductTier_id)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgRequired_xp,"Required Error Message", true, true);
					HighlightElementByXpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgRequired_xp);
					String sErrorMsg =driver.findElement(By.xpath(objRWModules.ProductTiers_AddProductTier_ErrorMsgRequired_xp)).getText().toString().trim();
					if(sErrorMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}

					//*This field is required

					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC32903 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC32903 Completed");
				}
				return obj;
			} //End of function TC32903	



			///////////////////////////////////////Product Tier Tests End Here///////////////////////////////////////////////////////////////////////////

			///////////////////////////////////////Property Tests Starts Here///////////////////////////////////////////////////////////////////////////

			//RW-75_Property_TC001_Add Property_Verify to see Add Property form
			@SuppressWarnings("static-access")
			public Reporter TC31951(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31951 Started..");

				try {
					obj.repAddData( "Adding the Property", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp,"Project Name text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square Feet text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathrooms select box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Year Built text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Year Built text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned Select box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);				
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition
				}

				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31951 Failed!", e );
				}
				finally {
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31951 Completed");
				}
				return obj;
			} //End of function TC31951

			
			//RW-75_Property_TC002_Add Property_Verify to see Add Property form Required fields
			@SuppressWarnings("static-access")
			public Reporter TC31952(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31952 Started..");

				try {
					obj.repAddData( "Required Fields label", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectNameRequired_xp,"Project Name Field required", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddressRequired_xp, "Address Field required", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCityFieldRequired_xp, "City Field required", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputStateFieldRequired_xp, "State Field required", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCodeFieldRequired_xp,"Project Name Field required", true, true);
							
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition
				}

				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31952 Failed!", e );
				}
				finally {
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31952 Completed");
				}
				return obj;
			} //End of function TC31952

			
			//RW-75_Property_TC003_Add Property_Verify to see the prompt for required fields
			@SuppressWarnings("static-access")
			public Reporter TC31953(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31953 Started..");

				try {

					obj.repAddData( "Validating the Property Page", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);

					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).sendKeys(sProjectName);
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ProjectNameErrorMsgRequired_xp, "Project name Error Message", true, true);

					String sProjectNameMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_ProjectNameErrorMsgRequired_xp)).getText().toString().trim();
					if(sProjectNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			

					//Check for Address field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);

					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_AddressErrorMsgRequired_xp, "Address Error Message", true, true);

					String sAddressMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_AddressErrorMsgRequired_xp)).getText().toString().trim();
					if(sAddressMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);

					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_CityErrorMsgRequired_xp, "City Error Message", true, true);

					String sCityMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_CityErrorMsgRequired_xp)).getText().toString().trim();
					if(sCityMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	

					//Check for State field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);

					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_StateErrorMsgRequired_xp, "State Error Message", true, true);

					String sStateMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_StateErrorMsgRequired_xp)).getText().toString().trim();
					if(sStateMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	

					//Check for ZipCode field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);

					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ZipCodeErrorMsgRequired_xp, "ZipCode Error Message", true, true);

					String sZipCodeMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_ZipCodeErrorMsgRequired_xp)).getText().toString().trim();
					if(sZipCodeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	


					//*This field is required
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31953 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31953 Completed");
				}
				return obj;
			} //End of function TC31953	

			//RW-75_Property_TC006_Add Property_Verify Number of Bathrooms dropdown values
			@SuppressWarnings("static-access")
			public Reporter TC31956(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31956 Started..");

				try {

					obj.repAddData( "Availability of Number of Bathrooms Options", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					List<WebElement> arrNumberOfBathroom = select.getOptions();
					System.out.println("Number Of Bathroom Combobox Size>>>>"+arrNumberOfBathroom.size());

					fnVerifyComboBoxValues(arrNumberOfBathroom, 1, "1");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 2, "1 �");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 3, "2");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 4, "2 �");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 5, "3");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 6, "3 �");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 7, "4");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 8, "4 �");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 9, "5");
					fnVerifyComboBoxValues(arrNumberOfBathroom, 10, "5 �");	

					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31956 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31956 Completed");
				}
				return obj;
			} //End of function TC31956	

			//RW-75_Property_TC007_Add Property_Verify Assigned user dropdown
			@SuppressWarnings("static-access")
			public Reporter TC31957(Reporter obj) throws Exception
			{
				log.info("Execution of Function TC31957 Started..");

				try {

					obj.repAddData( "Viewing the Users in User field", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					ClickByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned Combo Box",true);
					fnCheckComboBoxSorting(objRWModules.Property_AddProperty_ComboWalkAssigned_xp,"Walk Assigned", "Select");

					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",true); 
					fnLoadingPageWait();

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31957 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31957 Completed");
				}
				return obj;
			} //End of function TC31957


			//RW-75_Property_TC005_Add Property_Verify Number of Rooms Numeric only
			@SuppressWarnings("static-access")
			public Reporter TC31955(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31955 Started..");

				try {

					obj.repAddData( "Verify Number of Rooms Numeric only", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Filling Number of Bedrooms
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number Bedrooms text box", true, true);

					String sNumberBedroomsNumeric = "2";
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedroomsNumeric);
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).clear();

					String sNumberBedroomsNonNumeric = "AutoTest";
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedroomsNonNumeric);

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_NumberBedroomErrorMsgRequired_xp, "Number Of Bedrooms not Nmeric Error Message", true, true);

					String sNumberBedroomsMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_NumberBedroomErrorMsgRequired_xp)).getText().toString().trim();
					if(sNumberBedroomsMsg.equalsIgnoreCase(objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg+"' should be shown", "'"+objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg+"' should be shown","'"+ objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg+"' not shown", "Fail");
					}
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31955 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31955 Completed");
				}
				return obj;
			} //End of function TC31955

			//RW-75_Property_TC008_Add Property_Verify Year build can not be greater than current year
			@SuppressWarnings("static-access")
			public Reporter TC31958(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31958 Started..");

				try {

					obj.repAddData( "Verify year built must not be greater than Current Year", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);

					String sYearBuiltLesserThanCurrentYear = "2010";
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearBuiltLesserThanCurrentYear);
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).clear();

					String sYearsBuiltGreaterThanCurrentYear = "2016";
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuiltGreaterThanCurrentYear);

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_notPreviousYearErrorMsgRequired_xp, "Year Greater than Current year Error Message", true, true);

					String sYearBuiltMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_notPreviousYearErrorMsgRequired_xp)).getText().toString().trim();
					if(sYearBuiltMsg.equalsIgnoreCase(objAppMessages.Property_AddProperty_ErrorMsgYearBuilt_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Property_AddProperty_ErrorMsgYearBuilt_msg+"' should be shown", "'"+objAppMessages.Property_AddProperty_ErrorMsgYearBuilt_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Property_AddProperty_ErrorMsgYearBuilt_msg+"' should be shown","'"+ objAppMessages.Property_AddProperty_ErrorMsgYearBuilt_msg+"' not shown", "Fail");
					}
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31958 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31958 Completed");
				}
				return obj;
			} //End of function TC31958

			//method for save and cancel property

			

			//RW-75_Property_TC009_Add Property_Verify clicking Save on Add property
			@SuppressWarnings("static-access")
			public Reporter TC31959(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31959 Started..");

				try {

					obj.repAddData( "Save on Add Property", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);
					int iRandomNum = fnRandomNum(1,10000);
					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();		
					SendKeyByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, sProjectName+iRandomNum, "Name");

					//Filling Address field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);

					//Filing State Field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);

					//Filling ZipCode field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);

					//Filling County field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);
					String sCounty = mTestPhaseData.get(TestDriver.iTC_ID).get("County").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCounty_xp)).sendKeys(sCounty);

					//Filling main Square feet field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square feet text box", true, true);
					String sMainSquareFT = mTestPhaseData.get(TestDriver.iTC_ID).get("MainSqFt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp)).sendKeys(sMainSquareFT);

					//Filling Number of Bedrooms field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);
					String sNumberBedrooms = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedrooms);

					//Select Number of Bathrooms combo box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathroom select box", true, true);
					Select sNumberBathrooms = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					sNumberBathrooms.selectByIndex(2);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);
					String sYearsBuilt = mTestPhaseData.get(TestDriver.iTC_ID).get("YearBuilt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuilt);

					//Filling Comments
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Comments text box", true, true);
					String sComments = mTestPhaseData.get(TestDriver.iTC_ID).get("Comment").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputComment_xp)).sendKeys(sComments);

					//Select Walk Assigned
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned select box", true, true);
					Select sWalkAssigned = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp)));
					sWalkAssigned.selectByIndex(1);

					//Filling Gate Code
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);
					String sGateCode = mTestPhaseData.get(TestDriver.iTC_ID).get("GateCode").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputGateCode_xp)).sendKeys(sGateCode);

					//Filling Lock Box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);
					String sLockBox = mTestPhaseData.get(TestDriver.iTC_ID).get("LockBox").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputLockBox_xp)).sendKeys(sLockBox);

					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",true); 
					fnVerifyDialogBox("Add", 0);
					obj.repAddData( "Verify Office Name in Database", "", "", "");
					//Put db code here

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31959 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31959 Completed");
				}
				return obj;
			} //End of function TC31959
			
			//RW-75_Property_TC010_Add Property_Verify clicking Cancel on Add property
			@SuppressWarnings("static-access")
			public Reporter TC31960(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31960 Started..");

				try {

					obj.repAddData( "Cancel on Add Property", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);
					int iRandomNum = fnRandomNum(1,10000);
					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();		
					SendKeyByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, sProjectName+iRandomNum, "Name");

					//Filling Address field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);
					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);
					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);

					//Filing State Field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);
					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);

					//Filling ZipCode field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);
					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);

					//Filling County field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);
					String sCounty = mTestPhaseData.get(TestDriver.iTC_ID).get("County").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCounty_xp)).sendKeys(sCounty);

					//Filling main Square feet field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square feet text box", true, true);
					String sMainSquareFT = mTestPhaseData.get(TestDriver.iTC_ID).get("MainSqFt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp)).sendKeys(sMainSquareFT);

					//Filling Number of Bedrooms field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);
					String sNumberBedrooms = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedrooms);

					//Select Number of Bathrooms combo box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathroom select box", true, true);
					Select sNumberBathrooms = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					sNumberBathrooms.selectByIndex(2);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);
					String sYearsBuilt = mTestPhaseData.get(TestDriver.iTC_ID).get("YearBuilt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuilt);

					//Filling Comments
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Comments text box", true, true);
					String sComments = mTestPhaseData.get(TestDriver.iTC_ID).get("Comment").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputComment_xp)).sendKeys(sComments);

					//Select Walk Assigned
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned select box", true, true);
					Select sWalkAssigned = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp)));
					sWalkAssigned.selectByIndex(1);

					//Filling Gate Code
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);
					String sGateCode = mTestPhaseData.get(TestDriver.iTC_ID).get("GateCode").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputGateCode_xp)).sendKeys(sGateCode);

					//Filling Lock Box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);
					String sLockBox = mTestPhaseData.get(TestDriver.iTC_ID).get("LockBox").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputLockBox_xp)).sendKeys(sLockBox);

					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition
					obj.repAddData( "Verify Office Name in Database", "", "", "");
					//Put db code here

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31960 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31960 Completed");
				}
				return obj;
			} //End of function TC31960
			
			
			//RW-75_Property_TC011_Add Property_Verify Add Property showing on tab
			@SuppressWarnings("static-access")
			public Reporter TC31961(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31961 Started..");

				try {

					obj.repAddData( "Checking Add Properties Tab", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);
					ClickByXpath(objRWModules.Property_AddProperty_PropertyWalkTab_xp, "Property Walk tab", true);
					ClickByXpath(objRWModules.Property_AddProperty_PropertyBudgetTab_xp, "Budget tab", true);
					ClickByXpath(objRWModules.Property_AddProperty_PropertyProjectTools_xp, "Project tools Walk tab", true);

					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC31961 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC31961 Completed");
				}
				return obj;
			} //End of function TC31961
			

			//RW-91_Product Tiers_TC003_Add Product Tier_Verify current product tier display
			@SuppressWarnings("static-access")
			public Reporter TC31962(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC31962 Started..");

				try {

					obj.repAddData( "Viewing the Properties page", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);

					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();
					
					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_AddForm_xp, "Add Property Form", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Common_ViewModules_Table_xp, "Properties Table", true, true);

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC31962 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC31962 Completed");
				}
				return obj;
			} //End of function TC31962
			
			
			//RW-75_Property_TC014_Add Property_Required Field Project Name Validation
			@SuppressWarnings("static-access")
			public Reporter TC33412(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC33412 Started..");

				try {

					obj.repAddData( "Required Field Project Name Validation", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);

					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).sendKeys(sProjectName);


					//Filling Address field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);

					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);

					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);

					//Filing State Field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);

					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);

					//Filling ZipCode field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);

					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);

					//Filling County field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);

					String sCounty = mTestPhaseData.get(TestDriver.iTC_ID).get("County").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCounty_xp)).sendKeys(sCounty);

					//Filling main Square feet field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square feet text box", true, true);

					String sMainSquareFT = mTestPhaseData.get(TestDriver.iTC_ID).get("MainSqFt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp)).sendKeys(sMainSquareFT);

					//Filling Number of Bedrooms field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);

					String sNumberBedrooms = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedrooms);

					//Select Number of Bathrooms combo box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathroom select box", true, true);

					Select sNumberBathrooms = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					sNumberBathrooms.selectByIndex(2);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);

					String sYearsBuilt = mTestPhaseData.get(TestDriver.iTC_ID).get("YearBuilt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuilt);

					//Filling Comments
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Comments text box", true, true);

					String sComments = mTestPhaseData.get(TestDriver.iTC_ID).get("Comment").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputComment_xp)).sendKeys(sComments);

					//Select Walk Assigned
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned select box", true, true);

					Select sWalkAssigned = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp)));
					sWalkAssigned.selectByIndex(1);

					//Filling Gate Code
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);

					String sGateCode = mTestPhaseData.get(TestDriver.iTC_ID).get("GateCode").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputGateCode_xp)).sendKeys(sGateCode);

					//Filling Lock Box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);

					String sLockBox = mTestPhaseData.get(TestDriver.iTC_ID).get("LockBox").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputLockBox_xp)).sendKeys(sLockBox);

					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ProjectNameErrorMsgRequired_xp, "Project name Error Message", true, true);

					String sProjectNameMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_ProjectNameErrorMsgRequired_xp)).getText().toString().trim();
					if(sProjectNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					//*This field is required
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC33412 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC33412 Completed");
				}
				return obj;
			} //End of function TC33412	



			//RW-75_Property_TC015_Add Property_Required Field Address Validation
			@SuppressWarnings("static-access")
			public Reporter TC33413(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC33413 Started..");

				try {

					obj.repAddData( "Required Field Address Validation", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);

					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).sendKeys(sProjectName);


					//Filling Address field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);

					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);

					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);

					//Filing State Field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);

					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);

					//Filling ZipCode field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);

					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);

					//Filling County field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);

					String sCounty = mTestPhaseData.get(TestDriver.iTC_ID).get("County").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCounty_xp)).sendKeys(sCounty);

					//Filling main Square feet field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square feet text box", true, true);

					String sMainSquareFT = mTestPhaseData.get(TestDriver.iTC_ID).get("MainSqFt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp)).sendKeys(sMainSquareFT);

					//Filling Number of Bedrooms field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);

					String sNumberBedrooms = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedrooms);

					//Select Number of Bathrooms combo box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathroom select box", true, true);

					Select sNumberBathrooms = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					sNumberBathrooms.selectByIndex(2);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);

					String sYearsBuilt = mTestPhaseData.get(TestDriver.iTC_ID).get("YearBuilt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuilt);

					//Filling Comments
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Comments text box", true, true);

					String sComments = mTestPhaseData.get(TestDriver.iTC_ID).get("Comment").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputComment_xp)).sendKeys(sComments);

					//Select Walk Assigned
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned select box", true, true);

					Select sWalkAssigned = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp)));
					sWalkAssigned.selectByIndex(1);

					//Filling Gate Code
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);

					String sGateCode = mTestPhaseData.get(TestDriver.iTC_ID).get("GateCode").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputGateCode_xp)).sendKeys(sGateCode);

					//Filling Lock Box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);

					String sLockBox = mTestPhaseData.get(TestDriver.iTC_ID).get("LockBox").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputLockBox_xp)).sendKeys(sLockBox);

					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_AddressErrorMsgRequired_xp, "Address Error Message", true, true);

					String sAddressMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_AddressErrorMsgRequired_xp)).getText().toString().trim();
					if(sAddressMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					//*This field is required
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC33413 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC33413 Completed");
				}
				return obj;
			} //End of function TC33413	


			//RW-75_Property_TC016_Add Property_Required Field City Validation
			@SuppressWarnings("static-access")
			public Reporter TC33540(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC33540 Started..");

				try {

					obj.repAddData( "Required Field City Validation", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);

					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).sendKeys(sProjectName);


					//Filling Address field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);

					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);

					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);

					//Filing State Field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);

					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);

					//Filling ZipCode field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);

					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);

					//Filling County field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);

					String sCounty = mTestPhaseData.get(TestDriver.iTC_ID).get("County").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCounty_xp)).sendKeys(sCounty);

					//Filling main Square feet field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square feet text box", true, true);

					String sMainSquareFT = mTestPhaseData.get(TestDriver.iTC_ID).get("MainSqFt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp)).sendKeys(sMainSquareFT);

					//Filling Number of Bedrooms field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);

					String sNumberBedrooms = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedrooms);

					//Select Number of Bathrooms combo box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathroom select box", true, true);

					Select sNumberBathrooms = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					sNumberBathrooms.selectByIndex(2);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);

					String sYearsBuilt = mTestPhaseData.get(TestDriver.iTC_ID).get("YearBuilt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuilt);

					//Filling Comments
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Comments text box", true, true);

					String sComments = mTestPhaseData.get(TestDriver.iTC_ID).get("Comment").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputComment_xp)).sendKeys(sComments);

					//Select Walk Assigned
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned select box", true, true);

					Select sWalkAssigned = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp)));
					sWalkAssigned.selectByIndex(1);

					//Filling Gate Code
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);

					String sGateCode = mTestPhaseData.get(TestDriver.iTC_ID).get("GateCode").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputGateCode_xp)).sendKeys(sGateCode);

					//Filling Lock Box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);

					String sLockBox = mTestPhaseData.get(TestDriver.iTC_ID).get("LockBox").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputLockBox_xp)).sendKeys(sLockBox);

					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_CityErrorMsgRequired_xp, "City Error Message", true, true);

					String sCityMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_CityErrorMsgRequired_xp)).getText().toString().trim();
					if(sCityMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					//*This field is required
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC33540 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC33540 Completed");
				}
				return obj;
			} //End of function TC33540


			//RW-75_Property_TC017_Add Property_Required Field State Validation
			@SuppressWarnings("static-access")
			public Reporter TC33541(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC33541 Started..");

				try {

					obj.repAddData( "Required Field State Validation", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);

					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).sendKeys(sProjectName);


					//Filling Address field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);

					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);

					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);

					//Filing State Field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);

					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);

					//Filling ZipCode field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);

					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);

					//Filling County field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);

					String sCounty = mTestPhaseData.get(TestDriver.iTC_ID).get("County").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCounty_xp)).sendKeys(sCounty);

					//Filling main Square feet field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square feet text box", true, true);

					String sMainSquareFT = mTestPhaseData.get(TestDriver.iTC_ID).get("MainSqFt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp)).sendKeys(sMainSquareFT);

					//Filling Number of Bedrooms field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);

					String sNumberBedrooms = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedrooms);

					//Select Number of Bathrooms combo box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathroom select box", true, true);

					Select sNumberBathrooms = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					sNumberBathrooms.selectByIndex(2);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);

					String sYearsBuilt = mTestPhaseData.get(TestDriver.iTC_ID).get("YearBuilt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuilt);

					//Filling Comments
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Comments text box", true, true);

					String sComments = mTestPhaseData.get(TestDriver.iTC_ID).get("Comment").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputComment_xp)).sendKeys(sComments);

					//Select Walk Assigned
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned select box", true, true);

					Select sWalkAssigned = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp)));
					sWalkAssigned.selectByIndex(1);

					//Filling Gate Code
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);

					String sGateCode = mTestPhaseData.get(TestDriver.iTC_ID).get("GateCode").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputGateCode_xp)).sendKeys(sGateCode);

					//Filling Lock Box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);

					String sLockBox = mTestPhaseData.get(TestDriver.iTC_ID).get("LockBox").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputLockBox_xp)).sendKeys(sLockBox);

					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_StateErrorMsgRequired_xp, "State Error Message", true, true);

					String sStateMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_StateErrorMsgRequired_xp)).getText().toString().trim();
					if(sStateMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					//*This field is required
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC33541 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC33541 Completed");
				}
				return obj;
			} //End of function TC33541

			//RW-75_Property_TC018_Add Property_Required Field ZipCode Validation
			@SuppressWarnings("static-access")
			public Reporter TC33542(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC33542 Started..");

				try {

					obj.repAddData( "Required Field ZipCode Validation", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);

					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).sendKeys(sProjectName);


					//Filling Address field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);

					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);

					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);

					//Filing State Field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);

					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);

					//Filling ZipCode field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);

					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);

					//Filling County field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);

					String sCounty = mTestPhaseData.get(TestDriver.iTC_ID).get("County").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCounty_xp)).sendKeys(sCounty);

					//Filling main Square feet field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square feet text box", true, true);

					String sMainSquareFT = mTestPhaseData.get(TestDriver.iTC_ID).get("MainSqFt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp)).sendKeys(sMainSquareFT);

					//Filling Number of Bedrooms field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);

					String sNumberBedrooms = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedrooms);

					//Select Number of Bathrooms combo box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathroom select box", true, true);

					Select sNumberBathrooms = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					sNumberBathrooms.selectByIndex(2);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);

					String sYearsBuilt = mTestPhaseData.get(TestDriver.iTC_ID).get("YearBuilt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuilt);

					//Filling Comments
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Comments text box", true, true);

					String sComments = mTestPhaseData.get(TestDriver.iTC_ID).get("Comment").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputComment_xp)).sendKeys(sComments);

					//Select Walk Assigned
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned select box", true, true);

					Select sWalkAssigned = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp)));
					sWalkAssigned.selectByIndex(1);

					//Filling Gate Code
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);

					String sGateCode = mTestPhaseData.get(TestDriver.iTC_ID).get("GateCode").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputGateCode_xp)).sendKeys(sGateCode);

					//Filling Lock Box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);

					String sLockBox = mTestPhaseData.get(TestDriver.iTC_ID).get("LockBox").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputLockBox_xp)).sendKeys(sLockBox);

					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ZipCodeErrorMsgRequired_xp, "ZipCode Error Message", true, true);

					String sZipCodeMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_ZipCodeErrorMsgRequired_xp)).getText().toString().trim();
					if(sZipCodeMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					//*This field is required
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC33542 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC33542 Completed");
				}
				return obj;
			} //End of function TC33542


			//RW-75_Property_TC019_Add Property_Required Field Address and City Validation
			@SuppressWarnings("static-access")
			public Reporter TC33543(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC33543 Started..");

				try {

					obj.repAddData( "Required Field Address and City Validation", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);


					ClickByXpath(objRWModules.Property_GenProperty_LinkPropertyOption_xp, "Property Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Property_ViewOffice_BtnAddProperty_xp, "Add Property button",true);

					//Check for Project Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputProjectName_xp, "Project Name text box", true, true);

					String sProjectName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputProjectName_xp)).sendKeys(sProjectName);


					//Filling Address field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputAddress_xp, "Address text box", true, true);

					String sAddress = mTestPhaseData.get(TestDriver.iTC_ID).get("Address").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).sendKeys(sAddress);

					//Check for City field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCity_xp, "City text box", true, true);

					String sCity = mTestPhaseData.get(TestDriver.iTC_ID).get("City").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).sendKeys(sCity);

					//Filing State Field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputState_xp, "State text box", true, true);

					String sState = mTestPhaseData.get(TestDriver.iTC_ID).get("State").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputState_xp)).sendKeys(sState);

					//Filling ZipCode field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputZipCode_xp, "ZipCode text box", true, true);

					String sZipCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputZipCode_xp)).sendKeys(sZipCode);

					//Filling County field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputCounty_xp, "County text box", true, true);

					String sCounty = mTestPhaseData.get(TestDriver.iTC_ID).get("County").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCounty_xp)).sendKeys(sCounty);

					//Filling main Square feet field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp, "Main Square feet text box", true, true);

					String sMainSquareFT = mTestPhaseData.get(TestDriver.iTC_ID).get("MainSqFt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputMainSquareFT_xp)).sendKeys(sMainSquareFT);

					//Filling Number of Bedrooms field
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp, "Number of Bedrooms text box", true, true);

					String sNumberBedrooms = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputNumberBedrooms_xp)).sendKeys(sNumberBedrooms);

					//Select Number of Bathrooms combo box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp, "Number of Bathroom select box", true, true);

					Select sNumberBathrooms = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboNumberBathroom_xp)));
					sNumberBathrooms.selectByIndex(2);

					//Filling Years Built
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputYearBuilt_xp, "Years built text box", true, true);

					String sYearsBuilt = mTestPhaseData.get(TestDriver.iTC_ID).get("YearBuilt").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputYearBuilt_xp)).sendKeys(sYearsBuilt);

					//Filling Comments
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputComment_xp, "Comments text box", true, true);

					String sComments = mTestPhaseData.get(TestDriver.iTC_ID).get("Comment").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputComment_xp)).sendKeys(sComments);

					//Select Walk Assigned
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp, "Walk Assigned select box", true, true);

					Select sWalkAssigned = new Select(driver.findElement(By.xpath(objRWModules.Property_AddProperty_ComboWalkAssigned_xp)));
					sWalkAssigned.selectByIndex(1);

					//Filling Gate Code
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputGateCode_xp, "Gate Code text box", true, true);

					String sGateCode = mTestPhaseData.get(TestDriver.iTC_ID).get("GateCode").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputGateCode_xp)).sendKeys(sGateCode);

					//Filling Lock Box
					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_InputLockBox_xp, "Lock Box text box", true, true);

					String sLockBox = mTestPhaseData.get(TestDriver.iTC_ID).get("LockBox").toString().trim();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputLockBox_xp)).sendKeys(sLockBox);

					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputAddress_xp)).clear();
					driver.findElement(By.xpath(objRWModules.Property_AddProperty_InputCity_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_AddressErrorMsgRequired_xp, "Address Error Message", true, true);

					String sAddressMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_AddressErrorMsgRequired_xp)).getText().toString().trim();
					if(sAddressMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					fnCheckFieldDisplayByXpath(objRWModules.Property_AddProperty_CityErrorMsgRequired_xp, "City Error Message", true, true);

					String sCityMsg = driver.findElement(By.xpath(objRWModules.Property_AddProperty_CityErrorMsgRequired_xp)).getText().toString().trim();
					if(sCityMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}		

					//*This field is required
					ClickByXpath(objRWModules.Property_AddProperty_BtnCancel_xp, "Cancel button",false);  //post condition

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC33543 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC33543 Completed");
				}
				return obj;
			} //End of function TC33543

			///////////////////////////////////////Property Tests End Here///////////////////////////////////////////////////////////////////////////
			
			
			///////////////////////////////////////Groups Tests Starts Here///////////////////////////////////////////////////////////////////////////
			//RW-240_Groups_TC001_View Groups_View Groups
			@SuppressWarnings("static-access")
			public Reporter TC35857(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35857 Started..");

				try {
							
					obj.repAddData( "Viewing the Groups", "", "", "");
					
					/*ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();*/
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();
		
					fnSelectFromComboBoxXpath(objRWModules.Common_ViewModules_ComboPageSize_xp,"VIEW ALL");
					fnLoadingPageWait();
			/*		WebElement eleTable = driver.findElement(By.xpath(objRWHome.Main_ViewModules_Table_xp));

					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());

					HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer,HashMap<Integer, String>>();
					ArrayList<String> arrTableData = new ArrayList<String>();
		
					for(int iRow=0;iRow<arrTableRows.size();iRow++)
					{	
						//arrTableData.clear();
						String sColValue=null;
						mTableData.put(iRow+1, new HashMap<Integer, String>());
						
						List<WebElement> arrTableColumns = arrTableRows.get(iRow).findElements(By.xpath("./td"));  //Get the table data rows
						for(int iCol=0;iCol<arrTableColumns.size();iCol++)
						{
							List<WebElement> arrEditDelete;	
						
							switch (iCol) 
							{
								case 0: //sColValue = arrTableColumns.get(iCol).findElement(By.xpath("./b")).getText();//.toString();
										sColValue = arrTableColumns.get(iCol).findElement(By.xpath("./b")).getAttribute("innerText");
										System.out.println("sColValue"+sColValue);
										break;
								case 1: sColValue = arrTableColumns.get(iCol).getText().toString();
										break;
								case 2: arrEditDelete = arrTableColumns.get(iCol).findElements(By.xpath("./div/span"));
										String sEdit  = arrEditDelete.get(0).getAttribute("title");
										String sDelete = arrEditDelete.get(1).getAttribute("title");
										System.out.println(sEdit+sDelete);
										sColValue= sEdit+","+sDelete;
										break;
							}
							arrTableData.add(sColValue);
							
							mTableData.get(iRow+1).put(iCol+1,sColValue);
						}
						
		
					}*/
					
					HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Groups");
					fnCheckSortedList(mTableData,"Group Name",1);
					System.out.println("Sorted Functionality Tested Successfully");
								////////////////////Sorting Logic End////////////////////////////
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35857 Failed!", e );
				}
				finally {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					/*obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					header = null;    //Enable after testing
		*/				log.info("Execution of Function TC35857 Completed");
				}
				return obj;
			} //End of function TC35857
			
			
			
			//RW-240_Groups_TC002_View Groups_Prompt to select office
			@SuppressWarnings("static-access")
			public Reporter TC35859(Reporter obj) throws Exception
			{
				Boolean bLoginFlag = false;	
				log.info("Execution of Function TC35859 Started..");
				
		
				try {
							
						obj.repAddData( "View Groups", "", "", "");
						
						//fnSelectFromComboBoxXpath(objRWModules.Common_AllModules_ComboCorporateName_xp, "Select");
						//ClickByXpath(objRWModules.Common_AllModules_ComboCorporateName_xp, "Corporation Selection",true);
						fnSelectCorpOffice("Select", "Select");
						//fnSelectCorpOffice(objRWModules.Common_AllModules_ComboCorporateName_xp, sOffice);
						ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
						fnVerifyDialogBox("OfficeCode",1);
						//Navigate back to home page so next test runs correctly
						ClickByXpath("//*[@id='sidebarLogo']", "Groups Link",false);
						fnSelectCorpOffice(sCorporation, sOffice);
						
					
				}
				
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35859 Failed!", e );
				}
				finally {
					
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC35859 Completed");
				}
				return obj;
			} //End of function TC35859
			
			
			//RW-240_Groups_TC003_View Groups_verify columns
			@SuppressWarnings("static-access")
			public Reporter TC35860(Reporter obj) throws Exception
			{
				Boolean bLoginFlag = false;	
				log.info("Execution of Function TC35860 Started..");
				
		
				try {
							
						obj.repAddData( "View Groups", "", "", "");
						fnSelectCorpOffice(sCorporation, sOffice);
						ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
												
						WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("./thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,0,"Group Name");
						fnVerifyHeaders(arrHeaderColumns,1,"Max Number Per House");
						fnVerifyHeaders(arrHeaderColumns,2,"Include Measurements");
						fnVerifyHeaders(arrHeaderColumns,3,"Include Paint");
						fnVerifyHeaders(arrHeaderColumns,4,"Include Comment");
					
						HashMap<Integer, HashMap<Integer, String>> mTableData = fnGetTableData(objRWModules.Common_ViewModules_Table_xp, "Groups");
						boolean bCopyEditDelete = true;
						boolean bCheckBox = true;
						int iRow = 0;
						for(iRow=1;iRow<=mTableData.size();iRow++)
						{
							String[] arrCopyEditDelete = mTableData.get(iRow).get(6).toString().trim().split(";;");
							if(!arrCopyEditDelete[0].toString().trim().equalsIgnoreCase("Copy") && !arrCopyEditDelete[1].toString().trim().equalsIgnoreCase("Edit") && !arrCopyEditDelete[2].toString().trim().equalsIgnoreCase("Delete"))
							{
								bCopyEditDelete = false;
								break;
							}
							
							if(!mTableData.get(iRow).get(7).toString().trim().equalsIgnoreCase("checkbox"))
							{
								bCheckBox = false;
								break;
							}
						
						}
						
						if(bCopyEditDelete==true && bCheckBox==true)
						{
							obj.repAddData( "Verify Copy, Edit, Delete and Checkbox Options", "Copy, Edit, Delete and Checkbox Options should be displayed in front of each row", "Copy, Edit, Delete and Checkbox Options are displayed in front of each row", "Pass");
						}
						else
						{
							obj.repAddData( "Verify Copy, Edit, Delete and Checkbox Options", "Copy, Edit, Delete and Checkbox Options should be displayed in front of each row", "Copy, Edit, Delete and Checkbox Options are not displayed for row = "+iRow, "Fail");
						}
				}
				
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35860 Failed!", e );
				}
				finally {
					
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC35860 Completed");
				}
				return obj;
			} //End of function TC35860	
			
			
			//RW-240_Groups_TC004_View Groups_verify option
			@SuppressWarnings("static-access")
			public Reporter TC35861(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35861 Started..");

				try {
							
					obj.repAddData( "Availability of DELETE SELECTED button", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Groups_ViewGroup_BtnDeleteSelected_xp,"'DELETE SELECTED' button",true,true);
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35861 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35861 Completed");
				}
				return obj;
			} //End of function TC35861	
			
			//RW-240_Groups_TC005_View Groups_verify ADD GROUP
			@SuppressWarnings("static-access")
			public Reporter TC35862(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35862 Started..");

				try {
							
					obj.repAddData( "Availability of ADD GROUP button", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Groups_ViewGroup_BtnAddGroup_xp,"'ADD GROUP' button",true,true);
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35861 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35862 Completed");
				}
				return obj;
			} //End of function TC35862	
			
			
			//RW-240_Groups_TC006_View Groups_verify Loading message
			@SuppressWarnings("static-access")
			public Reporter TC35863(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35863 Started..");

				try {
							
					obj.repAddData( "Verify loading icon", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();			//Currently not coming. loading icon should come on every click on left hand side. Defect already raised.

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35863 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35863 Completed");
				}
				return obj;
			} //End of function TC35863
			
			
			//RW-240_Groups_TC007_View Groups_Availability of Pagination options
			@SuppressWarnings("static-access")
			public Reporter TC35914(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35914 Started..");

				try {
							
					obj.repAddData( "Availability of Pagination Options", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35914 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35914 Completed");
				}
				return obj;
			} //End of function TC35914
			
			//RW-240_Groups_TC008_View Groups_Validate Current Groups table using pagination option
			@SuppressWarnings("static-access")
			public Reporter TC35866(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35866 Started..");

				try {
							
					obj.repAddData( "Groups Table Count for VIEW ALL Option", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					//driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
					//Write DB code here
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35866 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35866 Completed");
				}
				return obj;
			} //End of function TC35866	
			
			
			
			//RW-240_Groups_TC009_View Groups_Validate Pagination for option 10 for current page
			@SuppressWarnings("static-access")
			public Reporter TC35868(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35868 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 10", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35868 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35868 Completed");
				}
				return obj;
			} //End of function TC35868
			
			
			//RW-240_Groups_TC010_View Groups_Validate Pagination for option 10 for all the pages
			@SuppressWarnings("static-access")
			public Reporter TC35870(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35870 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 10", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
									
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE' and verify all pages", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");  //First time validation
					
					boolean bMultiPageExists = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", false,true);
					if(bMultiPageExists==true)
					{
						int iCurrentPage = 1;
						String sTotalPages = fnGetGUITextXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp);
						while(iCurrentPage<Integer.parseInt(sTotalPages))
						{
							ClickByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "Next button", false);
							fnVerifyNumofRecords("10");
							iCurrentPage++;
						}
					}
					else
					{
						obj.repAddData( "Verify Pagination for all pages", "Pagination for all pages with option 10 should be validated", "Pagination for all pages with option 10 cannot be validated as no of records are less than 10", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35870 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35870 Completed");
				}
				return obj;
			} //End of function TC35870
			
			//RW-240_Groups_TC011_View Groups_Validate Pagination for any page with option 10
			@SuppressWarnings("static-access")
			public Reporter TC35872(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35872 Started..");

				try {
							
					obj.repAddData("Validate pagination for any specific page with option 10", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					//fnVerifyNumofRecords("10");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp); 
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						int iRandomNum = fnRandomNum(1,iTotalPageNum);
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iRandomNum),"Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 10", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
					fnVerifyNumofRecords("10");
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35872 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35872 Completed");
				}
				return obj;
			} //End of function TC35872
			
			
			//RW-240_Groups_TC012_View Groups_Validate Pagination for option 20 for current page
			@SuppressWarnings("static-access")
			public Reporter TC35874(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35874 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 20", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("20");
					
					
					if(bElementFound==true || iRows>20)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35874 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35874 Completed");
				}
				return obj;
			} //End of function TC35874
			
			
			//RW-240_Groups_TC013_View Groups_Validate Pagination for option 20 for all the pages
			@SuppressWarnings("static-access")
			public Reporter TC35876(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35876 Started..");

				try {
							
					obj.repAddData("Validate Pagination for Option 20", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
									
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE' and verify all pages", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("20");  //First time validation
					
					boolean bMultiPageExists = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", false,true);
					if(bMultiPageExists==true)
					{
						int iCurrentPage = 1;
						String sTotalPages = fnGetGUITextXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp);
						while(iCurrentPage<Integer.parseInt(sTotalPages))
						{
							ClickByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "Next button", false);
							fnVerifyNumofRecords("20");
							iCurrentPage++;
						}
					}
					else
					{
						obj.repAddData( "Verify Pagination for all pages", "Pagination for all pages with option 20 should be validated", "Pagination for all pages with option 20 cannot be validated as no of records are less than 20", "Pass");
					}

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35876 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35876 Completed");
				}
				return obj;
			} //End of function TC35876
			
			//RW-240_Groups_TC014_View Groups_Validate Pagination for any page with option 20
			@SuppressWarnings("static-access")
			public Reporter TC35878(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35878 Started..");

				try {
							
					obj.repAddData("Validate pagination for any specific page with option 20", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
		
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					//fnVerifyNumofRecords("10");
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp); 
					
					if(bElementFound==true || iRows>20)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						int iRandomNum = fnRandomNum(1,iTotalPageNum);
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iRandomNum),"Page Number");
					}
					else
					{
						obj.repAddData( "Validate Pagination for any page with option 20", "Pagination for any page with option 20 should be validated", "Pagination for any page with option 20 cannot be validated as no of records are less than 20", "Pass");
					}
					
					fnVerifyNumofRecords("20");
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35878 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35878 Completed");
				}
				return obj;
			} //End of function TC35878
			
			
			//RW-240_Groups_TC015_View Groups_Validate for Page Counter and Navigation
			@SuppressWarnings("static-access")
			public Reporter TC35880(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35880 Started..");

				try {
							
					obj.repAddData("Validate Page Counter and Navigation", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();	
		
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option 'VIEW ALL'", "", "", "");
					select.selectByVisibleText("VIEW ALL");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,false);
					fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,false);
					
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					if(bElementFound==true || iRows>10)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option '10 PER PAGE' should be validated", "Pagination with option '10 PER PAGE' cannot be validated as no of records are less than 10", "Pass");
					}
					
					obj.repAddData("Select option '20 PER PAGE'", "", "", "");
					select.selectByVisibleText("20 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					
					if(bElementFound==true || iRows>20)
					{
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true,true);
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", true,true);
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option '20 PER PAGE' should be validated", "Pagination with option '20 PER PAGE' cannot be validated as no of records are less than 20", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35880 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35880 Completed");
				}
				return obj;
			} //End of function TC35880
			
			
			//RW-240_Groups_TC016_View Groups_Previous Button for navigation
			@SuppressWarnings("static-access")
			public Reporter TC35882(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35882 Started..");

				try {
							
					obj.repAddData("Validate Previous Button for navigation", "", "", "");
								
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, "1", "Page Number");
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true,true);
						//fnCheckEnableByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button"); //For temperory purpose, comment this code once improvement RW-314 gets fixed
						fnCheckDisbleByXPath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp, "'Previous' button");//Once implemented, uncomment this line
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35882 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35882 Completed");
				}
				return obj;
			} //End of function TC35882
			
			
			//RW-240_Groups_TC016_View Groups_Previous Button for navigation
			@SuppressWarnings("static-access")
			public Reporter TC35883(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35883 Started..");

				try {
							
					obj.repAddData("Validate Next Button for navigation", "", "", "");
								
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Groups Link",true);
					fnLoadingPageWait();
					
					boolean bElementFound = fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",false,true);
					int iRows = fnGetTableRowsCount(objRWModules.Common_ViewModules_Table_xp);
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");
					obj.repAddData("Select option '10 PER PAGE'", "", "", "");
					select.selectByVisibleText("10 PER PAGE");
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					fnVerifyNumofRecords("10");
					
					
					if(bElementFound==true || iRows>10)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
						
						fnCheckFieldDisplayByXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true,true);
						//fnCheckEnableByXPath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "'Next' button"); //For temperory purpose, comment this code once improvement RW-314 gets fixed
						fnCheckDisbleByXPath(RenowalkModules.Common_ViewModules_BtnNextLink_xp, "'Next' button");//Once implemented, uncomment this line
					}
					else
					{
						obj.repAddData( "Verify Pagination", "Pagination for any page with option 10 should be validated", "Pagination for any page with option 10 cannot be validated as no of records are less than 10", "Pass");
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35883 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35883 Completed");
				}
				return obj;
			} //End of function TC35883
			
			
			

			
			
			//RW-241_Groups_TC001_ADD GROUP_Verify to see ADD GROUP form
			@SuppressWarnings("static-access")
			public Reporter TC35887(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35887 Started..");

				try {
					obj.repAddData( "Adding the Group", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					

					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();
					
					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGroupName_xp,"Group Name text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputDescription_xp, "Description text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGLCode_xp, "GL Code text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp, "Photo Folder Name text box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludeFlooring_xp, "Include Flooring Check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludeComment_xp, "Include Comment check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_CheckBoxDefaultPhotoGroup_xp, "Default Photo check box", true, true);
								
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}

				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35887 Failed!", e );
				}
				finally {
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35887 Completed");
				}
				return obj;
			} //End of function TC35887
			
			//RW-241_Groups_TC002_ADD GROUP_Verify to see ADD GROUP form Required fields
			@SuppressWarnings("static-access")
			public Reporter TC35889(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35889 Started..");

				try {
					obj.repAddData( "Required Fields label", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGroupNameFieldRequired_xp,"Group Name Field required", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputDescriptionFieldRequired_xp, "Description Field required", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberPerHouseFieldRequired_xp, "Max Number per House Field required", true, true);
					
							
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}

				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35889 Failed!", e );
				}
				finally {
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35889 Completed");
				}
				return obj;
			} //End of function TC35889
			
			
			//RW-241_Groups_TC003_ADD GROUP_Verify to see the prompt for required fields
			@SuppressWarnings("static-access")
			public Reporter TC35891(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35891 Started..");

				try {

					obj.repAddData( "Validating the Group Page", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					//Check for Group Name Validation
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGroupName_xp, "Group Name text box", true, true);

					String sGroupName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputGroupName_xp)).sendKeys(sGroupName);
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputGroupName_xp)).clear();
					
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgGroupNameRequired_xp, "Group name Error Message", true, true);

					String sGroupNameMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgGroupNameRequired_xp)).getText().toString().trim();
					if(sGroupNameMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			

					//Check for Description field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputDescription_xp, "Description text box", true, true);

					String sDescription = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputDescription_xp)).sendKeys(sDescription);
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputDescription_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgDescriptionRequired_xp, "Description Error Message", true, true);

					String sDescriptionMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgDescriptionRequired_xp)).getText().toString().trim();
					if(sDescriptionMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}			

					//Check for Max Number per House field Validation
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);

					String sMaxNumberPerHouse = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).sendKeys(sMaxNumberPerHouse);
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).clear();

					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgMaxNumberPerHouseRequired_xp, "max Number per House Error Message", true, true);

					String sMaxNumberPerHouseMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgMaxNumberPerHouseRequired_xp)).getText().toString().trim();
					if(sMaxNumberPerHouseMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgRequired_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgRequired_msg+"' not shown", "Fail");
					}	
					
					

					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35891 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35891 Completed");
				}
				return obj;
			} //End of function TC35891	
			
			
			//RW-241_Groups_TC004_ADD GROUP_Verify to see Items & Groups Items column
			@SuppressWarnings("static-access")
			public Reporter TC35893(Reporter obj) throws Exception
			{	
				log.info("Execution of Function TC35893 Started..");

				try {
							
					obj.repAddData( "Check Column names", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
		
					fnCheckFieldDisplayByXpath(RenowalkModules.Groups_AddGroup_ItemsColumnName_xp,"'Items' label",true,true);
					fnCheckFieldDisplayByXpath(RenowalkModules.Groups_AddGroup_GroupItemsColumnName_xp,"'Group Items' label",true,true);
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35893 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35893 Completed");
				}
				return obj;
			} //End of function TC35893	
			
			//RW-241_Groups_TC005_ADD GROUP_Items column Search Criteria
			@SuppressWarnings("static-access")
			public Reporter TC35895(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35895 Started..");

				try {

					obj.repAddData( "Verifying Item Column Searching", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputItemSearch_xp, "Items search text box", true, true);

					String sItemName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputItemSearch_xp)).sendKeys(sItemName);
					ClickByXpath(objRWModules.Groups_AddGroup_BtnSearchItems_xp, "Search button",true); 
					

					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35895 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35895 Completed");
				}
				return obj;
			} //End of function TC35895	
			
			//RW-241_Groups_TC008_ADD GROUP_Verify option
			@SuppressWarnings("static-access")
			public Reporter TC35900(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35900 Started..");

				try {

					obj.repAddData( "Verifying Include Paint Option check box", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludeFlooring_xp, "Include Flooring Check box",false);
					
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludePaint_xp,"'Include Paint' check box",true,true);				

					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35900 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35900 Completed");
				}
				return obj;
			} //End of function TC35900	
			
			
			//RW-241_Groups_TC010_ADD GROUP_Clicking SAVE with required field
			@SuppressWarnings("static-access")
			public Reporter TC35904(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35904 Started..");

				try {

					obj.repAddData( "Saving Group", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					//Fill Group Name Validation
					int iRandomNum = fnRandomNum(1,10000);
					String sGroupName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Groups_AddGroup_InputGroupName_xp, sGroupName+iRandomNum, "Group Name");
					
					//Fill description
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputDescription_xp, "Description text box", true, true);

					String sDescription = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputDescription_xp)).sendKeys(sDescription);

					//Fill Max Number per House field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);

					String sMaxNumberPerHouse = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).sendKeys(sMaxNumberPerHouse);
					
					//Fill GL Code field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGLCode_xp, "GL Code text box", true, true);

					String sGLCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputGLCode_xp)).sendKeys(sGLCode);
					
					//Fill Photo Folder Name
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp, "Photo Folder Name text box", true, true);

					String sPhotoFolderName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp)).sendKeys(sPhotoFolderName);
					
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludeFlooring_xp, "Include flooring checkBox", true);
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxDefaultPhotoGroup_xp, "Check default photo group", true);
					
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35904 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35904 Completed");
				}
				return obj;
			} //End of function TC35904
			
			
			//RW-241_Groups_TC010_ADD GROUP_Clicking SAVE with non required fields
			@SuppressWarnings("static-access")
			public Reporter TC35905(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35905 Started..");

				try {

					obj.repAddData( "Saving Group with only non required fields", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();
					//fnVerifyCancelForm(1);

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					
					//Fill GL Code field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGLCode_xp, "GL Code text box", true, true);

					String sGLCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputGLCode_xp)).sendKeys(sGLCode);
					
					//Fill Photo Folder Name
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp, "Photo Folder Name text box", true, true);

					String sPhotoFolderName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp)).sendKeys(sPhotoFolderName);
					
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludeFlooring_xp, "Include flooring checkBox", true);
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxDefaultPhotoGroup_xp, "Check default photo group", true);
					
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  
					fnCheckFieldDisplayByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save Button", true, true);
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35905 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35905 Completed");
				}
				return obj;
			} //End of function TC35905
			
			//RW-241_Groups_TC012_ADD GROUP_Clicking CANCEL with value
			@SuppressWarnings("static-access")
			public Reporter TC35906(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35906 Started..");

				try {

					obj.repAddData( "Cancel Adding Group", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					//Fill Group Name Validation
					int iRandomNum = fnRandomNum(1,10000);
					String sGroupName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Groups_AddGroup_InputGroupName_xp, sGroupName+iRandomNum, "Group Name");
					
					//Fill description
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputDescription_xp, "Description text box", true, true);

					String sDescription = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputDescription_xp)).sendKeys(sDescription);

					//Fill Max Number per House field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);

					String sMaxNumberPerHouse = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).sendKeys(sMaxNumberPerHouse);
					
					//Fill GL Code field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGLCode_xp, "GL Code text box", true, true);

					String sGLCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputGLCode_xp)).sendKeys(sGLCode);
					
					//Fill Photo Folder Name
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp, "Photo Folder Name text box", true, true);

					String sPhotoFolderName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp)).sendKeys(sPhotoFolderName);
					
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludeFlooring_xp, "Include flooring checkBox", true);
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxDefaultPhotoGroup_xp, "Check default photo group", true);
					
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35906 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35906 Completed");
				}
				return obj;
			} //End of function TC35906
			
			
			//RW-241_Groups_TC013_ADD GROUP_Clicking CANCEL without any value
			@SuppressWarnings("static-access")
			public Reporter TC35915(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35915 Started..");

				try {
					obj.repAddData( "Cancelling Add Group", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					

					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();
					
					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);								
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
				}

				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35915 Failed!", e );
				}
				finally {
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35915 Completed");
				}
				return obj;
			} //End of function TC35915
			
			//RW-241_Groups_TC014_ADD GROUP_Verify values into Max Numbers Per House field 
			@SuppressWarnings("static-access")
			public Reporter TC35907(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35907 Started..");

				try {

					obj.repAddData( "Verifying Max Number per House Field", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					

					//Fill Max Number per House field with Number
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);

					String sMaxNumberPerHouseNumeric = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).sendKeys(sMaxNumberPerHouseNumeric);
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).clear();
					
					//Fill Max Number per House field with Non Numeric
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);

					String sMaxNumberPerHouseNonNumeric = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).sendKeys(sMaxNumberPerHouseNonNumeric);
					
	
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgNumericValueRequired_xp, "max Number per House Error Message", true, true);

					String sMaxNumberPerHouseMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgNumericValueRequired_xp)).getText().toString().trim();
					if(sMaxNumberPerHouseMsg.equalsIgnoreCase(objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg+"' should be shown", "'"+objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg+"' should be shown","'"+ objAppMessages.Property_AddProperty_ErrorMsgNumberBedrooms_msg+"' not shown", "Fail");
					}	
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35907 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35907 Completed");
				}
				return obj;
			} //End of function TC35907
			
			
			//Verify that the user may not add a group of the same name  
			@SuppressWarnings("static-access")
			public Reporter TC35908(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35908 Started..");

				try {

					obj.repAddData( "Verify Duplicate Group name", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					//Fill Group Name Validation
					int iRandomNum = fnRandomNum(1,10000);
					String sGroupName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Groups_AddGroup_InputGroupName_xp, sGroupName+iRandomNum, "Group Name");
					
					//Fill description
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputDescription_xp, "Description text box", true, true);

					String sDescription = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputDescription_xp)).sendKeys(sDescription);

					//Fill Max Number per House field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);

					String sMaxNumberPerHouse = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).sendKeys(sMaxNumberPerHouse);
					
					//Fill GL Code field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGLCode_xp, "GL Code text box", true, true);

					String sGLCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputGLCode_xp)).sendKeys(sGLCode);
					
					//Fill Photo Folder Name
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp, "Photo Folder Name text box", true, true);

					String sPhotoFolderName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp)).sendKeys(sPhotoFolderName);
					
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludeFlooring_xp, "Include flooring checkBox", true);
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxDefaultPhotoGroup_xp, "Check default photo group", true);
					
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					
					//Adding the same Group name
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();
					//fnVerifyCancelForm(1);
					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					//Filling same Group Name
					SendKeyByXpath(objRWModules.Groups_AddGroup_InputGroupName_xp, sGroupName+iRandomNum, "Group Name");
					
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgDuplicate_xp, "Duplicate Group Name Error Message", true, true);

					String sGroupNameDuplicateMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgDuplicate_xp)).getText().toString().trim();
					if(sGroupNameDuplicateMsg.equalsIgnoreCase(objAppMessages.Groups_AddGroup_ErrorMsgDuplicateGroupName_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Groups_AddGroup_ErrorMsgDuplicateGroupName_msg+"' should be shown", "'"+objAppMessages.Groups_AddGroup_ErrorMsgDuplicateGroupName_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Groups_AddGroup_ErrorMsgDuplicateGroupName_msg+"' should be shown","'"+ objAppMessages.Groups_AddGroup_ErrorMsgDuplicateGroupName_msg+"' not shown", "Fail");
					}
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35908 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35908 Completed");
				}
				return obj;
			} //End of function TC35908
			
			//Verify if the user entered ADD GROUP form with character length more than 80, it should throw an error  
			@SuppressWarnings("static-access")
			public Reporter TC35909(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35909 Started..");

				try {

					obj.repAddData( "Verify Group form with character length more than 80", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					//Fill Group Name Validation with more than 80 characters
					int iRandomNum = fnRandomNum(1,10000);
					String sGroupName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Groups_AddGroup_InputGroupName_xp, sGroupName+iRandomNum, "Group Name");
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLengthGroupName_xp, "Group Name maximum Length Error Message", true, true);

					String sGroupNameMaxLengthMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLengthGroupName_xp)).getText().toString().trim();
					if(sGroupNameMaxLengthMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' not shown", "Fail");
					}
					
					
					//Fill description with more than 80 characters
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputDescription_xp, "Description text box", true, true);

					String sDescription = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputDescription_xp)).sendKeys(sDescription);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLengthDescription_xp, "Description maximum Length Error Message", true, true);
					
					String sDescriptionMaxLengthMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLengthDescription_xp)).getText().toString().trim();
					if(sDescriptionMaxLengthMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' not shown", "Fail");
					}
					
					
					//Fill Max Number per House field with more than 80 characters
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);

					String sMaxNumberPerHouse = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).sendKeys(sMaxNumberPerHouse);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLengthMaxNumberPerHouse_xp, "Maximum number per House Maxiumum Length Error Message", true, true);
					
					String sMaxNumberPerHouseMaxLengthMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLengthMaxNumberPerHouse_xp)).getText().toString().trim();
					if(sMaxNumberPerHouseMaxLengthMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' not shown", "Fail");
					}
					
					
					//Fill GL Code field with more than 80 characters
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGLCode_xp, "GL Code text box", true, true);

					String sGLCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputGLCode_xp)).sendKeys(sGLCode);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLengthGLCode_xp, "GLCode Maxiumum Length Error Message", true, true);
					
					String sGLCodeMaxLengthMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLengthGLCode_xp)).getText().toString().trim();
					if(sGLCodeMaxLengthMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' not shown", "Fail");
					}
					
					//Fill Photo Folder Name with more than 80 characters
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp, "Photo Folder Name text box", true, true);

					String sPhotoFolderName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp)).sendKeys(sPhotoFolderName);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLength_PhotoFolderName_xp, "Photo Folder Name maxiumum Length Error Message", true, true);
					
					String sPhotoFolderNameMaxLengthMsg = driver.findElement(By.xpath(objRWModules.Groups_AddGroup_ErrorMsgMaximumLength_PhotoFolderName_xp)).getText().toString().trim();
					if(sPhotoFolderNameMaxLengthMsg.equalsIgnoreCase(objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg))
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' shown successfully", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Required Error Message", "'"+objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' should be shown","'"+ objAppMessages.Common_AddModule_ErrorMsgMaxLength_msg+"' not shown", "Fail");
					}
					
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35909 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35909 Completed");
				}
				return obj;
			} //End of function TC35909
			
			//RW-241_Groups_TC016_ADD GROUP_Validate ADD GROUP form with characters length 80 and special characters except Max Number Per House field
			@SuppressWarnings("static-access")
			public Reporter TC35910(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35910 Started..");

				try {

					obj.repAddData( "Saving Group with special characters", "", "", "");

					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					//Fill Group Name Validation
					int iRandomNum = fnRandomNum(1,10000);
					String sGroupName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					SendKeyByXpath(objRWModules.Groups_AddGroup_InputGroupName_xp, sGroupName+iRandomNum, "Group Name");
					
					//Fill description
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputDescription_xp, "Description text box", true, true);

					String sDescription = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputDescription_xp)).sendKeys(sDescription);

					//Fill Max Number per House field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp, "Maximum Number per House text box", true, true);

					String sMaxNumberPerHouse = mTestPhaseData.get(TestDriver.iTC_ID).get("NumberBedRooms").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputMaxNumberperHouse_xp)).sendKeys(sMaxNumberPerHouse);
					
					//Fill GL Code field
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputGLCode_xp, "GL Code text box", true, true);

					String sGLCode = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputGLCode_xp)).sendKeys(sGLCode);
					
					//Fill Photo Folder Name
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp, "Photo Folder Name text box", true, true);

					String sPhotoFolderName = mTestPhaseData.get(TestDriver.iTC_ID).get("Name").toString().trim();
					driver.findElement(By.xpath(objRWModules.Groups_AddGroup_InputPhotoFolderName_xp)).sendKeys(sPhotoFolderName);
					
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxIncludeFlooring_xp, "Include flooring checkBox", true);
					ClickByXpath(objRWModules.Groups_AddGroup_CheckBoxDefaultPhotoGroup_xp, "Check default photo group", true);
					
					
					//*This field is required
					ClickByXpath(objRWModules.Common_AddModule_BtnSave_xp, "Save button",false);  //post condition
					fnVerifyDialogBox("Add",0);
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC35910 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}

					log.info("Execution of Function TC35910 Completed");
				}
				return obj;
			} //End of function TC35910
			
			//RW-241_Groups_TC018_ADD GROUP_Verify Current Groups available
			@SuppressWarnings("static-access")
			public Reporter TC35912(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35912 Started..");

				try {

					obj.repAddData( "Viewing the Groups page", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_AddForm_xp, "Add Group Form", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Common_ViewModules_Table_xp, "Groups Table", true, true);
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35912 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC35912 Completed");
				}
				return obj;
			} //End of function TC35912
			
			@SuppressWarnings("static-access")
			public Reporter TC35896(Reporter obj) throws Exception {
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC35896 Started..");

				tryblock: try {

					obj.repAddData( "Viewing the Groups page", "", "", "");
					fnSelectCorpOffice(sCorporation, sOffice);
					ClickByXpath(objRWModules.Groups_GenGroups_LinkGroupOption_xp, "Group Link",true);
					fnLoadingPageWait();
					

					ClickByXpath(objRWModules.Groups_ViewGroups_BtnAddGroup_xp, "Add Group button",true);
					
					if(fnCheckFieldDisplayByXpath(objRWModules.Groups_AddGroup_SortableItemList_xp, "Sortable List Area", true, true))
					{ }
					else { break tryblock; }
					
					ClickElementDragTo(objRWModules.Groups_AddGroup_FirstItemVisible_xp, objRWModules.Groups_AddGroup_SortableItemList_xp, "xpath", "xpath");					
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC35896 Failed!", e );
				}
				return obj;
			}
			//End of Function TC35896
			
			///////////////////////////////////////Group Tests End Here///////////////////////////////////////////////////////////////////////////
			
			
			
			///////////////////////////////////////SetContext Tests Begin Here///////////////////////////////////////////////////////////////////////////
			
			//RW-93_SetContext_TC001_Set Corporation and Offices Context_View Drop down boxes
			@SuppressWarnings("static-access")
			public Reporter TC27130(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27130 Started..");

				try {

					obj.repAddData( "Viewing the Home page", "", "", "");
					//fnSelectCorpOffice(sCorporation, sOffice);
					fnCheckFieldDisplayByXpath(objRWModules.Common_AllModules_ComboCorporateSelect_xp, "Corporation Menu", true, true);
					
					//May need to include some sort of check for the office menu:
					//fnCheckFieldDisplayByXpath(objRWModules.Common_AllModules_ComboOfficeSelect_xp, "Office Menu", true, true);
					
					

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27130 Failed!", e );
				}
				finally {

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27130 Completed");
				}
				return obj;
			} //End of function TC27130
			
			
			//RW-93_SetContext_TC002_Set Corporation and Offices Context_Verify for corporation drop down box
			@SuppressWarnings("static-access")
			public Reporter TC27131(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27131 Started..");

				try {
							
					obj.repAddData( "Viewing the Corporations in the Corporations field", "", "", "");
					
					//open the menu:
					ClickByXpath(objRWModules.Common_AllModules_ComboCorporateSelect_xp,"Corporation Drop Down", true);
					
					//check to see that the values are sorted:
					fnCheckDropDownSorting(objRWModules.Common_AllModules_ComboCorporateName_xp,"Corporation", "Select");
					
					//close the menu:
					ClickByXpath(objRWModules.Common_AllModules_ComboCorporateSelect_xp,"Corporation Drop Down", false);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27131 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27131 Completed");
				}
				return obj;
			} //End of function TC27131
			
			
			//RW-93_SetContext_TC003_Set Corporation and Offices Context_Verify for Office drop down box for a Corporation
			@SuppressWarnings("static-access")
			public Reporter TC27132(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27132 Started..");

				try {
							
					obj.repAddData( "Viewing the Office in the Offices field", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					//open the offices pull-down
					ClickByXpath(objRWModules.Common_AllModules_ComboOfficeSelect_xp,"Corporation Drop Down", true);
					
					//check to see that the values are sorted in ascending order:
					fnCheckDropDownSorting(objRWModules.Common_AllModules_ComboOfficeCode_xp, "Office", "Select");
					
					//close the offices pull-down
					ClickByXpath(objRWModules.Common_AllModules_ComboOfficeSelect_xp,"Corporation Drop Down", false);
					
					//Need to add DB code to verify office data
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27132 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27132 Completed");
				}
				return obj;
			} //End of function TC27132
			
			
			//RW-93_SetContext_TC004_Set Corporation and Offices Context_Check default value in Corporation Select Box
			@SuppressWarnings("static-access")
			public Reporter TC27133(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27133 Started..");

				try {
							
					obj.repAddData( "Verifying default value in Corporations field", "", "", "");
					
					driver.navigate().refresh();
					
					fnCheckFieldDisplayByXpath(objRWModules.Common_AllModules_ComboCorporateText_xp, "Select", true, true);
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27133 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27133 Completed");
				}
				return obj;
			} //End of function TC27133
			
			
			//RW-93_SetContext_TC006_Set Corporation and Offices Context_Verify for Office text box for a single Office
			@SuppressWarnings("static-access")
			public Reporter TC27135(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC27135 Started..");

				try {
							
					obj.repAddData( "Verifying Office text box when only one Office in Corporation", "", "", "");
					
					//Selects a corporation with a single office
					fnSelectCorpOffice("aaa", sOffice);
					
					fnCheckFieldDisplayByXpath(objRWModules.Common_AllModules_ComboOfficeText_xp, "Text Box", true, true);
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC27135 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC27135 Completed");
				}
				return obj;
			} //End of function TC27135
			
			
			
			///////////////////////////////////////SetContext Tests End Here///////////////////////////////////////////////////////////////////////////
			
			
			///////////////////////////////////////ToolOptions Starts End Here///////////////////////////////////////////////////////////////////////////
			
			
			//RW-248_Properties_Management_TC001_Project Tools Visible
			@SuppressWarnings("static-access")
			public Reporter TC36914(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36914 Started..");

				try {
							
					obj.repAddData( "Verifying that a variety of project tools are displayed", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					//Navigate to Properties page:
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp,"Property Link", true);
					
					//Select the top Property:
					ClickByXpath(objRWModules.Property_ToolOptions_SelectPropertyNotWalked_xp,"Property Link", true);
					
					//Click on Project Tools Tab:
					ClickByXpath(objRWModules.Property_ToolOptions_ProjectToolsTab_xp,"Property Link", true);
					
					//Verify Project Tools Buttons:
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_ExportCSV_xp, "Export CSV Button", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_PDF_xp, "PDF Button", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_ScopeAndPhotos_xp, "Scope and Photos Button", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_ApprovedScope_xp, "Approved Scope Button", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_PhotoLink_xp, "Photo Link Button", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_BidPhotoPDF_xp, "Bid Photos Button", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_PhotosZip_xp, "Photos Zip Button", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_BuildHDQuote_xp, "Build HD Quote Button", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Property_ProjectTools_SubmitBid_xp, "Submit Bid Button", true, true);	
					
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36914 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36914 Completed");
				}
				return obj;
			} //End of function TC36914
			
			
			//RW-248_Properties_Management_TC003_Project Tools buttons Shown in Disabled Mode
			@SuppressWarnings("static-access")
			public Reporter TC36916(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36916 Started..");

				try {
							
					obj.repAddData( "Verifying that a variety of project tools are displayed", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					//Navigate to Properties page:
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp,"Property Link", true);
					
					//Select the top Property:
					ClickByXpath(objRWModules.Property_ToolOptions_SelectPropertyNotWalked_xp,"Property item", true);
					
					//Click on Project Tools Tab:
					ClickByXpath(objRWModules.Property_ToolOptions_ProjectToolsTab_xp,"Project Tools tab", true);
					
					//Check that buttons are disabled:
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_ExportCSV_xp, "Export CSV Button");
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_PDF_xp, "PDF Button");
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_ScopeAndPhotos_xp, "Scope and Photos Button");
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_ApprovedScope_xp, "Approved Scope Button");
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_PhotoLink_xp, "Photo Link Button");
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_BidPhotoPDF_xp, "Bid Photos Button");
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_PhotosZip_xp, "Photos Zip Button");
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_BuildHDQuote_xp, "Build HD Quote Button");
					fnCheckDisbleByXPath(objRWModules.Property_ProjectTools_SubmitBid_xp, "Submit Bids Button");	
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36916 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36916 Completed");
				}
				return obj;
			} //End of function TC36916
			
			
			//RW-248_Properties_Management_TC004_Check CSV V2, Final Photos PDF, etc options are not available
			@SuppressWarnings("static-access")
			public Reporter TC36917(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36917 Started..");

				try {
							
					obj.repAddData( "Verifying that certain project tools are not displayed", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					//Navigate to Properties page:
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp,"Property Link", true);
					
					//Select the top Property:
					ClickByXpath(objRWModules.Property_ToolOptions_SelectPropertyNotWalked_xp,"Property item", true);
					
					//Click on Project Tools Tab:
					ClickByXpath(objRWModules.Property_ToolOptions_ProjectToolsTab_xp,"Property tab", true);
					
					//Verify Project Tools Buttons:
					fnCheckFieldDoesNotExistByXpath(objRWModules.Property_ProjectTools_ExportCSV2_xp, "Export CSV2 Button not shown", true);
					fnCheckFieldDoesNotExistByXpath(objRWModules.Property_ProjectTools_ExportCSV3_xp, "Export CSV3 not shown", true);
					fnCheckFieldDoesNotExistByXpath(objRWModules.Property_ProjectTools_FinalPhotosPDF_xp, "Final Photos PDF Button not shown", true);
					fnCheckFieldDoesNotExistByXpath(objRWModules.Property_ProjectTools_PunchList_xp, "Punch List not shown", true);
					fnCheckFieldDoesNotExistByXpath(objRWModules.Property_ProjectTools_InvoiceProject_xp, "Invoice Project Tools Button not shown", true);
					
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36914 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36917 Completed");
				}
				return obj;
			} //End of function TC36917
			
			
			
			
			//RW-248_Properties_Management_TC005_Verify Property Docs Tools
			@SuppressWarnings("static-access")
			public Reporter TC36918(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36918 Started..");

				try {
							
					obj.repAddData( "Verifying that a variety of project tools are displayed", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					//Navigate to Properties page:
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp,"Property Link", true);
					
					//Select the top Property:
					ClickByXpath(objRWModules.Property_ToolOptions_SelectPropertyNotWalked_xp,"Property item", true);
					
					//Click on Project Tools Tab:
					ClickByXpath(objRWModules.Property_ToolOptions_ProjectToolsTab_xp,"Project Tools tab", true);
					
					List<String> arrButtons = new ArrayList<String>();
					arrButtons.clear();
					arrButtons.add(objRWModules.Property_ProjectTools_ExportCSV_xp);
					arrButtons.add(objRWModules.Property_ProjectTools_PDF_xp);
					arrButtons.add(objRWModules.Property_ProjectTools_ScopeAndPhotos_xp);
					arrButtons.add(objRWModules.Property_ProjectTools_ApprovedScope_xp);
					fnCheckButtonsUnderHeader(objRWModules.Property_ProjectTools_PropertyDocsHeader_xp, arrButtons, "Project Docs" , true);
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36918 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36918 Completed");
				}
				return obj;
			} //End of function TC36918
			
			
			
			//RW-248_Properties_Management_TC006_Verify Photo Docs Tools
			@SuppressWarnings("static-access")
			public Reporter TC36919(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36919 Started..");

				try {
							
					obj.repAddData( "Verifying that a variety of project tools are displayed", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					//Navigate to Properties page:
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp,"Property Link", true);
					
					//Select the top Property:
					ClickByXpath(objRWModules.Property_ToolOptions_SelectPropertyNotWalked_xp,"Property item", true);
					
					//Click on Project Tools Tab:
					ClickByXpath(objRWModules.Property_ToolOptions_ProjectToolsTab_xp,"Project Tools tab", true);
					
					List<String> arrButtons = new ArrayList<String>();
					arrButtons.clear();
					arrButtons.add(objRWModules.Property_ProjectTools_PhotoLink_xp);
					arrButtons.add(objRWModules.Property_ProjectTools_BidPhotoPDF_xp);
					arrButtons.add(objRWModules.Property_ProjectTools_PhotosZip_xp);
					fnCheckButtonsUnderHeader(objRWModules.Property_ProjectTools_PhotoDocsHeader_xp, arrButtons, "Photo Docs" , true);
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36919 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36919 Completed");
				}
				return obj;
			} //End of function TC36919
			
			
			//RW-248_Properties_Management_TC007_Verify Product Ordering Tools
			@SuppressWarnings("static-access")
			public Reporter TC36920(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36920 Started..");

				try {
							
					obj.repAddData( "Verifying that a variety of project tools are displayed", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					//Navigate to Properties page:
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp,"Property Link", true);
					
					//Select the top Property:
					ClickByXpath(objRWModules.Property_ToolOptions_SelectPropertyNotWalked_xp,"Property item", true);
					
					//Click on Project Tools Tab:
					ClickByXpath(objRWModules.Property_ToolOptions_ProjectToolsTab_xp,"Project Tools tab", true);
					
					List<String> arrButtons = new ArrayList<String>();
					arrButtons.clear();
					arrButtons.add(objRWModules.Property_ProjectTools_BuildHDQuote_xp);
					fnCheckButtonsUnderHeader(objRWModules.Property_ProjectTools_ProductOrderingHeader_xp, arrButtons, "Photo Docs" , true);
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36920 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36920 Completed");
				}
				return obj;
			} //End of function TC36920
			
			
			//RW-248_Properties_Management_TC008_Verify Home Depot Bids
			@SuppressWarnings("static-access")
			public Reporter TC36921(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36921 Started..");

				try {
							
					obj.repAddData( "Verifying that a variety of project tools are displayed", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					//Navigate to Properties page:
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp,"Property Link", true);
					
					//Select the top Property:
					ClickByXpath(objRWModules.Property_ToolOptions_SelectPropertyNotWalked_xp,"Property item", true);
					
					//Click on Project Tools Tab:
					ClickByXpath(objRWModules.Property_ToolOptions_ProjectToolsTab_xp,"Project Tools tab", true);
					
					List<String> arrButtons = new ArrayList<String>();
					arrButtons.clear();
					arrButtons.add(objRWModules.Property_ProjectTools_SubmitBid_xp);
					fnCheckButtonsUnderHeader(objRWModules.Property_ProjectTools_HomeDepotBidsHeader_xp, arrButtons, "Home Depot Bids" , true);
					
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36921 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36921 Completed");
				}
				return obj;
			} //End of function TC36921
			
			
			
			///////////////////////////////////////ToolOptions Tests End Here///////////////////////////////////////////////////////////////////////////
			
			
			
			//bxk8854
			///////////////////////////////////////Row Type Test Starts here///////////////////////////////////////////////////////////////////////////
			
			//RW-279_Items_TC001_Row Type_Verify that select if default under Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36781(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36781 Started..");

				try {
							
					obj.repAddData( "Verify that When ADD ITEM is Clicked, the default Row Type is 'Select'", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					List<WebElement> arrPageSize = rowType.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					//Verify the values in the select Box
					fnVerifyComboBoxValues(arrPageSize, 0, "Select");
					fnVerifyComboBoxValues(arrPageSize, 1, "Always Added");
					fnVerifyComboBoxValues(arrPageSize, 2, "Basic Comment");
					fnVerifyComboBoxValues(arrPageSize, 3, "Default Package Kit");
					fnVerifyComboBoxValues(arrPageSize, 4, "Increment Row Type");
					fnVerifyComboBoxValues(arrPageSize, 5, "Multiple Sku Display");
					fnVerifyComboBoxValues(arrPageSize, 6, "Optional Increment Row Type");
					fnVerifyComboBoxValues(arrPageSize, 7, "Package Row Type");
					fnVerifyComboBoxValues(arrPageSize, 8, "Tenant Only");
					fnVerifyComboBoxValues(arrPageSize, 9, "Whole Budget Percent");
					fnVerifyComboBoxValues(arrPageSize, 10, "Whole House SqFT");			
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36781 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36781 Completed");
				}
				return obj;
			} //End of function TC36781
			
			
			//RW-279_Items_TC002_Row Type_Verify the format of the page after selecting "Always Added" for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36782(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36782 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Always Added' for Row Type", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select Always Added from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Always Added");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPriceOverride_xp,"Price Override check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm,"Default Material text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm,"Default Labor text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm,"Defaault Hours text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					
					//verifying the Required check box
					fnCheckSelectedCheckBoxByXPath(objRWModules.Items_AddItem_CheckBoxPriceOverride_xp, "Price Override");
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36782 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36782 Completed");
				}
				return obj;
			} //End of function TC36782
			
			//RW-279_Items_TC003_Row Type_Verify the format of the page after selecting Basic Comment for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36783(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36783 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Basic Comment' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select Always Added from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Basic Comment");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxRequired_xp,"Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPriceOverride_xp,"Price Override check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm,"Default Material text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm,"Default Labor text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm,"Default Hours text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(RenowalkModules.Items_AddItem_OpenCommentsSection_xp,"+",true);
					fnCheckFieldDisplayByName(RenowalkModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					
					//verifying the Required check box
					fnCheckSelectedCheckBoxByXPath(objRWModules.Items_AddItem_CheckBoxPriceOverride_xp, "Price Override");
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36783 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36783 Completed");
				}
				return obj;
			} //End of function TC36783
			
			//RW-279_Items_TC004_Row Type_Verify the format of the page after selecting Default Package Kit for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36784(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36784 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Default Package Kit' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select 'Default Package Kit' from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Default Package Kit");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxRequired_xp,"Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(objRWModules.Items_AddItem_OpenCommentsSection_xp,"Open Description",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					
					ClickByXpath(objRWModules.Items_AddItem_ProductsPanelHeader_xp,"Open Products",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultQty_nm,"Default Quantity",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_SKU_nm,"SKU",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MultiPakSKU_nm,"Multi Pak SKU",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultStoreNumber_nm,"Default Store Number",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Description_nm,"Description",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductDefaultLabor_nm,"Product Default Labor",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductDefaultHours_nm,"Product Default Hours",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductGLCode_nm,"Product GL Code",true,true);
	
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36784 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36784 Completed");
				}
				return obj;
			} //End of function TC36784
			
			
			//RW-279_Items_TC005_Row Type_Verify the format of the page after selecting Increment Row Type for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36785(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36785 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Increment Row Type' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select 'Increment Row Type' from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Increment Row Type");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxRequired_xp,"Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm,"Default Material text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm,"Default Labor text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm,"Default Hours text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(objRWModules.Items_AddItem_OpenCommentsSection_xp,"Open Description",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36785 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36785 Completed");
				}
				return obj;
			} //End of function TC36785
			
			//RW-279_Items_TC006_Row Type_Verify the format of the page after selecting Multiple Sku Display for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36786(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36786 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Multiple SKU' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select 'Multiple SKU' from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Multiple Sku Display");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxRequired_xp,"Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(objRWModules.Items_AddItem_OpenCommentsSection_xp,"Open Description",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					
					//Product Comments
					ClickByXpath(objRWModules.Items_AddItem_ProductsPanelHeader_xp,"Open Products",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_SKU_nm,"SKU",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MultiPakSKU_nm,"Multi Pak SKU",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultStoreNumber_nm,"Default Store Number",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Description_nm,"Description",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductDefaultLabor_nm,"Product Default Labor",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductDefaultHours_nm,"Product Default Hours",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductGLCode_nm,"Product GL Code",true,true);
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36786 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36786 Completed");
				}
				return obj;
			} //End of function TC36786
			
			//RW-279_Items_TC007_Verify the format of the page after selecting Optional Increment Display for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36787(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36787 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Optional Increment Display' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select 'Optional Increment Display' from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Optional Increment Row Type");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxRequired_xp,"Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(objRWModules.Items_AddItem_OpenCommentsSection_xp,"Open Description",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultPrice_nm,"Default Price",true,true);
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36787 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36787 Completed");
				}
				return obj;
			} //End of function TC36787
			
			
			//RW-279_Items_TC008_Verify the format of the page after selecting Package Row Type for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36788(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36788 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Package Row Type' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select 'Package Row Type' from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Package Row Type");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxRequired_xp,"Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(objRWModules.Items_AddItem_OpenCommentsSection_xp,"Open Description",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					
					//Product Comments
					ClickByXpath(objRWModules.Items_AddItem_ProductsPanelHeader_xp,"Open Products",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_SKU_nm,"SKU",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MultiPakSKU_nm,"Multi Pak SKU",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MultiPakQty_nm,"Multi Pak Qty",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultStoreNumber_nm,"Default Store Number",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Description_nm,"Description",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductDefaultLabor_nm,"Product Default Labor",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductDefaultHours_nm,"Product Default Hours",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ProductGLCode_nm,"Product GL Code",true,true);
					
					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36788 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36788 Completed");
				}
				return obj;
			} //End of function TC36788
			
			//RW-279_Items_TC009_Verify the format of the page after Selecting Tenant Only for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36789(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36789 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Tenant Only' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select 'Tenant Only' from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Tenant Only");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxRequired_xp,"Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPriceOverride_xp,"Price Override check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultMaterial_nm,"Default Material text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultLabor_nm,"Default Labor text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm,"Default Hours text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(objRWModules.Items_AddItem_OpenCommentsSection_xp,"Open Description",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultPrice_nm,"Default Price",true,true);

					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36789 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36789 Completed");
				}
				return obj;
			} //End of function TC36789
			
			
			//RW-279_Items_TC010_Verify the format of the page after selecting Whole Budget Percent for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36790(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36790 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Whole Budget Percent' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select 'Whole Budget Percent' from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Whole Budget Percent");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_PercentBudget_nm,"Percent Budget text box", true, true);

					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					

					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36790 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36790 Completed");
				}
				return obj;
			} //End of function TC36790
			
			//RW-279_Items_TC011_Verify the format of the page after selecting Whole House SqFT  for Row Type
			@SuppressWarnings("static-access")
			public Reporter TC36791(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC36791 Started..");

				try {
							
					obj.repAddData( "Verify the format of the page after selecting 'Whole House SqFt' for Row Type ", "", "", "");
					
					fnSelectCorpOffice(sCorporation, sOffice);
					
					ClickByXpath(objRWModules.Items_GenItem_LinkItemsOption_xp,"Items Link", true);
					ClickByXpath(objRWModules.Items_ViewItem_BtnAddItem_xp, "Add Item", true);
					
					HighlightElementByXpath(objRWModules.Items_AddItem_ComboRowType_xp);
					
					//Select 'Whole House SqFt' from Select Box
					Select rowType = new Select(driver.findElement(By.xpath(objRWModules.Items_AddItem_ComboRowType_xp)));
					rowType.selectByVisibleText("Whole House SqFT");
					
					//Validate all Fields
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemName_nm,"Item Name text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_RowTypeSelector_nm,"Row Type combo box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxRequired_xp,"Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxPictureRequired_xp,"Picture Required check box", true, true);
					fnCheckFieldDisplayByXpath(objRWModules.Items_AddItem_CheckBoxNonBudgetItem_xp,"Non Budget Item check box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_MaterialRate_nm,"Material Rate text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_LaborRate_nm,"Labor Rate text box", true, true);

					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_DefaultHours_nm,"Default Hours text box", true, true);

					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_GLCode_nm,"GL Code text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Category_nm,"Category text box", true, true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_Subcategory_nm,"Sub Category box", true, true);
					ClickByXpath(objRWModules.Items_AddItem_OpenCommentsSection_xp,"Open Description",true);
					fnCheckFieldDisplayByName(objRWModules.Items_AddItem_ItemComment_nm,"Comment Box",true,true);

					ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					fnVerifyCancelForm(1);
		
				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function TC36791 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Function TC36791 Completed");
				}
				return obj;
			} //End of function TC36791
			
			///////////////////////////////////////Row Type Test Ends here///////////////////////////////////////////////////////////////////////////
			
			
			///////////////////////////////////////Spike/Dummy Starts Here////////////////////////////////////////////////////////////////////////////
			
			//RW-58_Regions_TC017_Add Region_Validate Region Name with duplicate Region name
			@SuppressWarnings("static-access")
			public Reporter TC1111111(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC1111111 Started..");

				try {
							
					obj.repAddData( "Executing SoapUI Test", "", "", "");
					
					String[] cmdArray = new String[3];
					//Runtime.getRuntime().exec("C:\\Soap_Projects\\soap_selenium_launcher.bat C:\\Soap_Projects\\SeleniumIntegration-soapui-project.xml");
					
					 cmdArray[0] = "C:\\Soap_Projects\\soap_selenium_launcher.bat";

					   // second argument is a txt file we want to open with notepad
					   cmdArray[1] = "C:\\Soap_Projects\\SeleniumIntegration-soapui-project.xml";
					   cmdArray[2] = "TS";
					   //cmdArray[3] = "TC_2";

					   // print a message
					   System.out.println("Executing soap project from selenium..");

					   // create a process and execute cmdArray
					   Process process = Runtime.getRuntime().exec(cmdArray);
					   try {
						process.waitFor();
						if(process.exitValue()==0)
						{
							obj.repAddData( "Run SoapUI Test", "SoapUI Test should be passed", "SoapUI Test passed successfully", "Pass");
						}
						else
						{
							obj.repAddData( "Run SoapUI Test", "SoapUI Test should be passed", "SoapUI Test failed with exit value - "+process.exitValue(), "Fail");
						}
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						obj.repAddData( "Run SoapUI Test", "SoapUI Test should be passed", "SoapUI Test failed with exit value - "+process.exitValue(), "Fail");
						e.printStackTrace();
					}
					   System.out.println("Execution Completed with Exit value "+process.exitValue());

									}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					if(driver.findElement(By.xpath(objRWModules.Common_AddModule_BtnCancel_xp)).isEnabled())
					{
						ClickByXpath(objRWModules.Common_AddModule_BtnCancel_xp, "Cancel button",false);  //post condition
					}
					log.error( "Function TC1111111 Failed!", e );
				}
				finally {
		
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					
					log.info("Execution of Function TC1111111 Completed");
				}
				return obj;
			} //End of function TC1111111	
			
			//Renowalk - Regression - Login to Renowalk and Logout - 1
			@SuppressWarnings("static-access")
			public Reporter TC25701(Reporter obj) throws Exception
			{
				Boolean bLoginFlag = false;	
				log.info("Execution of Function fn25701 Started..");
				
		
				try {
							
					obj.repAddData( "View Properties", "", "", "");
					
					ClickByXpath(objRWModules.Property_GenProp_LinkPropertyOption_xp, "Property Link",true);
					
					fnLoadingPageWait();

					/*CheckId(objRWModules.Property_ViewProp_BtnAddProperty_id,"'Add Property' button",true);
					CheckXpath(objRWModules.Property_ViewProp_LabelProperties_xp,"'Properties' Label",true);
					
					HighlightElementById(objRWModules.Property_ViewProp_ComboStatus_id);
					Select select = new Select(driver.findElement(By.id(objRWModules.Property_ViewProp_ComboStatus_id)));
					String sString = select.getFirstSelectedOption().getText();
					
					if(sString.equalsIgnoreCase("Select Status"))
					{
						obj.repAddData( "Verify Status combo box", "'Select Status' should be selected in the combo box", "'Select Status' is selected in the combo box", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Status combo box", "'Select Status' should be selected in the combo box", "'Select Status' is not selected in the combo box", "Fail");
					}
					
					CheckId(objRWModules.Property_ViewProp_InputSearchValue_id,"'Search Value' field",true);*/
					
					
					List<WebElement> arrTBodies = driver.findElements(By.xpath(objRWModules.Property_ViewProp_TableListItem_xp));
					System.out.println("TBodies Size>>>>"+arrTBodies.size());
					List<WebElement> arrRows = arrTBodies.get(0).findElements(By.xpath("./tr"));  //Get the header
					System.out.println("Rows Size>>>>"+arrRows.size());
					List<WebElement> arrColumns = arrRows.get(0).findElements(By.xpath("./th"));  //Get the header
						
					/*System.out.println("Column Size>>>>"+arrColumns.size());
					if(arrColumns.size()>0)
					{
					fnVerifyHeaders(arrColumns,0,"Status");
					fnVerifyHeaders(arrColumns,1,"Project Name");
					fnVerifyHeaders(arrColumns,2,"Address");
					fnVerifyHeaders(arrColumns,3,"City");
					fnVerifyHeaders(arrColumns,4,"County");
					fnVerifyHeaders(arrColumns,5,"Assigned User");
					fnVerifyHeaders(arrColumns,6,"Last Activity");
					}
					else
					{
						System.out.println("Property table is not loaded");
						log.info("Property table is not loaded");
					}
					
					List<WebElement> arrRecordRows = arrTBodies.get(1).findElements(By.xpath("./tr"));  //Get the header
					List<WebElement> arrRecordColumns = arrRecordRows.get(0).findElements(By.xpath("./td"));  //Get the header
					//String sParentProjName = arrRecordColumns.get(1).findElement(By.xpath("..")).getTagName();
					String sChildProjName = arrRecordColumns.get(1).findElement(By.xpath("*")).getTagName();

					if(sChildProjName.equalsIgnoreCase("b"))
					{
						obj.repAddData( "Check 'Project Name'", "'Project Name' should be in bold font", "'Project Name' is in bold font", "Pass");
					}
					else
					{
						obj.repAddData( "Check 'Project Name'", "'Project Name' should be in bold font", "'Project Name' is not in bold font", "Fail");
					}
					
					ClickByElement(arrRecordColumns.get(1), "First Project Name",true);  //Clicking on first project name
					//arrRecordColumns.get(1).click();  //Clicking on first project name
					fnLoadingPageWait();
					
					CheckId(objRWModules.Property_UpdateProp_BtnUpdateProperty_id,"'Update Property' page",true);
					ClickById(objRWModules.Property_GenProp_BtnCancelProperty_id,"'Cancel Property' page",false);
					
					*/
					////////////////////Sorting Logic////////////////////////////
					//fnCheckSorting(objRWModules.Property_ViewProp_TableListItem_xp, "County", 5);
					//fnCheckDateSorting(mTableData, "Last Activity", 7, "");
					////////////////////Sorting Logic End////////////////////////////
					
					
				
				}
				
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function fn25701 Failed!", e );
				}
				finally {
					
					if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}
	
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					/*obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					header = null;    //Enable after testing
	*/				log.info("Execution of Function fn25701 Completed");
				}
				return obj;
			} //End of function fn25701	

		//Renowalk - Regression - Login to Renowalk and Logout - 1
			@SuppressWarnings("static-access")
			public Reporter TC25702(Reporter obj) throws Exception
			{
				//Boolean bLoginFlag = true;	
				log.info("Execution of Function TC25702 Started..");
				
		
				try {
							
					obj.repAddData( "Pagination Verification", "", "", "");
					
					/*ClickByXpath(objRWModules.Corporations_GenCorp_LinkCorporationsOption_xp, "Corporations Link",true);
					fnLoadingPageWait();
					ClickByXpath(objRWModules.Regions_GenRegion_LinkRegionsOption_xp, "Regions Link",true);
					fnLoadingPageWait();*/
					ClickByXpath(objRWModules.Offices_GenOffice_LinkOfficesOption_xp, "Offices Link",true);
					fnLoadingPageWait();
	
					CheckXpath(RenowalkModules.Offices_ViewOffice_BtnAddOffice_xp,"'Add Office' button",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.Offices_ViewOffice_BtnAddOffice_xp)));
					CheckXpath(RenowalkModules.Offices_ViewOffice_LabelCurrentOffices_xp,"'Current Offices' label",true,true);
					HighlightElement(driver.findElement(By.xpath(RenowalkModules.Offices_ViewOffice_LabelCurrentOffices_xp)));
					
					
					WebElement eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("./thead/tr/th"));  //Get the header
					System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
					fnVerifyHeaders(arrHeaderColumns,0,"Region Name");
					fnVerifyHeaders(arrHeaderColumns,1,"Default Store");
					
					
					HighlightElementByXpath(objRWModules.Common_ViewModules_ComboPageSize_xp);
					Select select = new Select(driver.findElement(By.xpath(objRWModules.Common_ViewModules_ComboPageSize_xp)));
					List<WebElement> arrPageSize = select.getOptions();
					System.out.println("Page Combobox Size>>>>"+arrPageSize.size());
					
					/*fnVerifyComboBoxValues(arrPageSize, 0, "10 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 1, "20 PER PAGE");
					fnVerifyComboBoxValues(arrPageSize, 2, "VIEW ALL");*/
					
					int iMultiPages = CheckXpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp, "Total No of Pages", false,true);
					
					if(iMultiPages>0)
					{
						String sTotalPageNum = driver.findElement(By.xpath(RenowalkModules.Common_ViewModules_LabelTotalPages_xp)).getText();
						int iTotalPageNum =  Integer.parseInt(sTotalPageNum);
						iTotalPageNum = iTotalPageNum -1;
						SendKeyByXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp, String.valueOf(iTotalPageNum), "Page Number");
					}
				
					eleTable = driver.findElement(By.xpath(objRWModules.Common_ViewModules_Table_xp));
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tbody/tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					
				/*	if(arrTableRows.size()>=10)
					{
						CheckXpath(RenowalkModules.Common_ViewModules_BtnPreviousLink_xp,"'Previous' button",true);
						CheckXpath(RenowalkModules.Common_ViewModules_BtnNextLink_xp,"'Next' button",true);
						CheckXpath(RenowalkModules.Common_ViewModules_InputPageNum_xp,"'Page Number' textbox",true);						
					}
					else
					{
						
					}*/
					
					//HashMap<Integer, ArrayList<String>> mTableData = new HashMap<Integer,ArrayList<String>>();
					
					HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer,HashMap<Integer, String>>();
					ArrayList<String> arrTableData = new ArrayList<String>();

					for(int iRow=0;iRow<arrTableRows.size();iRow++)
					{	
						//arrTableData.clear();
						String sColValue=null;
						mTableData.put(iRow+1, new HashMap<Integer, String>());
						
						List<WebElement> arrTableColumns = arrTableRows.get(iRow).findElements(By.xpath("./td"));  //Get the table data rows
						for(int iCol=0;iCol<arrTableColumns.size();iCol++)
						{
							List<WebElement> arrEditDelete;	
						
							switch (iCol) 
							{
								case 0: //sColValue = arrTableColumns.get(iCol).findElement(By.xpath("./b")).getText();//.toString();
										sColValue = arrTableColumns.get(iCol).findElement(By.xpath("./b")).getAttribute("innerText");
										System.out.println("sColValue"+sColValue);
										break;
								case 1: sColValue = arrTableColumns.get(iCol).getText().toString();
										break;
								case 2: arrEditDelete = arrTableColumns.get(iCol).findElements(By.xpath("./div/span"));
										String sEdit  = arrEditDelete.get(0).getAttribute("title");
										String sDelete = arrEditDelete.get(1).getAttribute("title");
										System.out.println(sEdit+sDelete);
										sColValue= sEdit+","+sDelete;
										break;
							}
							arrTableData.add(sColValue);
							
							mTableData.get(iRow+1).put(iCol+1,sColValue);
						}
						

					}
					
					fnCheckSortedList(mTableData,"Office Name",1);
					System.out.println("Data Retrieved Successfully");
					
					/*CheckId(objRWModules.Property_ViewProp_BtnAddProperty_id,"'Add Property' button",true);
					CheckXpath(objRWModules.Property_ViewProp_LabelProperties_xp,"'Properties' Label",true);
					
					HighlightElementById(objRWModules.Property_ViewProp_ComboStatus_id);
					Select select = new Select(driver.findElement(By.id(objRWModules.Property_ViewProp_ComboStatus_id)));
					String sString = select.getFirstSelectedOption().getText();
					
					if(sString.equalsIgnoreCase("Select Status"))
					{
						obj.repAddData( "Verify Status combo box", "'Select Status' should be selected in the combo box", "'Select Status' is selected in the combo box", "Pass");
					}
					else
					{
						obj.repAddData( "Verify Status combo box", "'Select Status' should be selected in the combo box", "'Select Status' is not selected in the combo box", "Fail");
					}
					
					CheckId(objRWModules.Property_ViewProp_InputSearchValue_id,"'Search Value' field",true);*/
				/*	
							
							List<WebElement> arrTBodies = driver.findElements(By.xpath(objRWModules.Property_ViewProp_TableListItem_xp));
							System.out.println("TBodies Size>>>>"+arrTBodies.size());
							List<WebElement> arrRows = arrTBodies.get(0).findElements(By.xpath("./tr"));  //Get the header
							System.out.println("Rows Size>>>>"+arrRows.size());
							List<WebElement> arrColumns = arrRows.get(0).findElements(By.xpath("./th"));  //Get the header
*/								
					/*System.out.println("Column Size>>>>"+arrColumns.size());
					if(arrColumns.size()>0)
					{
					fnVerifyHeaders(arrColumns,0,"Status");
					fnVerifyHeaders(arrColumns,1,"Project Name");
					fnVerifyHeaders(arrColumns,2,"Address");
					fnVerifyHeaders(arrColumns,3,"City");
					fnVerifyHeaders(arrColumns,4,"County");
					fnVerifyHeaders(arrColumns,5,"Assigned User");
					fnVerifyHeaders(arrColumns,6,"Last Activity");
					}
					else
					{
						System.out.println("Property table is not loaded");
						log.info("Property table is not loaded");
					}
					
					List<WebElement> arrRecordRows = arrTBodies.get(1).findElements(By.xpath("./tr"));  //Get the header
					List<WebElement> arrRecordColumns = arrRecordRows.get(0).findElements(By.xpath("./td"));  //Get the header
					//String sParentProjName = arrRecordColumns.get(1).findElement(By.xpath("..")).getTagName();
					String sChildProjName = arrRecordColumns.get(1).findElement(By.xpath("*")).getTagName();
	
					if(sChildProjName.equalsIgnoreCase("b"))
					{
						obj.repAddData( "Check 'Project Name'", "'Project Name' should be in bold font", "'Project Name' is in bold font", "Pass");
					}
					else
					{
						obj.repAddData( "Check 'Project Name'", "'Project Name' should be in bold font", "'Project Name' is not in bold font", "Fail");
					}
					
					ClickByElement(arrRecordColumns.get(1), "First Project Name",true);  //Clicking on first project name
					//arrRecordColumns.get(1).click();  //Clicking on first project name
					fnLoadingPageWait();
					
					CheckId(objRWModules.Property_UpdateProp_BtnUpdateProperty_id,"'Update Property' page",true);
					ClickById(objRWModules.Property_GenProp_BtnCancelProperty_id,"'Cancel Property' page",false);
					
					*/
					////////////////////Sorting Logic////////////////////////////
					//fnCheckSorting(objRWModules.Property_ViewProp_TableListItem_xp, "County", 5);
			//		fnCheckDateSorting(objRWModules.Property_ViewProp_TableListItem_xp, "Last Activity", 7);
					////////////////////Sorting Logic End////////////////////////////

				}
				catch (Exception e) {
					e.printStackTrace();
					testCaseStatus = false;
					//bLoginFlag=false;
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
					log.error( "Function fn25701 Failed!", e );
				}
				finally {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/
	
					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					/*obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					header = null;    //Enable after testing
	*/				log.info("Execution of Function TC25702 Completed");
				}
				return obj;
			} //End of function TC25702	

					//Renowalk - Regression - Login to Renowalk and Logout - 1
					public Reporter TC26677(Reporter obj) throws Exception
					{
						Boolean bLoginFlag = false;	
						log.info("Execution of Function TC26677 Started..");
						obj.repAddData( "Home page", "", "", "");
						obj.repAddData( "Verify Renowalk home page", "Home page should be loaded", "Home page loaded successfully", "Pass");
						obj.repAddData( "Verify Renowalk ", "Home page should be loaded", "Home page loaded successfully", "Pass");
				  				
						try {
									
							//Write your code here
						}
						
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							//bLoginFlag=false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Function TC26677 Failed!", e );
						}
						finally {
							
							if((bLoginFlag==true && driver!=null) )
							{
								fnSignOut();
							}
			
							if(!testCaseStatus)
							{
								Reporter.iTotalFail++;	
							}
							else
							{
								Reporter.iTotalPass++;
							}
							/*obj.repGenerateResult(Test_Case_Name, header);
							obj.repGenerateIndexReport(indexHeader);
							header = null;    //Enable after testing
			*/				log.info("Execution of Function TC26677 Completed");
						}
						return obj;
					} //End of function TC26677	

				//Renowalk - Regression - Login to Renowalk and Logout - 2
				public Reporter TC157158(Reporter obj) throws Exception
				{
					Boolean bLoginFlag = true;	
					log.info("Execution of Function fn157158 Started..");
					obj.repAddData( "Verify Renowalk home page", "Home page should be loaded", "Home page loaded successfully", "Fail");
					obj.repAddData( "Verify Renowalk home page", "Home page should be loaded", "Home page loaded successfully", "Fail");
			  				
					try {
								
						//Write your code here
					}
					
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Function fn157158 Failed!", e );
					}
					finally {
						
						if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}
		
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						/*obj.repGenerateResult(Test_Case_Name, header);
						obj.repGenerateIndexReport(indexHeader);
						header = null;    //Enable after testing
		*/				log.info("Execution of Function fn157158 Completed");
					}
					return obj;
				} //End of function fn157158	

		//Renowalk - Regression - Login to Renowalk and Logout - 3
		public Reporter TC157159(Reporter obj) throws Exception
		{
			Boolean bLoginFlag = false;
			obj.repAddData( "Home page", "", "", "");
			obj.repAddData( "Verify Renowalk home page", "Home page should be loaded", "Home page loaded successfully", "Pass");
			obj.repAddData( "Verify Renowalk home page", "Home page should be loaded", "Home page loaded successfully", "Fail");
			log.info("Execution of Function fn157159 Started..");
		  				
			try {
					
				//Write your code here
			}
			
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Function fn157159 Failed!", e );
			}
			finally {
				
				if((bLoginFlag==true && driver!=null) )
				{
					fnSignOut();
				}

				if(!testCaseStatus)
				{
					Reporter.iTotalFail++;	
				}
				else
				{
					Reporter.iTotalPass++;
				}

				log.info("Execution of Function fn157159 Completed");
			}
			return obj;
		} //End of function fn157159	
	
} //End of Class