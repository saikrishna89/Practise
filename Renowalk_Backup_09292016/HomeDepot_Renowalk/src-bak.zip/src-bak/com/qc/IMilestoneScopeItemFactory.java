package com.qc  ;

import com4j.*;

/**
 * MilestoneScopeItem Factory
 */
@IID("{87A3FD70-7FBA-41E9-B6B6-41BE00EA5CB1}")
public interface IMilestoneScopeItemFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
