package com.qc  ;

import com4j.*;

/**
 * For HP use. Services for managing comparisons.
 */
@IID("{ADF1AF0C-EC7F-4466-ACC8-300DE3F053EC}")
public interface IComparisonNodeFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
