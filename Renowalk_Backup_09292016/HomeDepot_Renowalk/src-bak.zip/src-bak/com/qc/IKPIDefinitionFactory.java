package com.qc  ;

import com4j.*;

/**
 * For HP use. Represents a KPIDefinition Factory.
 */
@IID("{0636C892-D22F-4AB7-89CC-0FEFBFC791DD}")
public interface IKPIDefinitionFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
