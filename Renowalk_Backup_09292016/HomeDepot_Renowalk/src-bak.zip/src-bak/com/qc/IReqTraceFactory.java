package com.qc  ;

import com4j.*;

/**
 * Services for managing traceability associations between requirements.
 */
@IID("{59AFC6E7-D640-401D-80C4-934340993704}")
public interface IReqTraceFactory extends com.qc.IBaseFactory {
  // Methods:
  // Properties:
}
