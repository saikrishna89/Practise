package com.qc  ;

import com4j.*;

/**
 * Services for managing CoverageEntity objects.
 */
@IID("{FD167DFE-8DEE-4930-AFAA-A83C2B1480EB}")
public interface ICoverageFactory extends com.qc.IBaseFactory {
  // Methods:
  // Properties:
}
