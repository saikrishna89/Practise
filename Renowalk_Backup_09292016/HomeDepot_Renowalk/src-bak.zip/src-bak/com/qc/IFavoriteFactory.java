package com.qc  ;

import com4j.*;

/**
 * Services to manage user-defined display settings.
 */
@IID("{C4E5171E-9BFA-4292-AB0C-F9C248193403}")
public interface IFavoriteFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
