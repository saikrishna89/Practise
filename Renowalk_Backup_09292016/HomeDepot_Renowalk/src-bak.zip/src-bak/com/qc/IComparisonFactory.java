package com.qc  ;

import com4j.*;

/**
 * For HP use. Services for managing comparisons.
 */
@IID("{07827C39-03AF-4E69-8091-267A471F9E89}")
public interface IComparisonFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
