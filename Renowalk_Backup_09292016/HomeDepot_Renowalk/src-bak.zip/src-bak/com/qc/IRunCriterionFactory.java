package com.qc  ;

import com4j.*;

/**
 * Services for managing run criteria.
 */
@IID("{4E9BA17B-825B-46CE-A916-183411AB9B1D}")
public interface IRunCriterionFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
