package com.qc  ;

import com4j.*;

/**
 * Services for managing AuditProperty objects.
 */
@IID("{A3D667D7-2285-4FE1-A799-8581C6D8DE70}")
public interface IAuditPropertyFactory extends com.qc.IBaseFactory {
  // Methods:
  // Properties:
}
