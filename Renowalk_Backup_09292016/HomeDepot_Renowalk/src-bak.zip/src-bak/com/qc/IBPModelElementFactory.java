package com.qc  ;

import com4j.*;

/**
 * Services for managing Business Process Model Element.
 */
@IID("{D8AD1F28-6D59-4C47-924D-828FDE762DF3}")
public interface IBPModelElementFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
