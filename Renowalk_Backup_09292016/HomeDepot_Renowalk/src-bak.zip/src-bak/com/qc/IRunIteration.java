package com.qc  ;

import com4j.*;

/**
 * Services for run iteration.
 */
@IID("{E5D84B97-219C-4698-ABEE-48F110755E2F}")
public interface IRunIteration extends com.qc.IBaseField {
  // Methods:
  // Properties:
}
