package com.qc  ;

import com4j.*;

/**
 * KPIMilestoneScopeItem Factory
 */
@IID("{F631190A-C557-4EC1-8773-2FA3A708F8F9}")
public interface IKPIMilestoneScopeItemFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
