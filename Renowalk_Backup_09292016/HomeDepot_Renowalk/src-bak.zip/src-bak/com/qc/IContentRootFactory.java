package com.qc  ;

import com4j.*;

/**
 * Represents a Content Root Factory.
 */
@IID("{0DC28FC3-F456-438E-B351-0087EA5B3A6C}")
public interface IContentRootFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
