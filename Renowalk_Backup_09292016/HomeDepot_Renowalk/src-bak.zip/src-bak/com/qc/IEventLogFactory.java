package com.qc  ;

import com4j.*;

/**
 * For HP use. Services for managing EventLog entities.
 */
@IID("{336DC31A-A01D-445C-B947-53842A00BB2A}")
public interface IEventLogFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
