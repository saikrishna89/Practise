package com.qc  ;

import com4j.*;

/**
 * For HP use. Services to manage analysis item files.
 */
@IID("{38B657F5-03E1-4459-90A7-B50E0BC1629D}")
public interface IAnalysisItemFileFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
