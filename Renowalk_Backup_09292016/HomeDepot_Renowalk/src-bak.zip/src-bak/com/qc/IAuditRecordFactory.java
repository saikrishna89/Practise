package com.qc  ;

import com4j.*;

/**
 * Services for managing AuditRecord objects.
 */
@IID("{10747648-0DF0-4B8C-8853-7408C70D883A}")
public interface IAuditRecordFactory extends com.qc.IBaseFactory {
  // Methods:
  // Properties:
}
