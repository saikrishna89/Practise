package com.qc  ;

import com4j.*;

/**
 * Represents a Content Part Factory.
 */
@IID("{264E6DB2-2574-433E-A264-A1BB8CE8459F}")
public interface IContentPartFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
