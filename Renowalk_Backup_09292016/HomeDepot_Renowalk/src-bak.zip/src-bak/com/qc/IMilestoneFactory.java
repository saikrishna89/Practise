package com.qc  ;

import com4j.*;

/**
 * Milestone Factory
 */
@IID("{F8019D12-757B-4605-9C73-7C1C6271A56E}")
public interface IMilestoneFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
