package com.qc  ;

import com4j.*;

/**
 * Services for managing Facets factory (BPT entity).
 */
@IID("{816F2624-6C03-4EB3-8CDF-6A784044BFFF}")
public interface IFacetFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
