package com.qc  ;

import com4j.*;

/**
 * Represents a PublicEntityKey Factory.
 */
@IID("{D3558B9C-D77C-405F-895F-33B3E56EDF6C}")
public interface IPublicEntityKeyFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
