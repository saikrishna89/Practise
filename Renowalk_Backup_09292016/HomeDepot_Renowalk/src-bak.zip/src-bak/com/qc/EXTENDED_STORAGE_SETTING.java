package com.qc  ;

import com4j.*;

/**
 */
public enum EXTENDED_STORAGE_SETTING {
  /**
   * <p>
   * The value of this constant is 0
   * </p>
   */
  EStorage_MirrorSet, // 0
  /**
   * <p>
   * The value of this constant is 1
   * </p>
   */
  EStorage_MirrorGet, // 1
}
