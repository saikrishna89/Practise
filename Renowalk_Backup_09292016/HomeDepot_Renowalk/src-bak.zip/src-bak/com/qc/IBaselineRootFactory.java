package com.qc  ;

import com4j.*;

/**
 * For HP use. Services for managing Baseline Roots
 */
@IID("{E801BB54-EC2E-44EB-9115-7B39D54CD89E}")
public interface IBaselineRootFactory extends com.qc.IBaseFactoryEx {
  // Methods:
  // Properties:
}
