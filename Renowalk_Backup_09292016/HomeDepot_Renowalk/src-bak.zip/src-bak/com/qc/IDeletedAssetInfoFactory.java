package com.qc  ;

import com4j.*;

/**
 * Represents a deleted assets factory.
 */
@IID("{21823396-E1CF-4328-94AA-0891B14D83E8}")
public interface IDeletedAssetInfoFactory extends com.qc.IBaseFactory {
  // Methods:
  // Properties:
}
