package com.qc  ;

import com4j.*;

/**
 * For HP use. IAttachmentVcs Interface.
 */
@IID("{CE4BEF63-1922-4C81-8C81-DC18FF94D8E7}")
public interface IAttachmentVcs extends Com4jObject {
  // Methods:
  // Properties:
}
