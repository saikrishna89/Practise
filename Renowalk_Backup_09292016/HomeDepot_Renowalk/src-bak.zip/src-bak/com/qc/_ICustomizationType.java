package com.qc  ;

import com4j.*;

/**
 * For HP use. _ICustomizationType Interface.
 */
@IID("{542912D4-D481-440A-8DB2-39D8D4E2EA93}")
public interface _ICustomizationType extends Com4jObject {
  // Methods:
  /**
   * @param icon Mandatory java.lang.Object parameter.
   */

  @VTID(3)
  void setIcon(
    @MarshalAs(NativeType.VARIANT) java.lang.Object icon);


  // Properties:
}
